# Pending skill improvements (apply after iteration-1 runs finish; do not edit skill while runs use it)
1. profile_data.md truncation hid rakuten.url dup row -> always include rows with dups/KEY?/malformed notes beyond --max-rows; raise default.
2. ledger status recommends BASELINE while gate REVIEW/STOP -> check gate first (GATE_BLOCKED / AWAIT_USER).
3. hours limit counts user-wait time -> clock pause/resume (ledger.py clock) or exclude gate-wait; document.
4. task-design: recipe for deriving tasks from existing data (pairs -> candidate selection): negatives by removing true item, hard negatives (same shop/similar), unlabeled candidate may be a true positive, retrieval coverage of prefilter, two questions per query (with/without true).
5. audit: shortcut/leakage check (answer ids/codes appear verbatim in input), "too easy with random candidates" check; close-read verdicts file convention (audit/close_read.md table).
6. checks.py: aux files (charter.data.aux) readable via ctx + hashed by gate.
7. ledger.py history -> markdown table for report.

## Applied in commit c593bab (2026-10-18 ~15:55Z): items 1-7 + user requests (deliverables, non-AI aids, production settings, thinking minimal) + quota breaker.
## Resumed with-skill agents eval-1 (a154b4b...) and eval-2 (a8ee9d1...) at ~15:56Z with skill-update notice. Baselines (a6a54a7..., a903e0e...) deferred to save quota.
