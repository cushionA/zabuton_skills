ai-task-autotuner test data and test-run records (2026-10-18/19)

inputs/sku-product-volume-normal-v1.zip  original test data as received (unzip it; ~66MB)
inputs/brief_sku.md                      the brief that came with the data
evals.json                               the two test prompts (replace DATA_DIR / BRIEF_PATH)
iteration-1/<eval>/<with_skill|without_skill>/outputs/
    with_skill: ws/ = skill workspace (charter, audit, eval, candidates, runs, ledger, journal,
                deliverables), final_message.md, skill_feedback.md
    without_skill: the comparison run's own files
iteration-1/<eval>/eval_metadata.json    prompt and draft grading assertions
iteration-1/*/timing.json                recorded agent time/tokens where available
pending_improvements.md                  improvement notes taken during the runs

Workspaces record absolute paths of the original machine. To continue a workspace locally,
see ai-task-autotuner/HANDOFF.md section 7 (relocate_workspace.py, clock resume --gap).
Runs contain full prompts/responses (calls.jsonl) built from the product data; do not publish.
