"""Run a prompt variant over a split with haiku via `claude -p`, then score.

Usage: python3 -I run_eval.py OUT_DIR VARIANT SPLIT [--workers 8] [--limit N] [--ids a,b] [--tag name]
Results: OUT_DIR/runs/<tag or VARIANT_SPLIT>/{raw/<qid>.json, predictions.jsonl, summary.json}
Cached per question: re-running skips questions that already have a successful raw result.
"""
import json, sys, os, re, time, subprocess, argparse, concurrent.futures as cf, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from prompts import VARIANTS

ap = argparse.ArgumentParser()
ap.add_argument("out"); ap.add_argument("variant"); ap.add_argument("split")
ap.add_argument("--workers", type=int, default=8)
ap.add_argument("--limit", type=int, default=0)
ap.add_argument("--ids", default="")
ap.add_argument("--tag", default="")
ap.add_argument("--model", default="haiku")
ap.add_argument("--budget-stop", type=float, default=2.7, help="abort if cumulative ledger cost exceeds this")
a = ap.parse_args()

OUT = a.out
qs = [json.loads(l) for l in open(f"{OUT}/data/questions.jsonl", encoding="utf-8")]
qs = [q for q in qs if a.split == "all" or q["split"] == a.split]
if a.ids:
    want = set(a.ids.split(","))
    qs = [q for q in qs if q["qid"] in want]
if a.limit:
    qs = qs[: a.limit]
pool = json.load(open(f"{OUT}/data/rakuten_pool.json", encoding="utf-8"))
au_items = json.load(open(f"{OUT}/data/au_items.json", encoding="utf-8"))
system, render = VARIANTS[a.variant]
tag = a.tag or f"{a.variant}_{a.split}"
rd = f"{OUT}/runs/{tag}"
os.makedirs(f"{rd}/raw", exist_ok=True)
ledger_path = f"{OUT}/runs/cost_ledger.jsonl"

def ledger_total():
    if not os.path.exists(ledger_path):
        return 0.0
    return sum(json.loads(l).get("cost", 0) for l in open(ledger_path))

env = {k: v for k, v in os.environ.items() if k not in ("CLAUDECODE", "CLAUDE_CODE_ENTRYPOINT")}
cwd = f"{OUT}/emptycwd"
os.makedirs(cwd, exist_ok=True)

def parse(text):
    m = re.findall(r"ANSWER\s*[:：]\s*(C\s*\d+|NONE|該当なし)", text or "", flags=re.I)
    if not m:
        return None
    v = m[-1].upper().replace(" ", "")
    return "NONE" if v in ("NONE", "該当なし") else v

def call(q):
    path = f"{rd}/raw/{q['qid']}.json"
    if os.path.exists(path):
        d = json.load(open(path))
        if not d.get("is_error") and d.get("result") is not None:
            return q, d, True
    user = render(q, au_items[q["au_url"]], pool)
    cmd = ["claude", "-p", "--model", a.model, "--system-prompt", system, "--tools", "",
           "--strict-mcp-config", "--setting-sources", "", "--no-session-persistence", "--output-format", "json"]
    d = None
    for attempt in range(3):
        t0 = time.time()
        try:
            p = subprocess.run(cmd, input=user, capture_output=True, text=True, env=env, cwd=cwd, timeout=180)
            d = json.loads(p.stdout)
            d["_wall_s"] = round(time.time() - t0, 2)
            d["_attempt"] = attempt
            d["_input_chars"] = len(user) + len(system)
            if not d.get("is_error"):
                break
        except Exception as e:  # noqa
            d = {"is_error": True, "error": repr(e)[:300], "_wall_s": round(time.time() - t0, 2), "_attempt": attempt}
        time.sleep(2 + 3 * attempt)
    json.dump(d, open(path, "w"), ensure_ascii=False)
    with open(ledger_path, "a") as f:
        f.write(json.dumps({"tag": tag, "qid": q["qid"], "cost": d.get("total_cost_usd", 0) or 0}) + "\n")
    return q, d, False

start_total = ledger_total()
if start_total > a.budget_stop:
    sys.exit(f"ledger total {start_total:.3f} exceeds budget stop {a.budget_stop}")
t0 = time.time()
results = []
with cf.ThreadPoolExecutor(a.workers) as ex:
    for q, d, cached in ex.map(call, qs):
        results.append((q, d, cached))
wall = time.time() - t0

preds = []
for q, d, cached in results:
    pred = parse(d.get("result")) if not d.get("is_error") else None
    u = d.get("usage") or {}
    preds.append(dict(qid=q["qid"], kind=q["kind"], gold=q["gold"], pred=pred, correct=(pred == q["gold"]),
                      cost=d.get("total_cost_usd", 0) or 0, wall_s=d.get("_wall_s"), cached=cached,
                      in_tok=(u.get("input_tokens", 0) + u.get("cache_creation_input_tokens", 0) + u.get("cache_read_input_tokens", 0)),
                      out_tok=u.get("output_tokens", 0),
                      thinking_tok=(u.get("output_tokens_details") or {}).get("thinking_tokens", 0),
                      error=d.get("is_error", False), result=(d.get("result") or "")[-600:]))
with open(f"{rd}/predictions.jsonl", "w", encoding="utf-8") as f:
    for p in sorted(preds, key=lambda p: p["qid"]):
        f.write(json.dumps(p, ensure_ascii=False) + "\n")

def summarize(preds):
    n = len(preds)
    pos = [p for p in preds if p["gold"] != "NONE"]
    neg = [p for p in preds if p["gold"] == "NONE"]
    s = dict(n=n, accuracy=round(sum(p["correct"] for p in preds) / n, 4) if n else None,
             pos_n=len(pos), pos_correct=sum(p["correct"] for p in pos),
             pos_wrong_pick=sum(1 for p in pos if p["pred"] not in (None, "NONE", p["gold"])),
             pos_said_none=sum(1 for p in pos if p["pred"] == "NONE"),
             neg_n=len(neg), neg_correct=sum(p["correct"] for p in neg),
             neg_false_match=sum(1 for p in neg if p["pred"] not in (None, "NONE")),
             parse_fail_or_error=sum(1 for p in preds if p["pred"] is None))
    picks = [p for p in preds if p["pred"] not in (None, "NONE")]
    s["match_precision"] = round(sum(p["correct"] for p in picks) / len(picks), 4) if picks else None
    s["wrong_identifications"] = s["pos_wrong_pick"] + s["neg_false_match"]
    s["cost_usd_new_calls"] = round(sum(p["cost"] for p in preds if not p["cached"]), 4)
    s["cost_usd_all_calls"] = round(sum(p["cost"] for p in preds), 4)
    s["cost_per_q"] = round(s["cost_usd_all_calls"] / n, 5) if n else None
    ws = sorted(p["wall_s"] for p in preds if p["wall_s"])
    s["latency_median_s"] = ws[len(ws) // 2] if ws else None
    s["in_tok_mean"] = round(sum(p["in_tok"] for p in preds) / n) if n else None
    s["out_tok_mean"] = round(sum(p["out_tok"] for p in preds) / n) if n else None
    s["thinking_tok_total"] = sum(p["thinking_tok"] for p in preds)
    return s

summary = summarize(preds)
summary.update(tag=tag, variant=a.variant, split=a.split, model=a.model, wall_clock_s=round(wall, 1),
               ledger_total_usd=round(ledger_total(), 4))
json.dump(summary, open(f"{rd}/summary.json", "w"), indent=1)
print(json.dumps(summary, indent=1))
for p in sorted(preds, key=lambda p: p["qid"]):
    if not p["correct"]:
        print("MISS", p["qid"], p["kind"], "gold", p["gold"], "pred", p["pred"], "|", p["result"][-220:].replace("\n", " "))
