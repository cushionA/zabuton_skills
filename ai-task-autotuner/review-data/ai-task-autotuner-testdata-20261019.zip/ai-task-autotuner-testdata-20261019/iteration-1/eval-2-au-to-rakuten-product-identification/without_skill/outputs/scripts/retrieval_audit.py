"""Char-bigram TF-IDF retrieval au->rakuten, to find label ambiguity / errors. No model calls.
Usage: python3 -I retrieval_audit.py IN_DIR OUT_JSON"""
import json, sys, re, math, unicodedata, collections
IN, OUTJ = sys.argv[1], sys.argv[2]
rows = [json.loads(l) for l in open(f"{IN}/inputs/products.jsonl", encoding="utf-8")]
def norm(s): return re.sub(r"\s+", "", unicodedata.normalize("NFKC", s or "").lower())
def doc(side, desc_chars=1500):
    sk = " ".join(c.get("value", "") for s in side["skus"] for c in s["conditions"])
    return norm(side["title"]) + "|" + norm(sk) + "|" + norm((side["description"].get("text") or "")[:desc_chars])
def grams(s, n=2): return collections.Counter(s[i:i+n] for i in range(len(s)-n+1))
rak = {}
for r in rows: rak.setdefault(r["rakuten"]["url"], r["rakuten"])
rurls = list(rak)
rdocs = {u: grams(doc(rak[u])) for u in rurls}
df = collections.Counter(g for c in rdocs.values() for g in c)
N = len(rurls)
idf = lambda g: math.log((N + 1) / (df.get(g, 0) + 1)) + 1
def vec(c):
    v = {g: (1 + math.log(n)) * idf(g) for g, n in c.items()}
    z = math.sqrt(sum(x*x for x in v.values())) or 1
    return {g: x / z for g, x in v.items()}
rvec = {u: vec(c) for u, c in rdocs.items()}
def cos(a, b):
    if len(a) > len(b): a, b = b, a
    return sum(x * b.get(g, 0) for g, x in a.items())
out = []
ranks = []
for r in rows:
    av = vec(grams(doc(r["au"])))
    sc = sorted(((cos(av, rvec[u]), u) for u in rurls), reverse=True)
    true = r["rakuten"]["url"]
    rank = [u for _, u in sc].index(true) + 1
    ranks.append(rank)
    out.append(dict(id=r["product_pair_id"], au_title=r["au"]["title"], true=true, rank=rank,
                    top=[(round(s, 3), u, rak[u]["title"][:80]) for s, u in sc[:8]]))
json.dump(out, open(OUTJ, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
c = collections.Counter(min(k, 11) for k in ranks)
print("rank dist (11=>10+):", sorted(c.items()))
for o in out:
    if o["rank"] > 1:
        print(o["id"], "rank", o["rank"], "| A:", o["au_title"][:70])
        print("   true:", o["true"]); 
        for t in o["top"][:3]: print("   ", t)
