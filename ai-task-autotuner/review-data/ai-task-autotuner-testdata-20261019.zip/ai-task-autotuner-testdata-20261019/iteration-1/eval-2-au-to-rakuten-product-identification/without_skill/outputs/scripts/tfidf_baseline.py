"""Classical baseline (no model): pick top TF-IDF candidate if its cosine >= t, else NONE.
t is tuned on dev only, then applied to test. Usage: python3 -I tfidf_baseline.py OUT_DIR"""
import json, sys
OUT = sys.argv[1]
qs = [json.loads(l) for l in open(f"{OUT}/data/questions.jsonl", encoding="utf-8")]

def predict(q, t):
    best = max(q["candidates"], key=lambda u: q["tfidf_scores"][u])
    return q["labels"][q["candidates"].index(best)] if q["tfidf_scores"][best] >= t else "NONE"

def evaluate(sub, t):
    preds = [(q, predict(q, t)) for q in sub]
    acc = sum(p == q["gold"] for q, p in preds) / len(preds)
    wrong = sum(1 for q, p in preds if p != "NONE" and p != q["gold"])
    miss = sum(1 for q, p in preds if p == "NONE" and q["gold"] != "NONE")
    return dict(n=len(preds), accuracy=round(acc, 4), wrong_identifications=wrong, missed_matches=miss)

dev = [q for q in qs if q["split"] == "dev"]
test = [q for q in qs if q["split"] == "test"]
grid = [i / 100 for i in range(10, 96)]
best_t = max(grid, key=lambda t: (evaluate(dev, t)["accuracy"], -t))
res = {"threshold_tuned_on_dev": best_t, "dev": evaluate(dev, best_t), "test": evaluate(test, best_t),
       "test_main": evaluate([q for q in test if not q["twin"]], best_t),
       "dev_main": evaluate([q for q in dev if not q["twin"]], best_t)}
json.dump(res, open(f"{OUT}/runs/tfidf_baseline.json", "w"), indent=1)
print(json.dumps(res, indent=1))
