"""Build the au -> Rakuten product identification dataset (no model calls).

Decisions approved by the user ("推奨案でOK"):
  A. 3 confirmed wrong pairs are not positives; their au product becomes a natural 該当なし question
     (the wrongly-paired Rakuten listing stays in the candidates as a hard distractor).
  B. Listing-level identity: correct = the Rakuten listing that sells the au item (multi-model listings,
     set-count differences, duplicate au listings all point to the same Rakuten listing).
  C. ~40% 該当なし: synthesized by removing the true Rakuten listing from the candidates.
  D. 6 candidates per question, hardest-first by char-bigram TF-IDF similarity (same-shop siblings).
  E. Product-group split dev/test (groups = shared Rakuten listing or duplicate au listing).

Usage: python3 -I build_dataset.py IN_DIR OUT_DIR
Writes OUT_DIR/data/{questions.jsonl, rakuten_pool.json, au_items.json, split_summary.json}
"""
import json, sys, re, math, random, unicodedata, collections, os

IN, OUT = sys.argv[1], sys.argv[2]
SEED = 20261018
K = 6
NEG_RATE = 0.40
WRONG_PAIRS = {"raw-7f04455a83ac52c8", "raw-7fa1c1f5f6ac2ec6", "raw-affeea04e64fe893"}

rows = [json.loads(l) for l in open(f"{IN}/inputs/products.jsonl", encoding="utf-8")]

def norm(s):
    return re.sub(r"\s+", "", unicodedata.normalize("NFKC", s or "").lower())

def doc(side, desc_chars=1500):
    sk = " ".join(c.get("value", "") for s in side["skus"] for c in s["conditions"])
    return norm(side["title"]) + "|" + norm(sk) + "|" + norm((side["description"].get("text") or "")[:desc_chars])

def grams(s, n=2):
    return collections.Counter(s[i:i + n] for i in range(len(s) - n + 1))

# ---- Rakuten pool (unique listings) ----
rak = {}
for r in rows:
    rak.setdefault(r["rakuten"]["url"], r["rakuten"])
rurls = sorted(rak)
rdocs = {u: grams(doc(rak[u])) for u in rurls}
df = collections.Counter(g for c in rdocs.values() for g in c)
N = len(rurls)

def vec(c):
    v = {g: (1 + math.log(n)) * (math.log((N + 1) / (df.get(g, 0) + 1)) + 1) for g, n in c.items()}
    z = math.sqrt(sum(x * x for x in v.values())) or 1
    return {g: x / z for g, x in v.items()}

def cos(a, b):
    if len(a) > len(b):
        a, b = b, a
    return sum(x * b.get(g, 0) for g, x in a.items())

rvec = {u: vec(c) for u, c in rdocs.items()}

# ---- groups (union-find on shared Rakuten listing / identical au title+SKU set) ----
parent = {r["product_pair_id"]: r["product_pair_id"] for r in rows}
def find(x):
    while parent[x] != x:
        parent[x] = parent[parent[x]]
        x = parent[x]
    return x
def union(a, b):
    parent[find(a)] = find(b)
by_r = collections.defaultdict(list)
by_a = collections.defaultdict(list)
for r in rows:
    by_r[r["rakuten"]["url"]].append(r["product_pair_id"])
    sig = norm(r["au"]["title"]) + "|" + "|".join(sorted(norm(" ".join(c["value"] for c in s["conditions"])) for s in r["au"]["skus"]))
    by_a[sig].append(r["product_pair_id"])
for lst in list(by_r.values()) + list(by_a.values()):
    for x in lst[1:]:
        union(lst[0], x)
groups = collections.defaultdict(list)
for r in rows:
    groups[find(r["product_pair_id"])].append(r["product_pair_id"])

rng = random.Random(SEED)
gkeys = sorted(groups)
rng.shuffle(gkeys)
split_of = {}
counts = {"dev": 0, "test": 0}
for g in sorted(gkeys, key=lambda g: -len(groups[g])):  # place big groups first, then balance
    s = "dev" if counts["dev"] <= counts["test"] else "test"
    for pid in groups[g]:
        split_of[pid] = s
    counts[s] += len(groups[g])

# ---- choose which questions are synthesized negatives (per split, ~NEG_RATE incl. natural ones) ----
neg = set(WRONG_PAIRS)
for s in ("dev", "test"):
    ids = sorted(p for p in split_of if split_of[p] == s)
    target = round(NEG_RATE * len(ids))
    have = sum(1 for p in ids if p in neg)
    pool = [p for p in ids if p not in neg]
    rng.shuffle(pool)
    neg.update(pool[: max(0, target - have)])

# ---- build questions ----
questions = []
by_id = {r["product_pair_id"]: r for r in rows}
for r in rows:
    pid = r["product_pair_id"]
    av = vec(grams(doc(r["au"])))
    ranked = [u for _, u in sorted(((cos(av, rvec[u]), u) for u in rurls), key=lambda x: (-x[0], x[1]))]
    true_url = r["rakuten"]["url"]
    natural_neg = pid in WRONG_PAIRS
    if natural_neg:
        # the wrongly paired listing is NOT the answer; keep it among candidates as a distractor
        cands = ranked[:K]
        if true_url not in cands:
            cands = cands[: K - 1] + [true_url]
        answer = None
        kind = "neg_natural"
    elif pid in neg:
        cands = [u for u in ranked if u != true_url][:K]
        answer = None
        kind = "neg_synth"
    else:
        cands = [true_url] + [u for u in ranked if u != true_url][: K - 1]
        answer = true_url
        kind = "pos"
    versions = [(pid, kind, cands, answer)]
    # flipped twin (same au item, opposite answer type) to double statistical power; natural negatives have none
    if kind == "pos":
        versions.append((pid + "#neg", "neg_synth", [u for u in ranked if u != true_url][:K], None))
    elif kind == "neg_synth":
        versions.append((pid + "#pos", "pos", [true_url] + [u for u in ranked if u != true_url][: K - 1], true_url))
    for qid, kd, cs, ans in versions:
        cs = list(cs)
        qrng = random.Random(f"{SEED}-{qid}")
        qrng.shuffle(cs)
        labels = [f"C{i+1}" for i in range(len(cs))]
        gold = labels[cs.index(ans)] if ans else "NONE"
        questions.append(dict(
            qid=qid, base_id=pid, twin=("#" in qid), split=split_of[pid], kind=kd, group=find(pid),
            au_url=r["au"]["url"], candidates=cs, labels=labels, gold=gold,
            gold_url=ans, paired_rakuten_url=true_url,
            tfidf_rank_of_pair=ranked.index(true_url) + 1,
            tfidf_scores={u: round(cos(av, rvec[u]), 4) for u in cs},
        ))

os.makedirs(f"{OUT}/data", exist_ok=True)
with open(f"{OUT}/data/questions.jsonl", "w", encoding="utf-8") as f:
    for q in sorted(questions, key=lambda q: q["qid"]):
        f.write(json.dumps(q, ensure_ascii=False) + "\n")
json.dump({u: rak[u] for u in rurls}, open(f"{OUT}/data/rakuten_pool.json", "w", encoding="utf-8"), ensure_ascii=False)
json.dump({r["au"]["url"]: r["au"] for r in rows}, open(f"{OUT}/data/au_items.json", "w", encoding="utf-8"), ensure_ascii=False)
summ = collections.Counter((q["split"] + ("_twin" if q["twin"] else "_main"), q["kind"]) for q in questions)
summary = {f"{a}/{b}": n for (a, b), n in sorted(summ.items())}
summary["groups"] = len(groups)
summary["multi_member_groups"] = {g: v for g, v in groups.items() if len(v) > 1}
json.dump(summary, open(f"{OUT}/data/split_summary.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(json.dumps(summary, ensure_ascii=False, indent=1))
