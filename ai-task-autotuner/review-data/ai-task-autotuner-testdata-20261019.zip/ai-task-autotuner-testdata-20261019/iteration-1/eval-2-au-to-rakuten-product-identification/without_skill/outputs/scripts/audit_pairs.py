"""Audit pair-label quality without any model call. Usage: python3 -I audit_pairs.py IN_DIR OUT_JSON"""
import json, sys, re, unicodedata, collections
IN, OUTJ = sys.argv[1], sys.argv[2]
rows = [json.loads(l) for l in open(f"{IN}/inputs/products.jsonl", encoding="utf-8")]

def norm(s):
    s = unicodedata.normalize("NFKC", s or "").lower()
    return re.sub(r"\s+", "", s)

def bigrams(s):
    s = norm(s)
    return {s[i:i+2] for i in range(len(s)-1)}

def jac(a, b):
    return len(a & b) / len(a | b) if a and b else 0.0

def sku_vals(side):
    vals = set()
    for s in side["skus"]:
        for c in s["conditions"]:
            vals.add(norm(c.get("value", "")))
    return vals

def codes(text):
    t = unicodedata.normalize("NFKC", text)
    jan = set(re.findall(r"(?<!\d)(4[59]\d{11})(?!\d)", t))
    model = {m.lower() for m in re.findall(r"\b([A-Za-z]{1,5}-?\d{3,6}[A-Za-z0-9-]*)\b", t)}
    return jan, model

def side_text(side):
    parts = [side["title"], side["description"].get("text") or ""]
    for s in side["skus"]:
        for a in s.get("auxiliary_attributes", []) or []:
            parts.append(str(a.get("value")))
    return "\n".join(parts)

def lines(side):
    return {norm(l["text"]) for l in side["description"].get("lines", []) if len(norm(l["text"])) >= 6}

out = []
for r in rows:
    R, A = r["rakuten"], r["au"]
    rj, rm = codes(side_text(R)); aj, am = codes(side_text(A))
    rec = dict(
        id=r["product_pair_id"], r_url=R["url"], a_url=A["url"],
        r_title=R["title"], a_title=A["title"],
        title_bigram_jac=round(jac(bigrams(R["title"]), bigrams(A["title"])), 3),
        sku_value_jac=round(jac(sku_vals(R), sku_vals(A)), 3),
        desc_line_jac=round(jac(lines(R), lines(A)), 3),
        shared_jan=sorted(rj & aj), r_jan=len(rj), a_jan=len(aj),
        shared_model=sorted(rm & am)[:10],
        r_skus=len(R["skus"]), a_skus=len(A["skus"]),
        r_desc_mode=R["description"]["mode"], a_desc_mode=A["description"]["mode"],
    )
    rec["score"] = round(rec["title_bigram_jac"] + rec["sku_value_jac"] + rec["desc_line_jac"] + (1 if rec["shared_jan"] else 0) + (0.5 if rec["shared_model"] else 0), 3)
    out.append(rec)
out.sort(key=lambda x: x["score"])
json.dump(out, open(OUTJ, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
for x in out[:40]:
    print(x["score"], x["id"], "tj", x["title_bigram_jac"], "sj", x["sku_value_jac"], "dj", x["desc_line_jac"], "jan", x["shared_jan"][:2], "mdl", x["shared_model"][:3])
    print("   R:", x["r_title"][:110]); print("   A:", x["a_title"][:110])
