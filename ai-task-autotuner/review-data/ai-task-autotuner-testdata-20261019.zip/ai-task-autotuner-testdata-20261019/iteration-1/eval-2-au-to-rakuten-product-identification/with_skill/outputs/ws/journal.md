# Journal

Concise English. One block per experiment; rewrite Learnings as they change.

## Learnings (max ~20 bullets; what is true about this task and model)
- Baseline Haiku errors are mostly false accepts on 'removed' queries (picks a sibling listing); in ~half its own 'why' names the mismatch -> choice-before-reasoning was the root cause.
- Reasoning-first JSON (compare, then choice) fixed it: 0.881 -> 0.968 pooled; run-to-run flips 11 -> 2.
- Remaining dev errors (~5): partner offers a subset of au variants (false none x3), LAD WEATHER inner siblings (gender/neckline).
- No-model rule (sim+margin threshold, dev-tuned) = 0.827; exact option-set equality + top similarity decides ~18% of dev queries with 0 errors.
- claude -p caches the whole prompt: an identical rerun costs ~1/6 (cold $0.19 vs warm $0.03 per dev run) -> compare cost on cold runs / uncached list price.
- Empty-text replies (CLI, after ~170 thinking tokens) happened 2-3x per baseline run; 0 with reasoning-first.

## Idea backlog (group: idea - evidence - status)
- prompt.instructions: variant lists may overlap partially (3 false none) - E004
- deterministic.pre: exact option-set shortcut (28/156 dev decided, 0 wrong) - efficiency
- input.selection: shorter descriptions (input side ~70% of cost) - efficiency
- output.format: shorter compare field - efficiency
- harness.parsing: retry once on empty reply - only if failures return

## Log

2026-10-18 audit: gate REVIEW (suspected-mispairs: 7f04455a83ac52c8 clear, 7fa1c1f5f6ac2ec6+affeea04e64fe893 likely,
  12f3057cc81c6d73 doubtful). Pool 146 unique Rakuten listings; title+axes retrieval puts partner at rank<=3 for 152/152,
  rule top-1 143/152. Plan: present+removed query per au product (304). Waiting for user's label-policy answer.

2026-10-18 15:50Z resume after quota outage (r2 void, moved to runs_void/); clock: 10 min used, deadline 17:40Z; concurrency 6.
E001 baseline (c000): r1 0.872, r2b 0.891; min_delta 0.0425 (11 flips). Validation passed (eval 91410e1a).
E002 deterministic.pre (r000-rule): 0.827 DISCARD; no-model reference point (dev-tuned thresholds).
E003 output.format (c001-reason-first <- c000): compare field before choice
  expect +0.03..0.06 | got 0.962/0.974 pooled 0.968 (+20/-2) KEEP | cold cost x1.06
  why: model's reasoning now gates the pick; false accepts 17 -> 2-3; parse failures 0
E004 prompt.instructions (c002-variant-overlap <- c001): partial variant overlap = same
  expect +0.01..0.02 | got 0.962: present 0.987 (+), none 0.936 (-), false accepts 6 -> DISCARD (guard)
  why: relaxing variant strictness trades false 'none' for sibling false accepts; quality headroom 0.032 < min_delta -> switched to efficiency phase (floor 0.94), efficiency metric = uncached list cost (CLI caches whole prompts).
E005 deterministic.pre (c003-rule-shortcut <- c001): exact option-set + top-sim>=0.4 decided by code
  expect -15..-20% | got 0.968 both runs, 28/156 rule-decided (0 wrong), -16% KEEP
E006 deterministic.pre (c005-top4 <- c003): prune to top-4 similar candidates before the model
  expect -30..-40% | got 0.955/0.949 (pooled 0.952, false acc 0.029), -27% KEEP (rule; quality -1.6pt within noise)
E007 input.selection (c006-top4-shortdesc <- c005): excerpts 300/120 chars
  expect -15..-25% | got 0.962/0.962, -13% KEEP; best uncached $0.058 per 156 queries
E008 simplify.ablation (c007-no-desc <- c006): no description text at all
  expect -15..-25% | got 0.942/0.942 (deterministic; -3 items vs c006, all present-side), -14% KEEP by rule (floor 0.94)
  why: titles+options carry most identity evidence; descriptions rescue 3 present queries. Floor creep: c003 0.968 -> c007 0.942 via 3 rule-keeps.
STOP 16:15Z: efficiency plateau by projection (<10% per remaining lever). Finalize: holdout c000, c007 (ledger best), c006 (accuracy alternative).
FINALIZE: holdout (142 scored) c000 0.909 / c007 0.951 / c006 0.958; c000->c007 +0.042 [0.000,0.085] (+8/-2); FA 0.063 -> 0.028.
  c007 dev x3: 0.942/0.942/0.955, pass^3 0.929, 4 flaky. Full 304 (warm): 0.946 (298 scored), 55 rule-decided.
  Excluded 6 (suspected mispairs): c007 answered none on all 6, incl. the 3 'present' ones -> supports the audit.
2026-10-18 23:26Z resumed after second outage (16:24-23:26Z, booked with clock resume --gap); deliverables exported, report/task_design written (0.8h active, $1.58 CLI-reported in runs/).
