# Data audit - au -> Rakuten product identification (2026-10-18)

Task under audit: input = one au PAY market product; candidates = several Rakuten products;
output = the Rakuten candidate that is the same product, or "none". Reference = the dataset's
product-pair correspondence (the user allowed it as ground truth). Model calls: none yet
(only `llm_call.py --calibrate`, no data sent).

## Inputs

| file | size | records | what one unit is |
|---|---|---|---|
| `sku-normal-v1/inputs/products.jsonl` | 4,162,677 B | 152 pairs | one au product + its paired Rakuten product (titles, URLs, all SKUs, axes, descriptions) |
| `packets/*.json` | 152 files | same 152 | duplicate representation of the JSONL - not used (README: do not run both) |
| `source_records/provenance.jsonl` | 152 | - | read only for pair provenance (not a model input) |
| `au_only_stress/` | 58 au products | - | load-test only, no Rakuten correspondence - out of scope |

sha256 of the JSONL is recorded by `quality_gate.py` (`audit/quality_gate.json`).
Profile: `audit/profile.md`. Computed checks: `audit/checks.py`.

## Stated by the user / README (known limitations)

- Pairs are legacy candidate correspondences, not human-verified for product identity
  (`pair_identity_human_verified=false` for 152/152; status `primary_image_token_mapping_review`).
  The user explicitly allowed using the pair correspondence as the answer key.
- Data was used in past development/evaluation (TRAIN72/EVAL80) - not an independent benchmark.
- Description text unavailable: Rakuten 10, au 1.
- beauty/apparel/food are collection-folder names, not product categories (confirmed: down coats sit in "food").

## Findings

| id | severity | finding | evidence | impact | recommendation |
|---|---|---|---|---|---|
| suspected-mispairs | **high** | 3 pairs in the answer key look like different products (1 clear, 2 likely) + 1 doubtful | `raw-7f04455a83ac52c8`: au "ACTLEG インパクト ふくらはぎサポーター" (12 colours, S/M/L) paired with Rakuten legstyle/act-01 "Actcyc ALLCOVER TIGHTS 10分丈" (6 colours, XS-XL); act-01 is also paired, correctly, with au 745560482 (identical title/axes). `raw-7fa1c1f5f6ac2ec6` + `raw-affeea04e64fe893` (byte-identical au copies): au "3way ショルダーバッグ/リュック/トート" colours A01-A03, small (長財布/iPad mini) vs Rakuten swissgem/47aug25sb01 "大容量リュックサック" ブラック/ホワイト 30x13x43cm. Doubtful: `raw-12f3057cc81c6d73` (au title says タンクトップ, au body/colour values match the Rakuten 綿100% インナー 2枚組). Computed flags (title, SKU values, description all < 0.2 Jaccard): 4 pairs, 3 of them the above, 1 (`raw-334374f11fbe2166`, LAD WEATHER gloves) judged plausible on close-read | if used as-is, a model that correctly answers "none" (or rejects the wrong candidate) on these is scored wrong: 3 units = 2.0% of units, 6 of 304 planned queries; the dev/holdout noise floor is of the same order, so this can flip keep/discard decisions | user decides: (A) keep as-is, (B) exclude the 3 (or 4) from accuracy denominators and report them separately, (C) have them checked and relabel |
| pairs-not-human-verified | high (known) | 152/152 pairs unverified | provenance.jsonl | results are "agreement with the pair list", not accuracy against gold | stated by README; user allowed it |
| shared-rakuten-listing | medium | 6 Rakuten listings are each the partner of 2 au products (12 pairs) -> 146 unique Rakuten listings | three-peace/k14006, wilmart/dsc88 (Galaxy S25 + S25 Ultra au listings), legstyle/act-01 (incl. the mispair), three-peace/k15029, swissgem/47aug25sb01, wilmart/dsh88-m (AQUOS wish4 + R9) | many-to-one is legitimate for au->Rakuten; pool must be de-duplicated | candidate pool = 146 unique listings; group_of = Rakuten URL |
| duplicate-au-inputs | medium | 2 groups of byte-identical au listings under different au ids | [6f8fde18946a343a, dee9faa315079124] cushion foundation; [7fa1c1f5f6ac2ec6, affeea04e64fe893] bag | the same input is scored twice | keep both (distinct listings), same split, also report a de-duplicated metric |
| negatives-unlabelled | medium | "different product" is inferred from the pair list; 13 same-shop Rakuten listing pairs with title similarity >= 0.6 | Kanken 16L in 3 colour listings, びわの種 1kg vs 2kg, Mode Tokimi pumps x3 (heel/width), curvys stoles t21040 vs ts21040 (different colour lists), K10 rings 0.02ct/0.1ct, LAD WEATHER cooling inner tights vs shirt, glorypark dresses 花柄 vs ジャガード | these are the real difficulty of the task; close-read found each distinguishable by SKU values or title specs | keep as hard negatives; report a "near-duplicate family" stratum |
| no-natural-none-cases | medium | every one of the 152 au products has a partner; au_only_stress has no checked correspondence and README forbids mixing it | README | "none" queries must be constructed | build them by removing the partner listing from the candidate set; say so in the report |
| reused-data | medium (known) | used in past development | README | no independence claim | report |
| description-unavailable | low (known) | Rakuten 10, au 1 | profile | less evidence for those units | stratum in report |
| trivial-baseline | info | title char-bigram nearest neighbour over the 146 listings: top-1 = 139/152; Rakuten item code appears in the au record for 64/152 pairs | checks.py | a rule solves most "partner present" queries; the LLM has to earn its place on "none" and near-duplicate families | measure the rule baseline next to the LLM |
| promo-in-titles | info | price/promotion words in titles: au 34, Rakuten 76 | checks.py | they differ across sites | rule in prompt: price/promotion is not identity evidence |
| injection-scan | info | 0 injection-like phrases | checks.py | - | prompts still mark data as untrusted |
| compact-candidate-size | info | Rakuten title+axis values median 164 chars, max 518; descriptions up to 2,636 chars | checks.py | 8 compact candidates fit easily; Haiku 5.5 list price $0.10/M input | cost is not the binding limit ($3) |

## Difficulty and strata

- Rakuten listing covers several phone models while the au listing covers one: 9 pairs
  (Galaxy S25/Ultra, AQUOS, iPhone 16 series, Pixel) - "same product" = the Rakuten listing that sells the au item.
- Different axis count between sides: 36 pairs; different SKU count: 43 pairs.
- Shop concentration: wilmart 44 pairs (phone cases, shoes, rings, soap-flower gifts), emix 23 (LAD WEATHER apparel), glorypark 16 (dresses).
- Near-duplicate Rakuten families (13 listing pairs, above) - the hard negatives.
- Title similarity of the true pair: 139/152 rank first among 146 listings; the rest are mostly phone cases where several wilmart listings share wording.

## Close-read sample (about 25 pairs, all buckets)

Read: naris lotion (identical titles), Actcyc/ACTLEG, cushion foundations (2 au -> 1 Rakuten; SPF50 vs SPF30 sibling), 3way bag x2,
tank top/inner, たこスライス 250g x2 (same), LAD WEATHER gloves, curvys stoles x3, Kanken x3, glorypark dresses x2,
cooling inner x2, びわの種 1kg/2kg, all 40 wilmart titles (phone cases, pumps, rings, gift sets), 25 food/beauty pairs with lower title similarity.
Easy: same seller, near-identical titles and axis values. Hard: one seller's sibling listings that differ only in
colour list, capacity, heel height, model; au titles written differently from Rakuten titles (keyword-stuffed);
Rakuten multi-model listings. Defects: the 3 suspected mispairs above; one au listing whose title contradicts its body.

## Trivial-solution check

Nearest-neighbour by title solves 139/152 "partner present" queries, but has no principled "none" decision:
with the partner removed it will always propose a sibling. LLM optimisation is worth it only if the evaluation
includes "partner removed" queries and the near-duplicate families; the plan does both and keeps the rule as a baseline.

## Scope

- In scope: 152 pairs from `inputs/products.jsonl` (146 unique Rakuten listings as the candidate pool).
- Excluded: `packets/` (duplicate representation), `au_only_stress/` (no correspondence; README forbids).
- Pending user decision: whether the 3 suspected mispairs (and the 1 doubtful pair) count in accuracy denominators.

## Gate

**REVIEW** - one unknown high finding (`suspected-mispairs`): the answer key contains pairs that appear to be
different products. The user allowed the pair list as ground truth, but asked to be told about data problems before
work starts, and how to treat these items is a label-policy decision. No experiment runs until the user answers.
