# Eval spec - au -> Rakuten product identification

## Task definition
Input: one au PAY market listing (title, option axes and values, description text) and 8 Rakuten
candidate listings (title, URL, option axes and values, description text) with neutral ids C1..C8.
Output: `{"choice": "C<n>" | "none"}`.
"Same product" = the Rakuten listing that sells the au item (same type, model/design, material,
capacity/quantity, set contents). A Rakuten listing that offers more variants (more colours or
compatible phone models) counts if it includes what the au listing sells. Price/promotion/shipping
text is not identity evidence. This is the definition implied by the pair list (e.g. Galaxy S25 au
listing <-> Rakuten S25/S25 Ultra listing).

## Derived test data (eval/dataset.py, frozen)
- Pool: 146 unique Rakuten listings (152 pairs; 6 listings are partners of 2 au listings).
- Candidate generator: char-bigram Jaccard of (title + all option values), top 8. Measured recall:
  partner rank <= 3 for 152/152 au listings (recall@8 = 100%).
- Per au listing two queries: `present` (partner among the 8) and `removed` (partner taken out of
  the pool, next 8; answer "none"). 304 queries; 50% "none" by construction.
- Candidate order shuffled with a seed from the query id; ids C1..C8.
- The answer key is not in the unit input; score.py reads it via dataset.answer_of().
- Constructed queries are exported to `data_built/` at finalize.

## Reference
Tier: unverified pair correspondence (README: legacy candidate mapping, not human-verified;
user allowed it as ground truth). Numbers are "agreement with the pair list", not accuracy.
User decision (REVIEW option B, 2026-10-18): the 3 suspected mispairs raw-7f04455a83ac52c8,
raw-7fa1c1f5f6ac2ec6, raw-affeea04e64fe893 (6 queries) are run but excluded from all
denominators; reported separately in score.json["excluded"]. raw-12f3057cc81c6d73 (doubtful) is
scored and tagged `doubtful`. Unlabelled positives: close reading found no non-partner candidate
that is the same product; sibling listings differ in colour list, capacity, model or design.

## Metrics
- Primary: correct decisions / scored queries.
- Guards: false_accept_rate (wrong listing chosen on any query) may not rise > 0.02 above the
  best; failed_rate (no parseable valid answer) <= 0.03.
- Diagnostics: present_acc, none_acc, pick_precision, family_acc (queries whose partner belongs to
  a same-shop near-duplicate family), tags: false_none, wrong_pick, false_accept_removed, failed.
- Hard gate: a choice outside {C1..C8, none} (pipelines raise instead, so it is scored as failed).
- Failed units are scored wrong, never dropped.

## Splits (eval/splits.json)
Group = union-find over partner listings (shared partner or same-shop near-duplicate title,
Jaccard >= 0.6), so a product family never straddles dev/holdout; both query variants share
the group. Balanced per shop stratum (wilmart / emix / glorypark / other), seed 0.
dev 156 queries (72 groups), holdout 148 queries (63 groups; contains the 6 excluded queries),
full 304, smoke = first 6 dev queries.

## Baselines
- trivial (score.trivial): always the most similar candidate -> dev 0.48 (never "none").
- r000-rule (no model): most similar candidate if sim >= 0.26 and margin >= 0.08, else none;
  thresholds grid-searched on dev (optimistic on dev).

## Noise
From two baseline runs (validate_eval.py) -> charter.noise / min_delta.
