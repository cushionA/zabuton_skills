# Skill feedback - ai-task-autotuner (eval-2: au -> Rakuten product identification)

Run outcome: Phase 1 audit completed. `quality_gate.py` returned REVIEW because 3 pairs in the answer key
look like different products. I stopped there, as SKILL.md and the user ("データに問題があれば動く前に報告して")
both asked. No model calls with data were made; the only calls were the `--calibrate` pings.

## What was unclear, wrong, missing or wasteful

1. **`profile.md` hid the most important duplicate signal.** `profile_data.py ... --out WS/audit/profile`
   wrote 86 lines and ended the products.jsonl table with `| ... 8 more paths in the .json |`. One of the
   truncated paths was `rakuten.url`: `distinct 146 / 152, dup_values 6, records_sharing_value 12`. That is
   the many-to-one structure that defines `group_of` and the candidate pool, and it only exists in
   `profile.json`. I found it with my own script.
   Suggestion: never truncate paths that have `dup_values > 0` or are `KEY?` candidates, or truncate by
   "least interesting" (no dups, no nulls) instead of by position.

2. **`ledger.py status` ignores the quality gate.** With `audit/quality_gate.json` at REVIEW and no waiver,
   `ledger.py status ws --write` printed `RECOMMEND BASELINE: propose lever=baseline, run it twice ...`, and the
   same text went to STATE.md. A resumed session that "follows RECOMMEND" (as SKILL.md tells it to) would try
   to run. `run_experiment.py` refuses later, but the recommendation is wrong.
   Suggestion: status should read the gate and print `GATE REVIEW (no waiver)` and `RECOMMEND WAIT_USER`.

3. **The hours limit keeps counting while the run waits for the user.** `LIMITS ... hours 0.1/2.0` is measured
   from `charter.created_epoch` (set by `init_workspace.py`). The user's "2 hours" plausibly means working
   time, but the clock keeps running across the REVIEW wait. If the user answers the next day, the limit is
   already used up.
   Suggestion: record a gate wait (pause/resume events), or count active time; document it in loop.md.

4. **SKILL.md is ambiguous about how much work to do past a REVIEW.** "REVIEW/STOP: send the user the findings
   ... and stop" vs. the Phase 2 outputs. I drafted `experiment_plan.md` (marked DRAFT, nothing frozen, no
   model calls) because the label-policy options only make sense once the query design (present/removed
   queries) is known. It is not clear whether that is intended or overreach.
   Suggestion: say explicitly "design notes that inform the user's decision are fine; do not freeze eval
   files or call the model".

5. **Setup ordering contradicts a ground rule.** Setup runs `llm_call.py --calibrate` before Phase 1, while the
   ground rules say "Audit the data before any model call". Calibration sends no data, so this is harmless,
   but the wording invites second-guessing.
   Suggestion: "calibrate (no data) may run any time; data-bearing calls only after the gate".

6. **There is no guidance for deriving a selection task from pair data.** The user's task (pick the same
   product among candidates, or "none") has no labels in the shape the templates expect. The reference has
   to be derived: build candidate sets from the pair list, make "none" queries by removing the partner, and
   de-duplicate the candidate pool. `evaluation.md` has only a one-row metric entry ("Retrieval / selection
   among candidates"). Several things were missing:
   - how to construct negatives and "none" items from positive-only pairs;
   - the risk of **unlabelled negatives**: a non-partner candidate might also be the same product. Here I had
     to check 13 near-duplicate same-shop listing pairs by hand;
   - measuring retrieval recall@K of the candidate generator. Here title+axes retrieval gave rank <= 3 for
     152/152, so K=8 is safe;
   - the fact that one unit can yield two items ("present" and "removed"), which doubles n and balances the
     classes.
   A short "pairs -> selection task" recipe in task-design.md or evaluation.md would save time and prevent
   leaky designs.

7. **"Known" vs. new evidence about an accepted limitation.** The user said the pair list may be used as
   ground truth. The README says pairs are unverified. That makes `pairs-not-human-verified` known, but the
   concrete mispairs I found are new evidence the user did not know about. audit.md does not cover this
   case. I made them a separate unknown `high` finding, which produced REVIEW.
   Suggestion: add one line: "a user's general acceptance of a limitation does not cover specific defects
   found later; report them".

8. **There is no place for close-read verdicts.** The checks.py template says "Compute every number here; do
   not eyeball", but step 4 of audit.md is a close-read whose verdicts ("clear mispair", "plausible") are
   judgments. I embedded a `CLOSE_READ` dict in `checks.py` and cross-checked it against computed low-signal
   flags (title/SKU-value/description Jaccard < 0.2). It works, but it is ad hoc.
   Suggestion: a standard `audit/close_read.jsonl` (id, verdict, evidence) that `quality_gate.py` folds into
   findings.

9. **`checks.py` cannot reach auxiliary data cleanly.** The provenance file (`source_records/provenance.jsonl`)
   is not a pipeline input, so it is not in `charter.data.inputs`. I used `ctx.inputs[0].parent.parent`. That
   is fragile, and the gate's data hashes do not cover the file.
   Suggestion: `charter.data.aux_inputs` (hashed, readable through `ctx.aux`).

10. **There is no fallback when subagents are unavailable.** SKILL.md and loop.md send bulk reading to a
    subagent, but this environment had no Agent/Task tool. I instead printed compact one-line-per-pair views
    (titles cut to 55-75 chars plus axis counts) and read about 25 pairs plus all 40 wilmart titles.
    Suggestion: one sentence of fallback guidance (compact tabular views, capped widths).

11. **Template placeholders still need many edits for multi-entity records.** `dataset.py` defaults
    `ID_FIELD = "id"` (the field here is `product_pair_id`), and `score.py` assumes `{"items": [{"key",
    "label"}]}` with references in `eval/reference/`. Nothing went wrong, because I never reached Phase 3.
    The template comments could mention the "units derived from records" case: one record producing several
    queries, with `group_of` shared.

## What helped

- **The trivial-solution check in audit.md.** It produced the decisive design insight. Title char-bigram
  nearest neighbour gives top-1 = 139/152 (title+axes: 143/152), so without "none" queries and near-duplicate
  families the LLM would add little. That led to the "present + removed" query design.
- **The quality-gate mechanics.** Exit codes, `known` handling, recorded input hashes, and the rule that
  `run_experiment.py` refuses without a waiver. These made the stop unambiguous and reproducible.
- **`llm_call.py --calibrate`.** Its output was clear: about 806 input-side tokens of overhead, 0.6-0.9 s
  `api_ms`, served `claude-haiku-5-5`. With `common.PRICES`, it showed quickly that $3 is not the binding
  limit and time is.
- **The audit severity table and the data_audit.md template.** Both mapped cleanly onto this dataset.
- **The "never rewrite labels / only the user can accept REVIEW" rules.** They removed any temptation to
  quietly drop the ACTLEG pair.

---

# Part 2 - after the user accepted REVIEW (option B): eval, loop, finalize (incl. the mid-run skill update)

Outcome:
- Dev and holdout: holdout baseline 0.909 -> final 0.951 agreement with the pair list (142 scored queries); false-accept rate 0.063 -> 0.028.
- Final pipeline: code shortcut + top-4 pruning + Haiku with reasoning-first JSON.
- Experiments: 8. Total CLI-reported cost $1.60 of $3. About 0.8 h of the 2 h active time used.
- Two quota outages: about 10:52-15:49Z and 16:24-23:26Z.

## Bugs / wrong behaviour

1. **`common.make_splits` breaks stratification.** It interleaves groups round-robin across strata, then fills dev
   first. A small stratum is therefore used up early and lands entirely in dev. With 4 shop strata, 304 queries
   and dev=152, holdout=152, the first split was: glorypark 32 dev / 0 holdout, emix 36 / 10. I replaced it in
   `eval/dataset.py` with a per-stratum balance (each group goes to the split with fewer units of that stratum),
   which gave glorypark 18/14 and emix 24/22. Suggest: assign alternately per stratum, or fill dev and holdout in
   proportion.
2. **A quota-killed run was pooled by the ledger.** The pre-update runner turned quota exhaustion into
   `harness_error` on 80/156 units and kept going. `ledger._exp_runs` pools every run of an experiment, so that
   void run would have been averaged into E001. I moved it to `runs_void/` by hand. The new runner's circuit
   breaker helps, but `_exp_runs` should still skip runs with `quota_exhausted` or a harness rate above the void
   threshold. Alternatively, add `ledger.py void RUN --reason`.
3. **`export_deliverables.py` writes a false claim.** It writes `"effort": {"why": "as measured; lower effort was
   tested"}`, but no lower effort was tested ("low" is the lowest). The report has to correct it. Other problems:
   - `cost_usd_per_unit_measured` averages a warm full run with a cold holdout run ($0.000255 vs cold $0.00050),
     which is not a usable production estimate.
   - `eval_kit/dataset.py` and `score.py` load `WS/charter.json` via `parents[1]`, so the exported eval kit does
     not run outside the WS.
   - `testset/reference/` is copied as an empty directory when the answers are built in code.
4. **The Write tool hook blocked `WS/report.md`.** The message was "Subagents should return findings as text, not
   write report files", but the skill (and the coordinator) require `report.md` as a deliverable. I wrote it with
   a Bash heredoc. The skill and the harness disagree here. Consider naming the file e.g.
   `deliverables/final_report.md`, or documenting the conflict.
5. **`ledger.py history` mixes metrics in the `eff` column** after the efficiency metric changes mid-run (E001-E004
   show cost_usd_per_unit, E005+ show cost_uncached_list_usd). Print the metric name per row.

## Measurement design issues the skill should address

6. **`claude -p` caches the whole prompt, not just the prefix.** An identical rerun costs about 1/6 of the cold run
   (E003: $0.191 cold vs $0.031 warm, cache_read 842K). The ledger pools `cost_usd_per_unit` over cold and warm
   runs, so an incumbent with a repeat looks about 40% cheaper than any new single-run candidate. Every "rerun"
   makes this worse. I switched `efficiency_metric` to `cost_uncached_list_usd`, which is fine only because dev
   size is constant. Suggest: add `cost_uncached_list_usd_per_unit` to the summary and make it the default
   efficiency metric for the cli backend. Also note in backends.md that warm reruns also change latency.
7. **The "near floor" rerun fires on every efficiency candidate.** I set the floor to 0.94 (best 0.968, min_delta
   0.0425), so every candidate is "within min_delta of the floor". E005, E006, E007 and E008 all came back RERUN
   and needed a second run (cheap only because of the full-prompt cache). Suggest: "near floor" should use the
   incumbent's measured noise, not the baseline min_delta.
8. **Floor creep.** Four efficiency keeps, each legal, took dev primary from 0.968 (c003) to 0.942 (c007). Holdout
   later showed c006 vs c007 differ by 1 item, so it was harmless here, but nothing in `status` shows the
   cumulative drop. Suggest: print "primary drop since phase switch: -0.026" and warn when it exceeds one
   min_delta.
9. **min_delta should be re-measured once the candidate stabilises.** The baseline flipped 11/156 items between
   identical runs (min_delta 0.0425). After the reasoning-first fix the incumbent flipped only 2. Because
   min_delta stays at 0.0425, any remaining quality headroom (0.032) is "undetectable" and I had to switch phase.
   Suggest: offer `validate_eval.py --renoise RUN_A RUN_B` on the incumbent at phase switch.
10. **Holdout cap vs. the no-model baseline.** With 3 peeks I had to choose among baseline, final, the accuracy
    alternative (c006) and the no-model rule. I dropped the rule, so "what code alone achieves" is dev-only and
    dev-tuned. Zero-call candidates could reasonably get one extra peek.
11. **Empty `claude -p` replies.** 2-3 calls per baseline run returned `text=''` with `stop_reason=end_turn`,
    ~170 thinking tokens and ~80 output tokens. llm_call classifies this as `parse`, which is a non-retried system
    error. A manual re-call of the same prompt succeeded. Suggest: treat empty text as retryable once and tag it.
    This disappeared entirely with the reasoning-first output format.

## About the mid-run skill update

12. **Re-reading the updated skill mid-run was smooth.** These were directly useful: the new task-design recipe
    (present/removed queries, lookalikes, recall@K, data_built/), the code-first emphasis, the NO-LLM status line
    and `export_deliverables.py`.
13. **There is no migration path for an already-accepted gate.** Re-running the new `quality_gate.py` would have
    regenerated REVIEW and dropped the user's waiver. I kept the accepted gate and only added
    `audit/close_read.jsonl` and `data.aux`, so `data.aux` is not hashed in the gate. Suggest: `quality_gate.py
    --refresh` that keeps the waiver when the set of blocking finding ids is unchanged.
14. **The clock and the deadline.**
    - First outage (before the clock feature existed): I had to fake it by moving `charter.created_epoch`.
    - Second outage: `ledger.py clock WS resume --gap` worked well ("recorded outage since 16:24").
    - `limits.deadline` is wall-clock and does not move with pauses, so after each outage I had to edit it by hand
      (otherwise the ledger reports "deadline passed"). Suggest: derive a deadline from active hours, or have
      `clock resume` shift it.
15. **The concurrency default changed from 8 to 6 after measured candidates existed.** Concurrency lives in the
    candidate's `config.json`, which is part of the candidate hash, so changing it would have made run_experiment
    refuse the edited candidate. `run_experiment.py --concurrency 6` was the right escape hatch; mention it in
    SKILL.md.

## What helped most in Part 2

- **Reading the model's own reasoning field on failures.** The baseline's "why" contradicted its "choice" in about
  half the errors. That led straight to the biggest win (output.format, reasoning before choice: +0.087, flips
  11 -> 2). The loop's "find the root cause" step works when the output carries a short rationale.
- **The rules on guards, decide and phase.** The false-accept guard correctly rejected E004, which traded false
  "none" answers for sibling false accepts. The novelty and diversity bookkeeping stayed out of the way.
- **validate_eval.py.** It caught nothing wrong, but having null/oracle/corrupt/rescore in one command made the
  eval freeze cheap.
