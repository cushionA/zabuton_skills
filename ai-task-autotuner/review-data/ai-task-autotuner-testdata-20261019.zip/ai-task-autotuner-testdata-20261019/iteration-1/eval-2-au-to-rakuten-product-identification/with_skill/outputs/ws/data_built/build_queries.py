"""Export the constructed identification queries (built by eval/dataset.py) to data_built/.

  python data_built/build_queries.py
Writes data_built/queries.jsonl (id, split, input, answer, flags) and data_built/README.md stats.
answer = candidate id of the Rakuten partner (present queries) or "none" (removed queries).
"""
import importlib.util
import json
from collections import Counter
from pathlib import Path

WS = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("ds", WS / "eval" / "dataset.py")
ds = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ds)
splits = json.loads((WS / "eval" / "splits.json").read_text(encoding="utf-8"))
split_of = {i: s for s in ("dev", "holdout") for i in splits[s]}
cnt = Counter()
with open(WS / "data_built" / "queries.jsonl", "w", encoding="utf-8") as f:
    for u in ds.load_units("all"):
        m = ds.meta_of(u["id"])
        row = {"id": u["id"], "split": split_of[u["id"]], "input": u["input"], "answer": ds.answer_of(u["id"]),
               "variant": m["variant"], "excluded_from_scoring": m["excluded"], "doubtful": m["doubtful"],
               "family": m["family"], "multi_model": m["multi_model"], "group": m["group"],
               "candidate_urls": m["cand_urls"]}
        f.write(json.dumps(row, ensure_ascii=False) + "\n")
        cnt[(row["split"], row["variant"], row["excluded_from_scoring"])] += 1
print(dict(cnt))
