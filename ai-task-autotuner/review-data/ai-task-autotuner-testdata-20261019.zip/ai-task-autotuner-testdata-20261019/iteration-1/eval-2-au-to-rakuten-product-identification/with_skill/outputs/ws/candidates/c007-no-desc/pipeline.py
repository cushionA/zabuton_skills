"""c007-no-desc (<- c006): ablation - no description text at all (title, url, options only). c005: code prunes the candidate list to the TOP_K most similar before the model call
(dev: partner similarity rank <= 3 in 78/78 present queries). Otherwise as c003: code decides the clear cases, the model the rest.

Shortcut (deterministic.pre): if the candidate most similar to the au listing (char-bigram Jaccard of
title + all option values, NFKC, whitespace removed) has similarity >= SIM_MIN AND its set of option
values equals the au listing's set exactly AND no other candidate has that exact set, choose it without
a model call. Threshold chosen on dev only (28/156 dev queries decided, 0 wrong). Everything else goes
to the c001 prompt (reasoning-first JSON).
"""
import re
import unicodedata

SIM_MIN = 0.4
TOP_K = 4


def _norm(s):
    return re.sub(r"\s+", "", unicodedata.normalize("NFKC", s or "").lower())


def _bg(s):
    s = _norm(s)
    return {s[i:i + 2] for i in range(len(s) - 1)}


def _rep(x):
    return x["title"] + " " + " ".join(v for a in x["sku_axes"] for v in a["values"])


def _vals(x):
    return frozenset(_norm(v) for a in x["sku_axes"] for v in a["values"])


def shortcut(unit):
    au = unit["input"]["au"]
    cands = unit["input"]["candidates"]
    a, av = _bg(_rep(au)), _vals(au)
    sims = [(len(a & _bg(_rep(c))) / max(1, len(a | _bg(_rep(c)))), c) for c in cands]
    top_sim, top = max(sims, key=lambda t: t[0])
    same = [c for c in cands if _vals(c) == av]
    if top_sim >= SIM_MIN and _vals(top) == av and len(same) == 1:
        return top["cid"]
    return None

AU_DESC = 0
CAND_DESC = 0


def _block(x, desc_chars, head):
    lines = [head, f"title: {x['title']}"]
    if x.get("url"):
        lines.append(f"url: {x['url']}")
    for a in x["sku_axes"]:
        lines.append(f"option {a['name']}: " + " | ".join(a["values"]))
    if desc_chars:
        d = (x.get("description_text") or "").replace("\n", " / ")
        lines.append(f"description: {d[:desc_chars] if d else '(unavailable)'}")
    return "\n".join(lines)


def prune(unit, k=TOP_K):
    """Keep the k candidates most similar to the au listing (original ids and order kept)."""
    au = unit["input"]["au"]
    a = _bg(_rep(au))
    cands = unit["input"]["candidates"]
    ranked = sorted(cands, key=lambda c: -len(a & _bg(_rep(c))) / max(1, len(a | _bg(_rep(c)))))
    keep = {c["cid"] for c in ranked[:k]}
    return [c for c in cands if c["cid"] in keep]


def render(unit, au_desc=AU_DESC, cand_desc=CAND_DESC):
    inp = dict(unit["input"])
    inp["candidates"] = prune(unit)
    parts = [_block(inp["au"], au_desc, "<au_listing>"), "</au_listing>", "", "<rakuten_candidates>"]
    for c in inp["candidates"]:
        parts.append(_block(c, cand_desc, f"[{c['cid']}]"))
        parts.append("")
    parts.append("</rakuten_candidates>")
    return "\n".join(parts)


def run(unit, ctx):
    cid = shortcut(unit)
    if cid is not None:
        ctx.count("rule_decided")
        return {"choice": cid, "why": "rule: exact option-set match + top similarity", "by": "rule"}
    ctx.count("model_decided")
    valid = {c["cid"] for c in prune(unit)} | {"none"}
    user = ctx.prompt("user.txt").replace("{{DATA}}", render(unit))
    r = ctx.llm(user, ctx.prompt("system.txt"), tag="main", expect_json=True)
    if not r["ok"]:
        raise RuntimeError(f"{r['error_kind']}: {r['error']}")
    j = r["json"]
    if not isinstance(j, dict):
        raise ValueError("unparseable model output")
    ch = str(j.get("choice", "")).strip()
    ch = "none" if ch.lower() == "none" else ch
    if ch not in valid:
        raise ValueError(f"invalid choice {ch!r}")
    return {"choice": ch, "why": j.get("compare")}
