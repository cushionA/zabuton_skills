"""c001-reason-first (<- c000): JSON asks for a short comparison BEFORE the choice."""

AU_DESC = 500
CAND_DESC = 300


def _block(x, desc_chars, head):
    lines = [head, f"title: {x['title']}"]
    if x.get("url"):
        lines.append(f"url: {x['url']}")
    for a in x["sku_axes"]:
        lines.append(f"option {a['name']}: " + " | ".join(a["values"]))
    d = (x.get("description_text") or "").replace("\n", " / ")
    lines.append(f"description: {d[:desc_chars] if d else '(unavailable)'}")
    return "\n".join(lines)


def render(unit, au_desc=AU_DESC, cand_desc=CAND_DESC):
    inp = unit["input"]
    parts = [_block(inp["au"], au_desc, "<au_listing>"), "</au_listing>", "", "<rakuten_candidates>"]
    for c in inp["candidates"]:
        parts.append(_block(c, cand_desc, f"[{c['cid']}]"))
        parts.append("")
    parts.append("</rakuten_candidates>")
    return "\n".join(parts)


def run(unit, ctx):
    valid = {c["cid"] for c in unit["input"]["candidates"]} | {"none"}
    user = ctx.prompt("user.txt").replace("{{DATA}}", render(unit))
    r = ctx.llm(user, ctx.prompt("system.txt"), tag="main", expect_json=True)
    if not r["ok"]:
        raise RuntimeError(f"{r['error_kind']}: {r['error']}")
    j = r["json"]
    if not isinstance(j, dict):
        raise ValueError("unparseable model output")
    ch = str(j.get("choice", "")).strip()
    ch = "none" if ch.lower() == "none" else ch
    if ch not in valid:
        raise ValueError(f"invalid choice {ch!r}")
    return {"choice": ch, "why": j.get("compare")}
