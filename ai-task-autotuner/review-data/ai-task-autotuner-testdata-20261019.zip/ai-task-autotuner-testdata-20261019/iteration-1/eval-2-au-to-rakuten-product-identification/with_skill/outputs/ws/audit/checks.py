"""Task-specific data checks: au PAY market product -> identify the same Rakuten product
among several Rakuten candidates (or "none"). Reference = the dataset's product-pair
correspondence (user allowed it as ground truth).

Every number below is computed here from the input files; close-read verdicts (which need
a human/LLM reading of the text) are recorded in CLOSE_READ with their evidence and are
cross-checked against computed signals.
"""
import json
import re
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

# Close-read verdicts (audit step 4). Evidence is quoted from the input records.
CLOSE_READ = {
    "raw-7f04455a83ac52c8": ("clear-mispair",
        "au 495885400 = 'ACTLEG(アクトレグ)インパクト ふくらはぎサポーター' (calf sleeve, 12 colours A-L, S/M/L, code ACTLEG-01); "
        "paired Rakuten legstyle/act-01 = 'Actcyc ALLCOVER TIGHTS 10分丈 着圧レギンス' (6 colours, XS-XL). "
        "act-01 is also (correctly) paired with au 745560482 whose title/axes are identical to it."),
    "raw-7fa1c1f5f6ac2ec6": ("likely-mispair",
        "au 754835715 = '3way ショルダーバッグ/リュック/トート' colours A01/A02/A03, body: 長財布・iPad mini・500mlが入る; "
        "Rakuten swissgem/47aug25sb01 = '大容量 リュックサック 男女兼用' colours ブラック/ホワイト, 30x13x43cm. No shared code."),
    "raw-affeea04e64fe893": ("likely-mispair",
        "au 790224047 is a byte-identical copy (title, axes, description) of au 754835715 above; same Rakuten partner."),
    "raw-12f3057cc81c6d73": ("doubtful",
        "au 759198609 title = 'タンクトップ ... トレーニングウェア' but its body and colour values (ホワイト(Vネック)/(クルーネック)) "
        "describe the Rakuten emix/ladinner070 '綿100% Vネック/クルーネック インナー 2枚組'. Seller title inconsistent; pair plausible."),
    "raw-334374f11fbe2166": ("plausible",
        "flagged by low signals only because Rakuten emix/ladgloves004 description is boilerplate; both are LAD WEATHER "
        "4-layer smartphone-compatible men's winter gloves, M/L/XL."),
}


def _norm(s):
    return re.sub(r"\s+", "", unicodedata.normalize("NFKC", s or "").lower())


def _bigrams(s):
    s = _norm(s)
    return {s[i:i + 2] for i in range(len(s) - 1)}


def _jac(a, b):
    return len(a & b) / max(1, len(a | b))


def _axis_values(side):
    v = set()
    for a in side.get("sku_axes", []):
        for t in a.get("values", []):
            t = _norm(t)
            v.add(t)
            v.update(x for x in re.split(r"[()（）/・×x\[\]★.]+", t) if x)
    return v


def _desc(side):
    d = side.get("description") or {}
    return d.get("text") or ""


def run_checks(ctx):
    out = []
    path = ctx.inputs[0]
    data_dir = path.parent.parent
    recs = [json.loads(line) for line in open(path, encoding="utf-8") if line.strip()]
    n = len(recs)
    out.append(ctx.finding("size", "info", f"{n} au-Rakuten product pairs in {path.name}"))

    # --- schema ---------------------------------------------------------------
    missing = []
    for r in recs:
        for side in ("au", "rakuten"):
            s = r.get(side) or {}
            for f in ("title", "url", "skus", "sku_axes", "description"):
                if f not in s or s[f] in (None, "", []):
                    missing.append(f"{r.get('product_pair_id')}:{side}.{f}")
    if missing:
        out.append(ctx.finding("schema-missing", "critical", f"{len(missing)} required fields missing",
                               evidence=str(missing[:8]), affected=len(missing)))
    ids = Counter(r["product_pair_id"] for r in recs)
    dup_ids = [k for k, c in ids.items() if c > 1]
    if dup_ids:
        out.append(ctx.finding("dup-ids", "critical", f"{len(dup_ids)} duplicated product_pair_id", evidence=str(dup_ids[:5])))
    au_urls = Counter(r["au"]["url"] for r in recs)
    if any(c > 1 for c in au_urls.values()):
        out.append(ctx.finding("dup-au-url", "high", "au URLs repeat across pairs",
                               evidence=str([u for u, c in au_urls.items() if c > 1][:5])))

    # --- reference provenance (stated by README; user allowed pairs as ground truth) ----
    prov_path = data_dir / "source_records" / "provenance.jsonl"
    if prov_path.exists():
        prov = [json.loads(l) for l in open(prov_path, encoding="utf-8") if l.strip()]
        unver = sum(1 for p in prov if not p.get("pair_identity_human_verified"))
        status = Counter(p.get("pair_identity_status") for p in prov)
        out.append(ctx.finding(
            "pairs-not-human-verified", "high",
            f"{unver}/{len(prov)} pairs have pair_identity_human_verified=false; status {dict(status)}",
            evidence="README: '商品ペアは従来の候補対応で、人手で商品同一性やSKU正解を確認したものではありません'",
            affected=unver, known=True,
            recommendation="user allowed pair correspondence as ground truth -> reference tier is 'unverified pair "
                           "correspondence', never 'accuracy against gold'; report as agreement with the pair list"))

    # --- shared Rakuten listings (many au -> one Rakuten) -----------------------------
    by_r = defaultdict(list)
    for r in recs:
        by_r[r["rakuten"]["url"]].append(r["product_pair_id"])
    shared = {u: v for u, v in by_r.items() if len(v) > 1}
    out.append(ctx.finding(
        "shared-rakuten-listing", "medium",
        f"{len(shared)} Rakuten listings are the partner of 2 au products each ({sum(len(v) for v in shared.values())} pairs); "
        f"unique Rakuten listings = {len(by_r)}",
        evidence="; ".join(f"{u.split('/', 3)[3]}<-{v}" for u, v in list(shared.items())[:6]),
        affected=sum(len(v) for v in shared.values()),
        recommendation="candidate pool = unique Rakuten listings; group_of = Rakuten URL so both au queries sit in one split"))

    # --- exact-duplicate au inputs (double counting) ----------------------------------
    sig = defaultdict(list)
    for r in recs:
        a = r["au"]
        key = (_norm(a["title"]), json.dumps(a["sku_axes"], ensure_ascii=False, sort_keys=True),
               (a.get("description") or {}).get("text_sha256"))
        sig[key].append(r["product_pair_id"])
    dup_au = [v for v in sig.values() if len(v) > 1]
    if dup_au:
        out.append(ctx.finding(
            "duplicate-au-inputs", "medium",
            f"{len(dup_au)} groups of byte-identical au listings (same title, axes, description) under different au ids",
            evidence=str(dup_au), affected=sum(len(v) for v in dup_au),
            recommendation="keep both (distinct au listings) but group them in one split; report a deduplicated metric too"))

    # --- pair plausibility signals + close-read verdicts --------------------------------
    flagged = []
    for r in recs:
        a, b = r["au"], r["rakuten"]
        t = _jac(_bigrams(a["title"]), _bigrams(b["title"]))
        v = _jac(_axis_values(a), _axis_values(b))
        da, db = _desc(a), _desc(b)
        d = _jac(_bigrams(da[:3000]), _bigrams(db[:3000])) if da and db else None
        if t < 0.2 and v < 0.2 and (d is None or d < 0.2):
            flagged.append((r["product_pair_id"], round(t, 2), round(v, 2), None if d is None else round(d, 2)))
    verdicts = Counter(CLOSE_READ[p][0] for p in CLOSE_READ)
    bad = [p for p, (k, _) in CLOSE_READ.items() if k in ("clear-mispair", "likely-mispair")]
    out.append(ctx.finding(
        "suspected-mispairs", "high",
        f"{len(bad)} pairs in the reference look like different products ({verdicts['clear-mispair']} clear, "
        f"{verdicts['likely-mispair']} likely), plus {verdicts['doubtful']} doubtful; "
        f"computed low-signal flags (title<0.2, SKU values<0.2, description<0.2): {len(flagged)}",
        evidence="flags=" + str(flagged) + " | close-read: " +
                 " || ".join(f"{p}: {CLOSE_READ[p][0]}: {CLOSE_READ[p][1]}" for p in CLOSE_READ),
        affected=len(bad),
        recommendation="user decides: (A) keep pairs as-is, (B) exclude the suspected pairs from accuracy denominators "
                       "and report them separately, or (C) have them checked and relabel (e.g. as 'none')"))

    # --- negatives are inferred, not labelled; near-duplicate Rakuten families ----------------
    urls = list(by_r)
    titles = {u: next(r["rakuten"]["title"] for r in recs if r["rakuten"]["url"] == u) for u in urls}
    bgs = {u: _bigrams(titles[u]) for u in urls}
    fam = []
    for i in range(len(urls)):
        for j in range(i + 1, len(urls)):
            if urls[i].split("/")[3] == urls[j].split("/")[3]:
                s = _jac(bgs[urls[i]], bgs[urls[j]])
                if s >= 0.6:
                    fam.append((urls[i].split("/", 3)[3], urls[j].split("/", 3)[3], round(s, 2)))
    out.append(ctx.finding(
        "negatives-unlabelled", "medium",
        f"'different product' is inferred from the pair list (no negative labels); {len(fam)} same-shop Rakuten listing "
        f"pairs have title similarity >= 0.6 (variant families split into separate listings)",
        evidence=str(fam),
        recommendation="close-read found these distinguishable by SKU values (colour, 1kg/2kg, neckline, heel height); "
                       "treat as genuine hard negatives, keep them, report the 'near-duplicate family' stratum"))

    # --- trivial-solution check ---------------------------------------------------------------
    top1 = 0
    ranks = Counter()
    for r in recs:
        ab = _bigrams(r["au"]["title"])
        order = sorted(urls, key=lambda u: -_jac(ab, bgs[u]))
        rk = order.index(r["rakuten"]["url"]) + 1
        ranks[min(rk, 9)] += 1
        top1 += rk == 1
    code_hit = 0
    code_unique = 0
    for r in recs:
        blob = json.dumps(r["au"], ensure_ascii=False).lower()
        hits = [u for u in urls if len(u.rstrip("/").split("/")[-1]) >= 5 and u.rstrip("/").split("/")[-1].lower() in blob]
        if r["rakuten"]["url"] in hits:
            code_hit += 1
            code_unique += len(hits) == 1
    out.append(ctx.finding(
        "trivial-baseline", "info",
        f"title char-bigram nearest neighbour over all {len(urls)} Rakuten listings: top-1 = {top1}/{n} "
        f"(rank histogram {dict(sorted(ranks.items()))}); Rakuten item code (URL last path part, >=5 chars) appears "
        f"in the au record for {code_hit}/{n} pairs ({code_unique} uniquely)",
        recommendation="a rule solves most 'match present' queries; the LLM must earn its place on 'none' decisions "
                       "and near-duplicate families -> evaluate both 'with true candidate' and 'true removed' queries, "
                       "and measure the rule baseline"))

    # --- descriptions unavailable (stated) ----------------------------------------------------
    un = Counter((s, (r[s].get("description") or {}).get("mode")) for r in recs for s in ("au", "rakuten"))
    out.append(ctx.finding(
        "description-unavailable", "low",
        f"description unavailable: rakuten {un[('rakuten', 'unavailable')]}, au {un[('au', 'unavailable')]}",
        known=True, affected=un[("rakuten", "unavailable")] + un[("au", "unavailable")]))

    # --- not independent of past development (stated) -----------------------------------------
    out.append(ctx.finding(
        "reused-data", "medium", "data was used in past development/evaluation (original TRAIN72/EVAL80 split)",
        evidence="README: '過去の開発/評価で使われたデータなので、新しい独立評価とは扱えません'", known=True,
        recommendation="report as non-independent; no claims of generalisation beyond this corpus"))

    # --- 'none' queries must be constructed ---------------------------------------------------
    out.append(ctx.finding(
        "no-natural-none-cases", "medium",
        "every au product in the 152 set has a Rakuten partner; au_only_stress (58 au products) has no Rakuten "
        "correspondence checked and README forbids mixing it into accuracy",
        known=False,
        recommendation="build 'none' queries by removing the partner listing from the candidate set; state it"))

    # --- injection-like text ---------------------------------------------------------------
    inj = re.compile(r"ignore (all|previous)|disregard|system prompt|指示に従|無視して|プロンプト", re.I)
    hits = [r["product_pair_id"] for r in recs for s in ("au", "rakuten")
            if inj.search(json.dumps(r[s], ensure_ascii=False))]
    out.append(ctx.finding("injection-scan", "info", f"injection-like phrases found in {len(hits)} records",
                           evidence=str(hits[:5])))

    # --- price / promotion text in titles (must not drive identity) -------------------------
    promo = re.compile(r"クーポン|円|%OFF|％OFF|半額|送料無料|ポイント")
    pa = sum(1 for r in recs if promo.search(r["au"]["title"]))
    pr = sum(1 for r in recs if promo.search(r["rakuten"]["title"]))
    out.append(ctx.finding("promo-in-titles", "info",
                           f"promotion/price words in titles: au {pa}, Rakuten {pr} (differ across sites; not identity)"))

    # --- size / feasibility ------------------------------------------------------------------
    sizes = sorted(len(r["rakuten"]["title"]) + sum(len(v) for a in r["rakuten"]["sku_axes"] for v in a["values"]) for r in recs)
    out.append(ctx.finding("compact-candidate-size", "info",
                           f"Rakuten title+axis values chars per listing: median {sizes[len(sizes) // 2]}, max {sizes[-1]} "
                           f"(full descriptions up to {max(len(_desc(r['rakuten'])) for r in recs)} chars)"))
    return out
