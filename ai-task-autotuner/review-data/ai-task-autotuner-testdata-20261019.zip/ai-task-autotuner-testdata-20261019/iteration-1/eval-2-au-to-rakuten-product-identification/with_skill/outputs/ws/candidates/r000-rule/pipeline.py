"""r000-rule: no-LLM baseline. Pick the candidate with the highest char-bigram Jaccard of
(title + option values) to the au listing; answer "none" unless top >= T and top - second >= M.
T=0.26, M=0.08 were grid-searched on dev only (optimistic for dev)."""
import re
import unicodedata

T, M = 0.26, 0.08


def _bg(s):
    s = re.sub(r"\s+", "", unicodedata.normalize("NFKC", s or "").lower())
    return {s[i:i + 2] for i in range(len(s) - 1)}


def _rep(x):
    return x["title"] + " " + " ".join(v for a in x["sku_axes"] for v in a["values"])


def run(unit, ctx):
    a = _bg(_rep(unit["input"]["au"]))
    s = sorted(((len(a & _bg(_rep(c))) / max(1, len(a | _bg(_rep(c)))), c["cid"]) for c in unit["input"]["candidates"]),
               reverse=True)
    ok = s[0][0] >= T and s[0][0] - s[1][0] >= M
    return {"choice": s[0][1] if ok else "none", "sim": round(s[0][0], 3)}
