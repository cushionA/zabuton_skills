# Experiment plan - au -> Rakuten product identification

Status: written as a draft during the audit; the user accepted REVIEW option B (10:43Z) and the plan was executed.
Deviations from the draft: dev 156 / holdout 148 queries (group- and shop-balanced split, see eval/eval_spec.md);
concurrency 6; guards = false_accept_rate max_increase 0.02 and failed_rate <= 0.03; efficiency metric = uncached list cost.
Outcome: report.md.

## Decision this serves
Whether Haiku (claude -p) can reliably pick the same Rakuten listing for an au listing among look-alike
candidates, and say "none" when the partner is absent - and at what cost/latency per query.

## Problem taxonomy (from the audit)
- Easy: same seller, near-identical title and axis values (most of the 152).
- Hard: sibling listings of one seller that differ only in colour list / capacity / heel height / phone model
  (13 near-duplicate listing pairs); Rakuten multi-model listings vs single-model au listings (9);
  keyword-stuffed au titles that differ from Rakuten wording.
- "None": no natural cases; constructed by removing the partner from the candidate set.

## Query construction (deterministic, frozen in eval/dataset.py)
- Pool: 146 unique Rakuten listings. Retrieval score: char-bigram Jaccard of (title + all axis values).
  Measured: partner rank <= 3 for 152/152 au products; rule top-1 = 143/152.
- For every au product two queries: `present` (top-8 by score, partner included) and `removed`
  (partner excluded, next top-8). 304 queries; candidate order shuffled with a fixed seed; candidates get
  neutral ids (C1..C8). Candidate URLs/item codes: shown as-is (a real system has them; 64/152 au records
  carry the Rakuten item code) - report a stratum split by "item code present".
- Model input per candidate: title, axis names + values, first ~600 chars of description (input.selection
  is a lever to tune later).

## Approaches, ranked
1. Rule only (retrieval top-1 + similarity threshold for "none") - no-LLM baseline, measured on the same queries.
2. Baseline LLM: one Haiku call per query, all 8 compact candidates, JSON `{"choice": "C3"|"none", "reason"}`.
3. Levers in likely order: explicit identity rules (model/capacity/colour-set must agree; price/promo ignored;
   multi-model listing counts if it contains the au model), input representation (axis values as table),
   description selection, verification pass on the chosen candidate (ensemble.verify), rule pre-filter to
   send only ambiguous queries to the model (efficiency phase), effort step.

## Metrics
- Primary: correct-decision rate over all queries (present: partner chosen; removed: "none").
- Guards: false-accept rate (a wrong listing chosen, either query type) - hard cap set after the baseline;
  gate failures (unknown candidate id, unparseable) = wrong.
- Diagnostics: present-recall, none-precision/recall, per stratum (near-duplicate family, multi-model,
  description unavailable, item code present), cost/query, api_ms and wall_ms.

## Splits
Group-aware by Rakuten URL (shared listings, duplicate au inputs and both query variants stay together),
stratified by shop family. Proposed: dev = about half of the au products (~76, ~152 queries), holdout =
the other half (~76, ~152 queries). Noise: about +-0.08 half-width per run on 152 binary queries; paired run-to-run noise
measured with two baseline runs.

## Reference
Tier: unverified pair correspondence (user-approved). Results are "agreement with the pair list".
Treatment of the 3 suspected mispairs + 1 doubtful pair: per the user's REVIEW answer.

## Budget and stop
User limits: $3 total, 2 hours. Haiku 5.5 list price $0.10/M input, $0.50/M output; estimated 3-6K
input tokens per query -> about $0.05-0.10 per 304-query pass with CLI overhead. Time, not money, is the
binding limit: about 10-15 dev runs fit. Holdout at most 3 evaluations.

## Risks
Reference errors (above); constructed "none" queries are easier/harder than real absent cases; data reused
from past development; candidate order/position bias (mitigated by seeded shuffle).
