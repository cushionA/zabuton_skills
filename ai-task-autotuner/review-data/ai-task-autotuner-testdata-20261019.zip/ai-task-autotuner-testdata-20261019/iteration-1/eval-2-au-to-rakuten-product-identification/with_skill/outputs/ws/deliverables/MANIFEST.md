# Deliverables

generated 2026-10-18T23:29:56+0000 from candidate `c007-no-desc`

| path | content |
|---|---|
| pipeline/ | final pipeline code, prompts and config |
| production_config.json | recommended settings with the measurements behind them |
| eval_kit/ | dataset/splits/scorer to re-measure later |
| testset/ | splits, reference answers (see eval_spec.md for provenance), constructed task data |
| task_design.md | |
| report.md | |
| non_ai_findings.md | |
| experiment_plan.md | |
