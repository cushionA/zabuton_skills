"""Units = identification queries derived from the 152 au-Rakuten pairs. Frozen once validated.

For every pair (au product A, Rakuten partner R):
  <pair_id>|present : A + 8 Rakuten candidates = top-8 of the 146 unique Rakuten listings by
                      char-bigram Jaccard of (title + all SKU-axis values); R is always inside
                      (audit: R ranks <= 3 for 152/152).
  <pair_id>|removed : same, but R is removed from the pool first -> correct answer is "none".
Candidates are shuffled with a seed derived from the unit id and get neutral ids C1..C8.
The answer (candidate id or "none") is NOT part of unit["input"]; score.py reads it via answer_of().

group_of: Rakuten partner listings that are near-duplicates within one shop (title Jaccard >= 0.6)
or shared by several au products form one group (union-find), so a product family never
straddles dev/holdout. Strata: shop family (wilmart / emix / glorypark / other).

  python eval/dataset.py --make-splits --dev 152 --holdout 152 --seed 0
"""
import argparse
import hashlib
import json
import random
import re
import sys
import unicodedata
from pathlib import Path

WS = Path(__file__).resolve().parents[1]
CHARTER = json.loads((WS / "charter.json").read_text(encoding="utf-8"))
sys.path.insert(0, str(Path(CHARTER["skill_dir"]) / "scripts"))
from common import make_splits, read_json, write_json  # noqa: E402

K = 8
VARIANTS = ("present", "removed")
# User decision 2026-10-18 (REVIEW option B): run, but exclude from accuracy denominators.
EXCLUDED_PAIRS = {"raw-7f04455a83ac52c8", "raw-7fa1c1f5f6ac2ec6", "raw-affeea04e64fe893"}
DOUBTFUL_PAIRS = {"raw-12f3057cc81c6d73"}
_CACHE = {}


def _norm(s):
    return re.sub(r"\s+", "", unicodedata.normalize("NFKC", s or "").lower())


def _bigrams(s):
    s = _norm(s)
    return {s[i:i + 2] for i in range(len(s) - 1)}


def _jac(a, b):
    return len(a & b) / max(1, len(a | b))


def _rep(side):
    return side["title"] + " " + " ".join(v for a in side["sku_axes"] for v in a["values"])


def _compact(side, with_url=True):
    d = side.get("description") or {}
    out = {"title": side["title"],
           "sku_axes": [{"name": a["name"], "values": a["values"]} for a in side["sku_axes"]],
           "n_skus": len(side.get("skus", [])),
           "description_mode": d.get("mode"),
           "description_text": d.get("text") or ""}
    if with_url:
        out["url"] = side["url"]
    return out


def _build():
    if "units" in _CACHE:
        return _CACHE
    path = CHARTER["data"]["inputs"][0]
    recs = [json.loads(l) for l in open(path, encoding="utf-8") if l.strip()]
    pool = {}
    for r in recs:
        pool.setdefault(r["rakuten"]["url"], r["rakuten"])
    urls = sorted(pool)
    pbg = {u: _bigrams(_rep(pool[u])) for u in urls}
    # groups: union-find over partner listings (shared partner / same-shop near-duplicate titles)
    parent = {u: u for u in urls}

    def find(u):
        while parent[u] != u:
            parent[u] = parent[parent[u]]
            u = parent[u]
        return u
    tbg = {u: _bigrams(pool[u]["title"]) for u in urls}
    for i, u in enumerate(urls):
        for v in urls[i + 1:]:
            if u.split("/")[3] == v.split("/")[3] and _jac(tbg[u], tbg[v]) >= 0.6:
                parent[find(u)] = find(v)
    units, answers, meta = {}, {}, {}
    for r in recs:
        pid = r["product_pair_id"]
        partner = r["rakuten"]["url"]
        abg = _bigrams(_rep(r["au"]))
        ranked = sorted(urls, key=lambda u: (-_jac(abg, pbg[u]), u))
        fam_size = sum(1 for u in urls if find(u) == find(partner))
        for var in VARIANTS:
            uid = f"{pid}|{var}"
            cand = [u for u in ranked if not (var == "removed" and u == partner)][:K]
            rng = random.Random(int(hashlib.sha256(uid.encode()).hexdigest()[:12], 16))
            rng.shuffle(cand)
            cands = []
            ans = "none"
            for i, u in enumerate(cand, 1):
                c = _compact(pool[u])
                c = {"cid": f"C{i}", **c}
                cands.append(c)
                if u == partner:
                    ans = f"C{i}"
            if var == "present":
                assert ans != "none", uid
            units[uid] = {"id": uid, "input": {"au": _compact(r["au"], with_url=False), "candidates": cands}}
            answers[uid] = ans
            shop = partner.split("/")[3]
            meta[uid] = {"pair": pid, "variant": var, "group": find(partner),
                         "stratum": shop if shop in ("wilmart", "emix", "glorypark") else "other",
                         "family": fam_size > 1,
                         "multi_model": any("機種" in a["name"] for a in r["rakuten"]["sku_axes"])
                         and not any("機種" in a["name"] for a in r["au"]["sku_axes"]),
                         "desc_unavailable": "unavailable" in (r["au"]["description"]["mode"], r["rakuten"]["description"]["mode"]),
                         "excluded": pid in EXCLUDED_PAIRS, "doubtful": pid in DOUBTFUL_PAIRS,
                         "cand_urls": [u for u in cand]}
    _CACHE.update(units=units, answers=answers, meta=meta)
    return _CACHE


def load_units(split):
    c = _build()
    if split == "all":
        ids = sorted(c["units"])
    else:
        ids = read_json(WS / "eval" / "splits.json", {})[split]
    return [c["units"][i] for i in ids]


def answer_of(uid):
    return _build()["answers"][uid]


def meta_of(uid):
    return _build()["meta"][uid]


def group_of(unit):
    return meta_of(unit["id"])["group"]


def stratum_of(unit):
    return meta_of(unit["id"])["stratum"]


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--make-splits", action="store_true")
    ap.add_argument("--dev", type=int, required="--make-splits" in sys.argv)
    ap.add_argument("--holdout", type=int, required="--make-splits" in sys.argv)
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()
    if a.make_splits:
        units = load_units("all")
        # common.make_splits fills dev first from a round-robin order, which put every small stratum
        # (glorypark) into dev. Balance per stratum instead: each group goes to the split that has
        # fewer units of that stratum so far (groups shuffled with the seed; never by score).
        rng = random.Random(a.seed)
        g2ids, g2s = {}, {}
        for u in units:
            g2ids.setdefault(group_of(u), []).append(u["id"])
            g2s[group_of(u)] = stratum_of(u)
        sp = {"dev": [], "holdout": [], "rest": []}
        for st in sorted(set(g2s.values())):
            gs = sorted(g for g in g2ids if g2s[g] == st)
            rng.shuffle(gs)
            cnt = {"dev": 0, "holdout": 0}
            for g in gs:
                tgt = "dev" if cnt["dev"] <= cnt["holdout"] else "holdout"
                sp[tgt] += g2ids[g]
                cnt[tgt] += len(g2ids[g])
        sp["full"] = [u["id"] for u in units]
        sp["smoke"] = sp["dev"][:6]
        write_json(WS / "eval" / "splits.json", sp)
        print({k: len(v) for k, v in sp.items()})
