"""Frozen scorer for au -> Rakuten identification queries.

Pipeline output per unit: {"choice": "C1".."C8" | "none", ...}. One item per unit.
Reference = pair list (unverified, user-approved): present -> the partner's cid; removed -> "none".
Units of the 3 suspected mispairs (user option B) are scored separately in score["excluded"] and
are NOT in items/primary. Failed units (output None) are scored wrong, never dropped.

primary            correct decisions / scored items
false_accept_rate  (wrong candidate on present + any candidate on removed) / scored items
present_acc        partner chosen on present queries
none_acc           "none" on removed queries
pick_precision     correct picks / all picks
"""
import importlib.util
import json
import random
from pathlib import Path

WS = Path(__file__).resolve().parents[1]
_spec = importlib.util.spec_from_file_location("ws_dataset_for_score", WS / "eval" / "dataset.py")
ds = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(ds)


def _choice(out):
    if not isinstance(out, dict):
        return None
    c = out.get("choice")
    if isinstance(c, str):
        c = c.strip()
        return "none" if c.lower() == "none" else c
    return None


def score(units, outputs, split):
    items, gate, excluded = [], [], []
    for u in units:
        uid = u["id"]
        m = ds.meta_of(uid)
        ref = ds.answer_of(uid)
        valid = {c["cid"] for c in u["input"]["candidates"]} | {"none"}
        out = outputs.get(uid)
        pred = _choice(out) if out is not None else None
        if out is not None and pred not in valid:
            gate.append(f"{uid}: invalid choice {pred!r}")
        ok = pred == ref
        tags = [m["variant"]]
        if pred is None:
            tags.append("failed")
        elif not ok:
            if m["variant"] == "present":
                tags.append("false_none" if pred == "none" else "wrong_pick")
            else:
                tags.append("false_accept_removed")
        for k in ("family", "multi_model", "desc_unavailable", "doubtful"):
            if m[k]:
                tags.append(k)
        tags.append("shop:" + m["stratum"])
        rec = {"id": uid, "unit": uid, "score": 1.0 if ok else 0.0, "tags": tags, "pred": pred, "ref": ref}
        (excluded if m["excluded"] else items).append(rec)
    n = len(items)

    def rate(pred_fn, sel=lambda i: True):
        s = [i for i in items if sel(i)]
        return (sum(1 for i in s if pred_fn(i)) / len(s)) if s else None
    picks = [i for i in items if i["pred"] not in (None, "none")]
    metrics = {
        "accuracy_vs_pairlist": rate(lambda i: i["score"] == 1.0),
        "false_accept_rate": rate(lambda i: i["pred"] not in (None, "none") and i["score"] == 0.0),
        "present_acc": rate(lambda i: i["score"] == 1.0, lambda i: "present" in i["tags"]),
        "none_acc": rate(lambda i: i["score"] == 1.0, lambda i: "removed" in i["tags"]),
        "pick_precision": (sum(1 for i in picks if i["score"] == 1.0) / len(picks)) if picks else None,
        "failed_rate": rate(lambda i: "failed" in i["tags"]),
        "family_acc": rate(lambda i: i["score"] == 1.0, lambda i: "family" in i["tags"]),
        "n_items": n,
        "n_excluded": len(excluded),
    }
    return {"primary": metrics["accuracy_vs_pairlist"] or 0.0, "metrics": metrics, "items": items,
            "gate_failures": gate, "excluded": excluded}


def oracle(units, split):
    return {u["id"]: {"choice": ds.answer_of(u["id"])} for u in units}


def corrupt(output, rng):
    c = output.get("choice")
    return {"choice": "none" if c != "none" else "C1"}


def trivial(units, split):
    """Rule: pick the candidate with the highest title+axes bigram Jaccard; never 'none'."""
    out = {}
    for u in units:
        a = ds._bigrams(ds._rep(u["input"]["au"]))
        best = max(u["input"]["candidates"], key=lambda c: ds._jac(a, ds._bigrams(ds._rep(c))))
        out[u["id"]] = {"choice": best["cid"]}
    return out


def flatten(unit, output):
    return {unit["id"]: _choice(output)}
