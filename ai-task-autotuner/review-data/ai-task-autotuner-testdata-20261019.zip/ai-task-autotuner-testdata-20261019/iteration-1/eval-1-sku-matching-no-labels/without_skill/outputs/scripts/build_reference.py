# -*- coding: utf-8 -*-
"""Expand reference_spec into per-Rakuten-SKU provisional reference labels (reference/reference_labels.jsonl)."""
import sys, os, json, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *
from reference_spec import R as SPEC


def build_product(r, spec, problems):
    A = r['au']
    ignore_r = set(spec.get('ignore_r', [])) | set(spec.get('ignore_r2', []))
    ignore_a = set(spec.get('ignore_a', []))
    au_vocab = set()
    for a in A['skus']:
        for c in a['conditions']:
            if c['name'] not in ignore_a:
                au_vocab.add(normR(c['value']))

    def resolve(v):
        if v in au_vocab:
            return v
        pref = [w for w in au_vocab if (w.startswith(v) or v.startswith(w)) and min(len(w), len(v)) >= 2]
        return pref[0] if len(pref) == 1 else v

    out = []
    for rs in r['rakuten']['skus']:
        rc = {c['name']: c['value'] for c in rs['conditions']}
        cons = []  # (au_axis or None, normalized value)
        for ax, f in spec.get('compose', {}).items():
            cons.append((ax, normR(f(rc))))
        for ax, v in spec.get('au_fixed', {}).items():
            cons.append((ax, normR(v)))
        unresolved = []
        for c in rs['conditions']:
            n, v = c['name'], c['value']
            if n in ignore_r:
                continue
            mp = spec.get('map_r', {}).get(n)
            if mp is not None and v in mp:
                cons.append((None, normR(mp[v]))); continue
            v2 = spec.get('rw_r', {}).get(n, {}).get(v, v)
            if n in spec.get('rw_fn', {}):
                v2 = spec['rw_fn'][n](v2)
            nv = resolve(normR(v2))
            if nv not in au_vocab:
                unresolved.append(f'{n}={v}')
            cons.append((None, nv))
        cands = []
        for a in A['skus']:
            conds = [(c['name'], normR(c['value'])) for c in a['conditions'] if c['name'] not in ignore_a]
            ok = True; used = set()
            for ax, nv in cons:
                hit = [i for i, (an, av) in enumerate(conds) if av == nv and (ax is None or an == ax)]
                if not hit:
                    ok = False; break
                used.update(hit)
            if ok:
                cands.append((a['sku_key'], len(used) == len(conds)))
        full = [k for k, f in cands if f]
        pick = full if full else [k for k, f in cands]
        label = None; note = ''; alt = []
        for rule in spec.get('rules', []):
            cond, lab, au_over, rnote, ralt = rule
            if cond(rc):
                label, note, alt = lab, rnote, ralt
                break
        if label is None:
            if len(pick) == 1 and not unresolved:
                label, note = 'matched', 'all conditions correspond (normalized value equality)'
            elif not pick or unresolved:
                label, note = 'unmatched', 'no au row has value(s): ' + ', '.join(unresolved)
            else:
                label, note = 'review', f'{len(pick)} au rows remain'
        au_key = None
        if label in ('matched', 'conditional'):
            if len(pick) == 1:
                au_key = pick[0]
            else:
                problems.append((r['product_pair_id'], rs['sku_key'], label, len(pick), unresolved))
        out.append(dict(product_pair_id=r['product_pair_id'], rakuten_sku_key=rs['sku_key'],
                        rakuten_conditions=[c['value'] for c in rs['conditions']],
                        label=label, au_key=au_key,
                        au_conditions=[c['value'] for a in A['skus'] if a['sku_key'] == au_key for c in a['conditions']],
                        alt=alt, note=note + (' | ' + spec['note'] if spec.get('note') else '')))
    return out


def main():
    rows = load_rows(); splits = load_splits()
    problems = []; allout = []
    for pid, r in rows.items():
        spec = SPEC.get(pid, {})
        allout.extend(build_product(r, spec, problems))
    os.makedirs(os.path.join(OUT, 'reference'), exist_ok=True)
    with open(os.path.join(OUT, 'reference/reference_labels.jsonl'), 'w', encoding='utf-8') as f:
        for o in allout:
            o['split'] = splits[o['product_pair_id']]
            f.write(json.dumps(o, ensure_ascii=False) + '\n')
    c = collections.Counter(o['label'] for o in allout)
    print('total', len(allout), dict(c))
    print('problems', len(problems))
    for p in problems[:40]:
        print('  ', p)
    byp = collections.defaultdict(collections.Counter)
    for o in allout:
        byp[o['product_pair_id']][o['label']] += 1
    if '-v' in sys.argv:
        for pid, cc in byp.items():
            print(pid, dict(cc), 'spec' if pid in SPEC else '')
    # au row reuse check (matched to same au row twice in one product)
    reuse = collections.Counter((o['product_pair_id'], o['au_key']) for o in allout if o['au_key'] and o['label'] == 'matched')
    print('matched au rows reused within product:', [(k, v) for k, v in reuse.items() if v > 1][:10])


if __name__ == '__main__':
    main()
