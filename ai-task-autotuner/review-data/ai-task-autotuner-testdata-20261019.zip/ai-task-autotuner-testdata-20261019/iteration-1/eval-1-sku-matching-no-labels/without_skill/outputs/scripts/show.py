import json,sys
D='/tmp/claude-0/-home-user-zabuton-skills/63e4c5c7-d309-596e-8dd4-3c5a2c09efb2/scratchpad/inputs/sku-normal-v1'
rows={}
for l in open(D+'/inputs/products.jsonl',encoding='utf-8'):
    r=json.loads(l); rows[r['product_pair_id']]=r
maxlines=int(sys.argv[2]) if len(sys.argv)>2 else 40
for pid in sys.argv[1].split(','):
    r=rows[pid]
    print('='*20,pid)
    for s in ('rakuten','au'):
        S=r[s]
        print(f'--- {s}: {S["title"]}')
        print('  url', S['url'])
        for a in S['sku_axes']: print('  axis',a['axis_index'],a['name'],'=',a['values'])
        print('  skus:',len(S['skus']))
        for k in S['skus'][:12]:
            aux=''
            if s=='rakuten': aux=' aux='+';'.join(f"{a['name']}:{a['value']}" for a in k.get('auxiliary_attributes',[]) if a['name'] not in ('ブランド名','ブランド名（カナ）','原産国／製造国'))[:200]
            print('   ',k['sku_key'][-30:],[c['value'] for c in k['conditions']],aux)
        if s=='au': print('  non_sku', json.dumps(S['non_sku_options'],ensure_ascii=False))
        d=S['description']; print('  desc mode',d['mode'],'lines',len(d['lines']),'links',len(d['links']))
        for ln in d['lines'][:maxlines]: print('    ',ln['evidence_id'][-4:],ln['text'][:160])
