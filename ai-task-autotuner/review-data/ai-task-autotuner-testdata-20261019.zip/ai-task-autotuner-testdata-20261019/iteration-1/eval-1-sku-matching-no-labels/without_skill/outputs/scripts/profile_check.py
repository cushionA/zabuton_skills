import json, sys, csv, collections, hashlib, os, statistics
D = sys.argv[1]
rows = [json.loads(l) for l in open(os.path.join(D,'inputs/products.jsonl'), encoding='utf-8')]
rep = collections.OrderedDict()
rep['n_pairs'] = len(rows)
ids = [r['product_pair_id'] for r in rows]
rep['dup_pair_ids'] = [k for k,v in collections.Counter(ids).items() if v>1]
rk = sum(len(r['rakuten']['skus']) for r in rows); au = sum(len(r['au']['skus']) for r in rows)
rep['rakuten_skus']=rk; rep['au_skus']=au
rep['cand_pairs']=sum(len(r['rakuten']['skus'])*len(r['au']['skus']) for r in rows)
rep['max_r']=max(len(r['rakuten']['skus']) for r in rows); rep['max_a']=max(len(r['au']['skus']) for r in rows)
rep['max_pair_product']= max(((len(r['rakuten']['skus']),len(r['au']['skus']),r['product_pair_id']) for r in rows), key=lambda x:x[0]*x[1])
rep['unequal_axis_count']=sum(1 for r in rows if len(r['rakuten']['sku_axes'])!=len(r['au']['sku_axes']))
rep['desc_modes']={s:dict(collections.Counter(r[s]['description']['mode'] for r in rows)) for s in ('rakuten','au')}
# key uniqueness
allkeys=collections.Counter()
for r in rows:
    for s in ('rakuten','au'):
        for k in r[s]['skus']: allkeys[k['sku_key']]+=1
rep['dup_sku_keys']=[k for k,v in allkeys.items() if v>1][:20]
# duplicate condition tuples within a side
dupcond=[]
cond_not_in_axes=[]
for r in rows:
    for s in ('rakuten','au'):
        c=collections.Counter()
        axes={a['axis_index']:a for a in r[s]['sku_axes']}
        for k in r[s]['skus']:
            t=tuple((x['name'],x['value']) for x in k['conditions'])
            c[t]+=1
            for x in k['conditions']:
                a=axes.get(x['axis_index'])
                if a is None or x['value'] not in a['values'] or x['name']!=a['name']:
                    cond_not_in_axes.append((r['product_pair_id'],s,k['sku_key'],x))
        for t,v in c.items():
            if v>1: dupcond.append((r['product_pair_id'],s,t,v))
rep['dup_condition_tuples']=dupcond[:30]; rep['n_dup_condition_tuples']=len(dupcond)
rep['cond_not_in_axes']=cond_not_in_axes[:20]; rep['n_cond_not_in_axes']=len(cond_not_in_axes)
# same product id used in multiple pairs
for s in ('rakuten','au'):
    pid=collections.Counter((r[s].get('product_id') or r[s].get('url')) for r in rows)
    rep[f'{s}_product_reuse']=[(k,v) for k,v in pid.items() if v>1]
# zero-sku sides
rep['zero_sku_sides']=[(r['product_pair_id'],s) for r in rows for s in ('rakuten','au') if not r[s]['skus']]
# keys present
rep['top_keys']=sorted(rows[0].keys()); rep['rk_keys']=sorted(set(k for r in rows for k in r['rakuten'])); rep['au_keys']=sorted(set(k for r in rows for k in r['au']))
rep['rk_sku_keys']=sorted(set(k for r in rows for s in r['rakuten']['skus'] for k in s)); rep['au_sku_keys']=sorted(set(k for r in rows for s in r['au']['skus'] for k in s))
# packets equality
pk_mismatch=[]
for r in rows:
    p=json.load(open(os.path.join(D,'packets',r['product_pair_id']+'.json'),encoding='utf-8'))
    if p!=r: pk_mismatch.append(r['product_pair_id'])
rep['packet_files']=len(os.listdir(os.path.join(D,'packets'))); rep['packet_mismatch']=pk_mismatch
# subsets
sub=json.load(open(os.path.join(D,'subsets.json'),encoding='utf-8'))
idset=set(ids)
rep['subsets']={k:(len(v) if isinstance(v,list) else type(v).__name__, (len(set(v)-idset) if isinstance(v,list) else None), (len(v)-len(set(v)) if isinstance(v,list) else None)) for k,v in sub.items()}
# products.csv
with open(os.path.join(D,'products.csv'),encoding='utf-8') as f:
    pc=list(csv.DictReader(f))
rep['products_csv_rows']=len(pc); rep['products_csv_cols']=list(pc[0].keys())
# non_sku_options
rep['au_nonsku']=collections.Counter((r['au']['non_sku_options']['has_paid_options'],r['au']['non_sku_options']['has_free_options']) for r in rows if r['au'].get('non_sku_options'))
rep['au_nonsku']={str(k):v for k,v in rep['au_nonsku'].items()}
rep['rk_nonsku']=collections.Counter(str(r['rakuten'].get('non_sku_options',{}) and (r['rakuten']['non_sku_options'].get('has_paid_options'),r['rakuten']['non_sku_options'].get('has_free_options'))) for r in rows)
# axis count dist
rep['axis_counts']=dict(collections.Counter((len(r['rakuten']['sku_axes']),len(r['au']['sku_axes'])) for r in rows))
rep['axis_counts']={str(k):v for k,v in rep['axis_counts'].items()}
# sku-count ratio
rep['sku_count_equal']=sum(1 for r in rows if len(r['rakuten']['skus'])==len(r['au']['skus']))
rep['rk_more']=sum(1 for r in rows if len(r['rakuten']['skus'])>len(r['au']['skus']))
rep['au_more']=sum(1 for r in rows if len(r['rakuten']['skus'])<len(r['au']['skus']))
json.dump(rep, sys.stdout, ensure_ascii=False, indent=1, default=str)
