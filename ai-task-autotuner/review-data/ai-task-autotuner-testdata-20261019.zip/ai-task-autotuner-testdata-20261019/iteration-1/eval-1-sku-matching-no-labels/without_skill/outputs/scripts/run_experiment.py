# -*- coding: utf-8 -*-
"""Run a design over a subset with concurrency; save results, call logs, timing/usage summary, and evaluation."""
import os, sys, json, time, argparse, statistics, importlib, datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import OUT, load_rows, load_subsets, load_splits
from evaluate import evaluate
from llm import claude_version


def pct(xs, q):
    if not xs:
        return None
    xs = sorted(xs); k = max(0, min(len(xs) - 1, int(round(q * (len(xs) - 1)))))
    return xs[k]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--design', required=True)          # module name: design_a / design_b / ...
    ap.add_argument('--subset', default='dev')          # dev / test / all / smoke_10 / normal_50 / largest_20 / comma ids
    ap.add_argument('--tag', required=True)
    ap.add_argument('--cfg', default='{}')
    ap.add_argument('--concurrency', type=int, default=6)
    ap.add_argument('--limit', type=int, default=0)
    args = ap.parse_args()
    cfg = json.loads(args.cfg)
    mod = importlib.import_module(args.design)
    rows = load_rows(); sp = load_splits(); subs = load_subsets()
    if args.subset == 'dev':
        pids = [p for p in rows if sp[p] == 'TRAINdict']
    elif args.subset == 'test':
        pids = [p for p in rows if sp[p] == 'EVALtest']
    elif args.subset == 'all':
        pids = list(rows)
    elif args.subset in subs:
        pids = list(subs[args.subset])
    else:
        pids = args.subset.split(',')
    if args.limit:
        pids = pids[:args.limit]
    # largest first to reduce tail latency
    pids.sort(key=lambda p: -len(rows[p]['rakuten']['skus']) * len(rows[p]['au']['skus']))
    odir = os.path.join(OUT, 'runs', args.tag); os.makedirs(odir, exist_ok=True)
    t0 = time.time()
    allres = []; plog = []

    def work(pid):
        ts = time.time()
        try:
            out, calls, fixes, meta = mod.run_product(rows[pid], cfg)
            err = None
        except Exception as e:
            import traceback
            out, calls, fixes, meta = [], [], [], {}
            err = traceback.format_exc()[-800:]
        te = time.time()
        return pid, out, calls, fixes, meta, ts, te, err

    with ThreadPoolExecutor(max_workers=args.concurrency) as ex:
        futs = [ex.submit(work, p) for p in pids]
        for f in as_completed(futs):
            pid, out, calls, fixes, meta, ts, te, err = f.result()
            r = rows[pid]
            if not out:
                out = [dict(product_pair_id=pid, rakuten_sku_key=s['sku_key'], decision=None, au_sku_key=None, status='failed',
                            required_extra_options=[], unresolved_conditions=[], evidence_refs=[], reason='exception') for s in r['rakuten']['skus']]
            allres.extend(out)
            u = {k: sum((c.get('usage') or {}).get(k, 0) for c in calls) for k in ('input', 'output', 'thinking', 'cache_creation', 'cache_read')}
            plog.append(dict(pid=pid, split=sp[pid], n_r=len(r['rakuten']['skus']), n_a=len(r['au']['skus']),
                             product_wall_s=round(te - ts, 3), n_calls=len(calls),
                             n_attempts=sum(len(c.get('attempts', [])) for c in calls),
                             call_wall_s=[c.get('wall_s') for c in calls], cached=[c.get('cached') for c in calls],
                             usage=u, cost_usd=round(sum(c.get('cost_usd') or 0 for c in calls), 6),
                             models=sorted({m for c in calls for m in c.get('models', [])}),
                             fixes=fixes, error=err, meta=meta,
                             n_ok=sum(1 for o in out if o.get('status') == 'ok')))
            print(f"[{len(plog)}/{len(pids)}] {pid} R{len(r['rakuten']['skus'])}xA{len(r['au']['skus'])} {te-ts:.1f}s ok={plog[-1]['n_ok']} calls={len(calls)} fixes={fixes[:3]} err={'Y' if err else ''}", flush=True)
    wall = time.time() - t0
    with open(os.path.join(odir, 'results.jsonl'), 'w', encoding='utf-8') as f:
        for o in allres:
            f.write(json.dumps(o, ensure_ascii=False) + '\n')
    with open(os.path.join(odir, 'product_log.jsonl'), 'w', encoding='utf-8') as f:
        for o in plog:
            f.write(json.dumps(o, ensure_ascii=False) + '\n')
    pw = [p['product_wall_s'] for p in plog]
    n_r = sum(p['n_r'] for p in plog)
    usage = {k: sum(p['usage'][k] for p in plog) for k in ('input', 'output', 'thinking', 'cache_creation', 'cache_read')}
    summ = dict(tag=args.tag, design=args.design, cfg=cfg, subset=args.subset, n_products=len(plog), n_rakuten_skus=n_r,
                concurrency=args.concurrency, wall_clock_s=round(wall, 1), sum_product_s=round(sum(pw), 1),
                product_s_median=pct(pw, .5), product_s_p90=pct(pw, .9), product_s_max=max(pw) if pw else None,
                wall_per_product_s=round(wall / len(plog), 2) if plog else None,
                allocated_s_per_sku=round(sum(pw) / n_r, 3) if n_r else None,
                n_calls=sum(p['n_calls'] for p in plog), n_attempts=sum(p['n_attempts'] for p in plog),
                n_retries=sum(p['n_attempts'] - p['n_calls'] for p in plog),
                cached_calls=sum(sum(1 for c in p['cached'] if c) for p in plog),
                usage=usage, cost_usd=round(sum(p['cost_usd'] for p in plog), 4),
                models=sorted({m for p in plog for m in p['models']}),
                coverage_ok=sum(p['n_ok'] for p in plog), fixes=sum(len(p['fixes']) for p in plog),
                exceptions=sum(1 for p in plog if p['error']), claude_cli=claude_version(),
                finished=datetime.datetime.now().isoformat(timespec='seconds'))
    pidset = set(pids)
    dev = {p for p in pidset if sp[p] == 'TRAINdict'}; test = {p for p in pidset if sp[p] == 'EVALtest'}
    if dev:
        summ['eval_dev'] = evaluate(allres, dev)
    if test:
        summ['eval_test'] = evaluate(allres, test)
    summ['eval_all'] = evaluate(allres, pidset)
    json.dump(summ, open(os.path.join(odir, 'summary.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    show = {k: v for k, v in summ.items() if not k.startswith('eval')}
    print(json.dumps(show, ensure_ascii=False))
    for k in ('eval_dev', 'eval_test', 'eval_all'):
        if k in summ:
            print(k, json.dumps({kk: vv for kk, vv in summ[k].items() if kk not in ('by_tag', 'by_gold')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
