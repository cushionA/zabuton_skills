import json,sys,collections,re
sys.path.insert(0, '/tmp/claude-0/-home-user-zabuton-skills/63e4c5c7-d309-596e-8dd4-3c5a2c09efb2/scratchpad/ai-task-autotuner-workspace/iteration-1/eval-1-sku-matching-no-labels/without_skill/outputs/scripts')
from common import *
rows=load_rows()
kw=sys.argv[2] if len(sys.argv)>2 else ''
for pid in sys.argv[1].split(','):
    r=rows[pid]
    print('='*10,pid)
    for s in ('rakuten','au'):
        S=r[s]
        print(f'[{s}] {S["title"][:200]}')
        for a in S['sku_axes']: print('  axis',a['name'],'=',a['values'])
        if s=='rakuten':
            # varying aux attrs
            vals=collections.defaultdict(set)
            for k in S['skus']:
                for a in k.get('auxiliary_attributes',[]): vals[a['name']].add(a['value'])
            print('  aux-vary:', {k:sorted(v)[:8] for k,v in vals.items() if len(v)>1})
            print('  aux-const:', {k:list(v)[0] for k,v in vals.items() if len(v)==1 and k not in ('ブランド名（カナ）','原産国／製造国')})
        print('  rows:', ' ; '.join('/'.join(c['value'] for c in k['conditions']) for k in S['skus'])[:1500])
        if s=='au': print('  non_sku', json.dumps({k:v for k,v in S['non_sku_options'].items() if v not in (None,[],False)},ensure_ascii=False))
        d=S['description']
        lines=[l['text'] for l in d['lines']]
        if kw:
            hits=[l for l in lines if re.search(kw,l)]
            seen=set(); hh=[]
            for h in hits:
                if h not in seen: seen.add(h); hh.append(h)
            print(f'  desc({d["mode"]},{len(lines)}) hits:', ' || '.join(x[:150] for x in hh[:12]))
        else:
            print(f'  desc({d["mode"]},{len(lines)}):', ' | '.join(x[:80] for x in lines[:15]))
