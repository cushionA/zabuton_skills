import sys, json, collections
sys.path.insert(0, '/tmp/claude-0/-home-user-zabuton-skills/63e4c5c7-d309-596e-8dd4-3c5a2c09efb2/scratchpad/ai-task-autotuner-workspace/iteration-1/eval-1-sku-matching-no-labels/without_skill/outputs/scripts')
from common import *

def align(r):
    R = r['rakuten']; A = r['au']
    res = {}
    for rs in R['skus']:
        rv = [c['value'] for c in rs['conditions']]
        cands = []
        for a in A['skus']:
            av = [c['value'] for c in a['conditions']]
            # each au value must be covered by some rakuten value (equal) or contain rakuten values (composite)
            ok = True; covered_r = set()
            for x in av:
                eq = [i for i, y in enumerate(rv) if vmatch(x, y)]
                if eq: covered_r.update(eq); continue
                cont = [i for i, y in enumerate(rv) if contains(x, y)]
                if cont: covered_r.update(cont); continue
                ok = False; break
            if ok:
                cands.append((a['sku_key'], len(covered_r) == len(rv), sorted(set(range(len(rv))) - covered_r)))
        full = [c for c in cands if c[1]]
        res[rs['sku_key']] = {'r': rv, 'n_cand': len(cands), 'full': [c[0] for c in full], 'partial': [(c[0], c[2]) for c in cands if not c[1]]}
    return res

if __name__ == '__main__':
    rows = load_rows(); sp = load_splits()
    stats = collections.Counter(); prod = {}
    for pid, r in rows.items():
        al = align(r)
        kinds = collections.Counter()
        used = collections.Counter()
        for k, v in al.items():
            if len(v['full']) == 1 and not v['partial']: kinds['uniq_full']+=1; used[v['full'][0]]+=1
            elif len(v['full']) == 1: kinds['uniq_full_plus_partial']+=1
            elif len(v['full']) > 1: kinds['multi_full']+=1
            elif v['partial']: kinds['partial_only']+=1
            else: kinds['none']+=1
        trivial = kinds['uniq_full'] == len(al) and all(c == 1 for c in used.values())
        prod[pid] = (trivial, dict(kinds), len(r['rakuten']['skus']), len(r['au']['skus']))
        stats['trivial' if trivial else 'nontrivial'] += 1
    print(stats)
    for pid, v in prod.items():
        if not v[0]: print(pid, sp[pid], v[1:])
