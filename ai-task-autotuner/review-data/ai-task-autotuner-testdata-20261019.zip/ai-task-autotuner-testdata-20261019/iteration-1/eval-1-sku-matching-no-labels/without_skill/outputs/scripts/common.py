import json, re, unicodedata, os
D = '/tmp/claude-0/-home-user-zabuton-skills/63e4c5c7-d309-596e-8dd4-3c5a2c09efb2/scratchpad/inputs/sku-normal-v1'
OUT = '/tmp/claude-0/-home-user-zabuton-skills/63e4c5c7-d309-596e-8dd4-3c5a2c09efb2/scratchpad/ai-task-autotuner-workspace/iteration-1/eval-1-sku-matching-no-labels/without_skill/outputs'

def load_rows():
    rows = {}
    with open(os.path.join(D, 'inputs/products.jsonl'), encoding='utf-8') as f:
        for l in f:
            r = json.loads(l); rows[r['product_pair_id']] = r
    return rows

def load_subsets():
    return json.load(open(os.path.join(D, 'subsets.json'), encoding='utf-8'))

def load_splits():
    sp = {}
    with open(os.path.join(D, 'source_records/provenance.jsonl'), encoding='utf-8') as f:
        for l in f:
            p = json.loads(l); sp[p['product_pair_id']] = p['original_split']
    return sp

def nfkc(s):
    return unicodedata.normalize('NFKC', s or '')

def norm1(s):
    s = nfkc(s).lower()
    s = re.sub(r'[\s　]+', '', s)
    return s

PUNCT = re.compile(r'[()（）\[\]【】「」『』<>＜＞・/／|｜:：,，、。．\-_＿~〜～★☆■◆●※!！?？+＋]')
def norm2(s):
    s = norm1(s)
    s = s.replace('〜', '~').replace('～', '~')
    s = PUNCT.sub('', s)
    s = re.sub(r'^(\d{1,2})\.(?=\D)', '', norm1(s)) if False else s
    return s

def norm3(s):
    s = norm1(s)
    s = re.sub(r'^\d{1,2}[\.:：](?=\D)', '', s)  # leading "01." code
    s = s.replace('サイズ', '').replace('目安', '').replace('号', '').replace('cm', '')
    s = PUNCT.sub('', s)
    return s

def vmatch(a, b):
    """value-level loose match tiers: returns tier (1 best) or 0"""
    if a == b: return 1
    if norm1(a) == norm1(b): return 1
    if norm2(a) == norm2(b): return 2
    na, nb = norm3(a), norm3(b)
    if na and na == nb: return 3
    return 0

def contains(big, small):
    nb, ns = norm3(big), norm3(small)
    return bool(ns) and len(ns) >= 1 and ns in nb

PRICE_PATTERNS = [
    r'[（(]\s*別途\s*[+＋]?\s*[\d,]+\s*円\s*[)）]',
    r'[:：]?\s*別途\s*[+＋]?\s*[\d,]+\s*円',
    r'[+＋]\s*[\d,]+\s*円',
    r'[（(]\s*[\d,]+\s*円\s*[)）]',
]
def strip_price(s):
    s = nfkc(s)
    for p in PRICE_PATTERNS:
        s = re.sub(p, '', s)
    return s

def kata2hira(s):
    return ''.join(chr(ord(c) - 0x60) if 'ァ' <= c <= 'ヶ' else c for c in s)

def normR(s):
    """reference normalizer: NFKC, price strip, leading code strip, unit-word strip, punct strip, kana fold"""
    s = strip_price(s).lower().strip()
    s = re.sub(r'^\d{1,2}(?:[\.:：](?=\D)|\s+)', '', s)
    s = s.replace('×', 'x')
    s = re.sub(r'[\s　]+', '', s)
    for w in ('サイズ', '目安', '号', 'cm'):
        s = s.replace(w, '')
    s = PUNCT.sub('', s)
    s = kata2hira(s)
    return s
