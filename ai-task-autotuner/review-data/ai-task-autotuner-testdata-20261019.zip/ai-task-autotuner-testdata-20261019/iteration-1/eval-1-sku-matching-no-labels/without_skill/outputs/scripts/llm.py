# -*- coding: utf-8 -*-
"""claude -p runner (API substitute) with per-call timing, usage capture, retry and optional cache."""
import os, sys, json, time, hashlib, subprocess, threading
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import OUT

CWD = os.path.join(OUT, 'sandbox_cwd')
CACHE = os.path.join(OUT, 'cache')
os.makedirs(CWD, exist_ok=True); os.makedirs(CACHE, exist_ok=True)
_env = {k: v for k, v in os.environ.items() if k not in ('CLAUDECODE', 'CLAUDE_CODE_ENTRYPOINT')}
_lock = threading.Lock()


def claude_version():
    try:
        return subprocess.run(['claude', '--version'], capture_output=True, text=True, timeout=60, env=_env, cwd=CWD).stdout.strip()
    except Exception as e:
        return f'unknown ({e})'


def call(prompt, system, model='haiku', schema=None, effort=None, timeout=420, retries=2, use_cache=False, tag=''):
    """Returns dict(ok, text, structured, usage, cost, timings, attempts, error, cached)."""
    cfg = dict(model=model, system=system, schema=schema, effort=effort)
    key = hashlib.sha256(json.dumps([cfg, prompt], ensure_ascii=False, sort_keys=True).encode()).hexdigest()
    cpath = os.path.join(CACHE, key + '.json')
    if use_cache and os.path.exists(cpath):
        d = json.load(open(cpath, encoding='utf-8'))
        d['cached'] = True
        return d
    cmd = ['claude', '-p', '--model', model, '--tools', '', '--system-prompt', system,
           '--output-format', 'json', '--no-session-persistence', '--strict-mcp-config', '--setting-sources', '']
    if schema is not None:
        cmd += ['--json-schema', json.dumps(schema, ensure_ascii=False)]
    if effort:
        cmd += ['--effort', effort]
    attempts = []
    res = None
    for i in range(retries + 1):
        t0 = time.time()
        err = None; d = None
        try:
            p = subprocess.run(cmd, input=prompt, capture_output=True, text=True, timeout=timeout, env=_env, cwd=CWD)
            wall = time.time() - t0
            try:
                d = json.loads(p.stdout)
            except Exception:
                err = f'nonjson rc={p.returncode} stdout={p.stdout[:300]} stderr={p.stderr[:300]}'
            if d is not None and (d.get('is_error') or d.get('subtype') != 'success'):
                err = f"is_error subtype={d.get('subtype')} api_error={d.get('api_error_status')} result={str(d.get('result'))[:200]}"
        except subprocess.TimeoutExpired:
            wall = time.time() - t0
            err = f'timeout {timeout}s'
        att = dict(start=t0, wall_s=round(wall, 3), error=err)
        if d is not None:
            u = d.get('usage', {}) or {}
            att.update(duration_ms=d.get('duration_ms'), duration_api_ms=d.get('duration_api_ms'), ttft_ms=d.get('ttft_ms'),
                       num_turns=d.get('num_turns'), cost_usd=d.get('total_cost_usd'),
                       usage=dict(input=u.get('input_tokens'), output=u.get('output_tokens'),
                                  thinking=(u.get('output_tokens_details') or {}).get('thinking_tokens'),
                                  cache_creation=u.get('cache_creation_input_tokens'), cache_read=u.get('cache_read_input_tokens')),
                       model_usage=d.get('modelUsage'), stop_reason=d.get('stop_reason'))
        attempts.append(att)
        if err is None:
            res = d
            break
        time.sleep(2 + 3 * i)
    out = dict(ok=res is not None, text=(res or {}).get('result'), structured=(res or {}).get('structured_output'),
               attempts=attempts, cached=False, tag=tag)
    # aggregate usage over attempts (failed attempts also cost)
    agg = dict(input=0, output=0, thinking=0, cache_creation=0, cache_read=0)
    cost = 0.0
    for a in attempts:
        for k in agg:
            agg[k] += (a.get('usage') or {}).get(k) or 0
        cost += a.get('cost_usd') or 0
    out['usage'] = agg; out['cost_usd'] = round(cost, 6)
    out['wall_s'] = round(sum(a['wall_s'] for a in attempts), 3)
    out['models'] = sorted({m for a in attempts for m in (a.get('model_usage') or {}).keys()})
    if out['ok']:
        with _lock:
            json.dump(out, open(cpath, 'w', encoding='utf-8'), ensure_ascii=False)
    return out


def extract_json(text):
    """Parse a JSON object from model text (handles ```json fences / leading prose)."""
    if text is None:
        return None
    t = text.strip()
    if t.startswith('```'):
        t = t.split('\n', 1)[1] if '\n' in t else t
        if t.rstrip().endswith('```'):
            t = t.rstrip()[:-3]
    try:
        return json.loads(t)
    except Exception:
        pass
    s = t.find('{'); e = t.rfind('}')
    if s >= 0 and e > s:
        try:
            return json.loads(t[s:e + 1])
        except Exception:
            return None
    return None
