# -*- coding: utf-8 -*-
"""Compare a system output (results jsonl) against the provisional reference (reference/reference_labels.jsonl)."""
import os, sys, json, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import OUT

# asymmetry type tags (by product) for breakdown; products not listed = 'symmetric/naming-only'
TAGS = {}
def _t(tag, *pids):
    for p in pids:
        TAGS.setdefault(p, []).append(tag)
_t('au_single_model(subset)', 'raw-4bb84bb524d60a77', 'raw-c24a3d93ed23a245', 'raw-949d7779a78625df', 'raw-dda5335fb4fea120',
   'raw-b7c643b1fe1fa785', 'raw-ba6be4d42376a54a', 'raw-ec66cdf34000106f', 'raw-f04a36fbd4cc457a', 'raw-f550c14a9a642c78')
_t('quantity/set_one_side', 'raw-0209be9e10e8febc', 'raw-12f3057cc81c6d73', 'raw-14870a21b0b285e6', 'raw-241f737351829b41',
   'raw-a0b32008327edad6', 'raw-dca4c563276ecd75', 'raw-a7704e4202d56f57', 'raw-f197ee49242ae821')
_t('composite_values', 'raw-0908bb952709f362', 'raw-12f3057cc81c6d73', 'raw-2edbf9ae7458043c', 'raw-3087165228863cd1',
   'raw-5a6a1938e1698365', 'raw-ac8fd1a7cbd8cfe2', 'raw-8df14d4636e3db58', 'raw-2730ff0f4338c5c3', 'raw-44ce949d8dcecf40', 'raw-457e312a33caba50')
_t('au_paid_option', 'raw-078b840ebb0bdc83', 'raw-0908bb952709f362', 'raw-0ff99724c5cb0e91', 'raw-23a256226c40db65', 'raw-23dd1d3cb8a0ab88',
   'raw-2730ff0f4338c5c3', 'raw-30ed9ec522c43c4e', 'raw-44ce949d8dcecf40', 'raw-457e312a33caba50', 'raw-6de77fae280c02b2',
   'raw-738db4d617d48eb3', 'raw-875f94252b18eb78', 'raw-f197ee49242ae821', 'raw-701a460aa9270c56')
_t('au_free_option', 'raw-635b86c6e684e1d1', 'raw-803a727608455afe', 'raw-b996688cc5c0ccfe')
_t('one_side_fixed_spec', 'raw-23dd1d3cb8a0ab88', 'raw-738db4d617d48eb3', 'raw-30ed9ec522c43c4e', 'raw-635b86c6e684e1d1', 'raw-df54f8a492f9f692',
   'raw-a7704e4202d56f57')
_t('value_range_diff', 'raw-4455fc31b129a8a2', 'raw-89473b67c1a1d382', 'raw-867417cfbebb5736', 'raw-247bceda1b56d3ad', 'raw-df54f8a492f9f692')
_t('pair_doubt', 'raw-7f04455a83ac52c8', 'raw-7fa1c1f5f6ac2ec6', 'raw-affeea04e64fe893')
_t('undeterminable_axis', 'raw-f94b25d2668fe1d6')
_t('placeholder/mislabeled_axis', 'raw-0f0942dbce1625c1', 'raw-334374f11fbe2166', 'raw-5368b4a54d1b762d', 'raw-806805573867fb66',
   'raw-867417cfbebb5736', 'raw-fb5f9d07bbd7392a', 'raw-5aac1087be9600dc', 'raw-7552380c5bdcd2a4', 'raw-247bceda1b56d3ad')


def load_ref():
    ref = {}
    for l in open(os.path.join(OUT, 'reference/reference_labels.jsonl'), encoding='utf-8'):
        o = json.loads(l); ref[(o['product_pair_id'], o['rakuten_sku_key'])] = o
    return ref


def classify(g, s):
    gl, ga, alt = g['label'], g['au_key'], set(g['alt'] or [])
    if s is None or s.get('status') != 'ok':
        return 'failed'
    sl, sa = s.get('decision'), s.get('au_sku_key')
    if sl == 'matched':
        if ga is not None and sa == ga:
            if gl == 'matched' or 'matched' in alt:
                return 'ok'
            if gl == 'conditional':
                return 'missed_condition'
        return 'false_confirm'
    if sl == 'conditional':
        if ga is not None and sa == ga:
            if gl == 'conditional' or 'conditional' in alt:
                return 'ok'
            return 'over_conditional'
        return 'wrong_conditional'
    if sl == 'unmatched':
        if gl == 'unmatched' or 'unmatched' in alt:
            return 'ok'
        if gl in ('matched', 'conditional'):
            return 'missed_match'
        return 'unmatched_vs_review'
    if sl == 'review':
        if gl == 'review' or 'review' in alt:
            return 'ok'
        return 'held'
    return 'failed'


def evaluate(results, pids=None, ref=None):
    ref = ref or load_ref()
    sysmap = {(o['product_pair_id'], o['rakuten_sku_key']): o for o in results}
    keys = [k for k in ref if pids is None or k[0] in pids]
    cats = collections.Counter(); by_gold = collections.defaultdict(collections.Counter)
    by_tag = collections.defaultdict(collections.Counter)
    sys_lab = collections.Counter()
    for k in keys:
        g = ref[k]; s = sysmap.get(k)
        c = classify(g, s)
        cats[c] += 1; by_gold[g['label']][c] += 1
        sys_lab[(s or {}).get('decision') if s and s.get('status') == 'ok' else 'failed'] += 1
        for t in TAGS.get(k[0], ['symmetric/naming-only']):
            by_tag[t][c] += 1
    n = len(keys)
    sys_matched = sum(1 for k in keys if (sysmap.get(k) or {}).get('decision') == 'matched' and (sysmap.get(k) or {}).get('status') == 'ok')
    ok_matched = sum(1 for k in keys if classify(ref[k], sysmap.get(k)) == 'ok' and sysmap[k]['decision'] == 'matched')
    gold_matched = sum(1 for k in keys if ref[k]['label'] == 'matched')
    gold_matched_hit = sum(1 for k in keys if ref[k]['label'] == 'matched' and (sysmap.get(k) or {}).get('decision') == 'matched' and sysmap[k].get('au_sku_key') == ref[k]['au_key'])
    m = dict(
        n=n, ok=cats['ok'], ok_rate=round(cats['ok'] / n, 4) if n else None,
        critical=cats['false_confirm'] + cats['missed_condition'],
        false_confirm=cats['false_confirm'], missed_condition=cats['missed_condition'],
        wrong_conditional=cats['wrong_conditional'], missed_match=cats['missed_match'],
        over_conditional=cats['over_conditional'], held=cats['held'], unmatched_vs_review=cats['unmatched_vs_review'],
        failed=cats['failed'],
        sys_labels=dict(sys_lab),
        auto_confirm_precision=round(ok_matched / sys_matched, 4) if sys_matched else None,
        auto_confirm_recall_vs_ref_matched=round(gold_matched_hit / gold_matched, 4) if gold_matched else None,
        by_gold={k: dict(v) for k, v in by_gold.items()},
        by_tag={k: dict(v) for k, v in by_tag.items()},
    )
    return m


def load_results(path):
    return [json.loads(l) for l in open(path, encoding='utf-8')]


if __name__ == '__main__':
    from common import load_splits
    sp = load_splits()
    res = load_results(sys.argv[1])
    for name, pids in [('dev(TRAINdict)', {p for p, s in sp.items() if s == 'TRAINdict'}), ('test(EVALtest)', {p for p, s in sp.items() if s == 'EVALtest'})]:
        have = {o['product_pair_id'] for o in res}
        pids2 = pids & have
        if not pids2:
            continue
        m = evaluate(res, pids2)
        print(name, 'products', len(pids2), json.dumps({k: v for k, v in m.items() if k not in ('by_tag', 'by_gold')}, ensure_ascii=False))
        if '-v' in sys.argv:
            print('  by_gold', json.dumps(m['by_gold'], ensure_ascii=False))
            for t, c in m['by_tag'].items():
                print('  tag', t, dict(c))
