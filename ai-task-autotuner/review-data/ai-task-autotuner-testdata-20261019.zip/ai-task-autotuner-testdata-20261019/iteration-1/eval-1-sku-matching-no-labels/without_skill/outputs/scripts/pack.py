# -*- coding: utf-8 -*-
"""Build compact per-product model input from inputs/products.jsonl (distributed input only)."""
import json, collections


def dedupe_lines(lines, maxlen=220):
    seen = set(); out = []
    for ln in lines:
        t = ln['text'].strip()
        if not t or t in seen:
            continue
        seen.add(t)
        out.append([ln['evidence_id'], t[:maxlen]])
    return out


def pack(r, with_rows=True, with_aux=True, desc_max_lines=150):
    """Returns (packet_dict, idmap) where idmap maps short ids -> original sku_keys."""
    R, A = r['rakuten'], r['au']
    idmap = {}
    rk_rows = []
    common_aux = None
    if with_aux:
        vals = collections.defaultdict(set)
        for s in R['skus']:
            for a in s.get('auxiliary_attributes', []):
                vals[a['name']].add(str(a['value']) + (a.get('unit') or ''))
        varying = {k for k, v in vals.items() if len(v) > 1}
        common_aux = {k: list(v)[0][:80] for k, v in vals.items() if len(v) == 1 and list(v)[0] not in ('-', '')}
    for i, s in enumerate(R['skus'], 1):
        sid = f'R{i}'; idmap[sid] = s['sku_key']
        row = {'id': sid, 'cond': {f"{c['axis_index']}:{c['name']}": c['value'] for c in s['conditions']}}
        if with_aux:
            aux = {a['name']: (str(a['value']) + (a.get('unit') or ''))[:80] for a in s.get('auxiliary_attributes', []) if a['name'] in varying}
            if aux:
                row['aux'] = aux
        rk_rows.append(row)
    au_rows = []
    for i, s in enumerate(A['skus'], 1):
        sid = f'A{i}'; idmap[sid] = s['sku_key']
        au_rows.append({'id': sid, 'cond': {f"{c['axis_index']}:{c['name']}": c['value'] for c in s['conditions']}})
    pk = {
        'rakuten': {
            'title': R['title'],
            'axes': [{'axis': f"{a['axis_index']}:{a['name']}", 'values': a['values']} for a in R['sku_axes']],
            'sku_attributes_common_to_all_rows': common_aux,
            'description_mode': R['description']['mode'],
            'description_lines': dedupe_lines(R['description']['lines'])[:desc_max_lines],
        },
        'au': {
            'title': A['title'],
            'axes': [{'axis': f"{a['axis_index']}:{a['name']}", 'values': a['values']} for a in A['sku_axes']],
            'non_sku_options': A['non_sku_options'],
            'description_mode': A['description']['mode'],
            'description_lines': dedupe_lines(A['description']['lines'])[:desc_max_lines],
        },
    }
    if not with_aux:
        pk['rakuten'].pop('sku_attributes_common_to_all_rows')
    if with_rows:
        pk['rakuten']['sku_rows'] = rk_rows
        pk['au']['sku_rows'] = au_rows
    return pk, idmap


def aux_by_value(r):
    """For Rakuten aux attributes that vary across rows and are a function of one axis value, return {axis: {value: {attr: val}}}."""
    R = r['rakuten']
    skus = R['skus']
    vals = collections.defaultdict(set)
    for s in skus:
        for a in s.get('auxiliary_attributes', []):
            vals[a['name']].add(str(a['value']))
    varying = [k for k, v in vals.items() if len(v) > 1]
    out = collections.defaultdict(lambda: collections.defaultdict(dict))
    unexplained = []
    for attr in varying:
        placed = False
        for ax in R['sku_axes']:
            key = f"{ax['axis_index']}:{ax['name']}"
            m = {}
            ok = True
            for s in skus:
                v = next((c['value'] for c in s['conditions'] if c['axis_index'] == ax['axis_index']), None)
                av = next((str(a['value']) for a in s.get('auxiliary_attributes', []) if a['name'] == attr), None)
                if v in m and m[v] != av:
                    ok = False; break
                m[v] = av
            if ok:
                for v, av in m.items():
                    if av is not None:
                        out[key][v][attr] = av[:60]
                placed = True
                break
        if not placed:
            unexplained.append(attr)
    return {k: dict(v) for k, v in out.items()}, unexplained
