# -*- coding: utf-8 -*-
"""
Provisional reference ("暫定参照") for Rakuten->au SKU matching.

Author: Claude Opus 5.5 (the agent running this evaluation), by reading each product pair's
axes, SKU rows, titles, non_sku_options and descriptions in inputs/products.jsonl.
NOT human-verified.  NOT an independent ground truth.  Used only to measure system variants
consistently.  Every product-specific judgement is written down here so a human can audit it.

Per Rakuten SKU the reference gives:
  label  : matched | conditional | unmatched | review
  au_key : the au row (for matched/conditional), else None
  alt    : other labels that are also acceptable (judgement-dependent cases)
  note   : reason

Engine: per product, a list of Rakuten->au value rules.  Rakuten conditions are first rewritten
(spec 'rw_r'), axes listed in 'ignore_r' are dropped from row matching (they are explained by a
fixed spec / option / placeholder and handled in 'rules'), au axes in 'ignore_a' are placeholders.
'au_fixed' constrains au axes that Rakuten has no axis for.  'compose' builds au values from
Rakuten values for combined-value axes.  Generic matching uses common.normR equality.
'rules' (first match wins) override the label for specific Rakuten values.
"""
import re

def has(axis, *vals):
    return lambda rc: rc.get(axis) in vals
def contains(axis, sub):
    return lambda rc: sub in (rc.get(axis) or '')
def not_in(axis, *vals):
    return lambda rc: rc.get(axis) not in vals

R = {}

# ---------------------------------------------------------------- non-trivial products
R['raw-0209be9e10e8febc'] = dict(ignore_r=['枚数'], rules=[
    (has('枚数', '1枚'), 'unmatched', None, 'au is fixed 2枚組 (title "2枚組", desc "コスパ抜群の2枚セット"); Rakuten 1枚 (型番ladshirt064) has no au row', ['review']),
], note='2枚セット rows -> au size row (au fixed 2枚組, desc mentions ladshirt047 = Rakuten 2枚 型番)')
R['raw-078b840ebb0bdc83'] = dict(rules=[
    (contains('カラー', 'ロング丈'), 'conditional', None, 'au desc: ロング丈希望は買い物かごでオプション「付ける」を選択 (paid option, selection unverified)', ['review']),
])
R['raw-0908bb952709f362'] = dict(compose={'カラー': lambda rc: f"{rc['カラー']}({rc['ファー']})"}, ignore_r=['ファー', 'カラー'], rules=[
    (has('ファー', 'フォックス'), 'conditional', None, 'au desc: ファー フォックス（オプション料金：別途+5990円）; au paid option needed, unverified', ['review']),
])
R['raw-0f0942dbce1625c1'] = dict(ignore_r=['在庫'], note='Rakuten axis labels shifted (在庫=サイズ, カラー=Sサイズ..); values are sizes')
R['raw-0ff99724c5cb0e91'] = dict(map_r={'セット内容': {
    'ワンピース+髪飾り': 'ワンピース/髪飾り', 'ワンピース+髪飾り+マント': 'ワンピース|髪飾り|マント',
    'ワンピース+髪飾り+パニエ': 'ワンピース|髪飾り|パニエ', 'ワンピース+髪飾り+マント+パニエ': 'ワンピース|髪飾り|パニエ|マント'}}, rules=[
    (lambda rc: 'マント' in rc['セット内容'] or 'パニエ' in rc['セット内容'], 'conditional', None, 'au desc: マント/パニエ オプション料金 別途 (paid option on au, unverified)', ['review']),
])
R['raw-12f3057cc81c6d73'] = dict(ignore_r=['枚数'], compose={'カラー': lambda rc: f"{rc['カラー']}（{rc['ネックライン']}）"}, ignore_r2=['ネックライン', 'カラー'], rules=[
    (has('枚数', '1枚'), 'unmatched', None, 'au desc: 2枚セット fixed; no 1枚 row', ['review']),
    (has('枚数', '2枚セット'), 'matched', None, 'color(neck)+size; au desc 2枚セット. NOTE au title says タンクトップ/ノースリーブ (title conflict)', ['review']),
])
R['raw-14870a21b0b285e6'] = dict(rules=[
    (lambda rc: True, 'unmatched', None, 'Rakuten is a 2-bottle set (一つ目+二つ目); au rows are single bottles (種類 x1)', ['review']),
])
R['raw-224155aa351376c9'] = dict(rw_r={'種類を選んで下さい': {'あぶり250g×2P': '炙り250g×2p', 'ゆで250g+あぶり250g': 'ゆで250g＋炙り250g'}})
R['raw-23a256226c40db65'] = dict(ignore_r=['オプション'], rules=[
    (contains('オプション', 'グランドシート'), 'conditional', None, 'au desc: グランドシートはオプション選択画面で購入 (paid option, unverified)', ['review']),
])
R['raw-23dd1d3cb8a0ab88'] = dict(au_fixed={'カラー': 'シャンパン色'}, ignore_r=['パニエ（4段）', 'ヘアアクセサリー'], rules=[
    (lambda rc: rc['パニエ（4段）'] == 'つける' or rc['ヘアアクセサリー'] == 'つける', 'conditional', None, 'パニエ/ヘアアクセサリー are au paid options (desc オプション料金)', ['review']),
    (contains('サイズ', 'サイズ指定'), 'conditional', None, 'au desc: サイズ指定 オプション料金 別途2230円', ['matched', 'review']),
])
R['raw-241f737351829b41'] = dict(ignore_r=['数量'], rules=[
    (has('数量', '2個セット'), 'unmatched', None, 'au rows are single units; no 2個セット row', ['review']),
])
R['raw-247bceda1b56d3ad'] = dict(ignore_a=['お選びください'], map_r={'カラー': {'Aタイプ_オレンジ': 'オレンジ（C）', 'Aタイプ_ホワイト': 'ホワイト（E）'}}, rules=[
    (lambda rc: 'オレンジ' in rc['カラー'] or 'ホワイト' in rc['カラー'], 'matched', None, 'color name match; Rakuten "Aタイプ" vs au letter codes not explained', ['review']),
    (lambda rc: True, 'unmatched', None, 'Aタイプ_ブルーグレイ (mojibake) has no au color', ['review']),
])
R['raw-2730ff0f4338c5c3'] = dict(map_r={'カラー': {'ワインレッド(ミモレ丈)': 'ミモレ丈', 'ワインレッド(ロング丈＋1380円)': 'ロング丈＋1380円'}}, rules=[
    (contains('カラー', 'ロング丈'), 'conditional', None, 'au row "ロング丈＋1380円" + au desc オプション「つける」; extra charge via paid option likely', ['matched', 'review']),
])
R['raw-2edbf9ae7458043c'] = dict(compose={'カラー': lambda rc: f"{rc['カラー']}ポケット{rc['ポケット']}"}, ignore_r2=['ポケット', 'カラー'])
R['raw-3087165228863cd1'] = dict(compose={'サイズ': lambda rc: f"{rc['型']}{rc['サイズ']}"}, ignore_r2=['型', 'サイズ'])
R['raw-30ed9ec522c43c4e'] = dict(au_fixed={'カラー': 'オレンジ'}, ignore_r=['カラー'], rules=[
    (has('カラー', 'ヘアバンド付ける'), 'conditional', None, 'au: ヘアバンド is a paid option (別途880円)', ['review']),
])
R['raw-334374f11fbe2166'] = dict(ignore_r=['在庫'])
R['raw-3486110e019a2015'] = dict(rules=[(lambda rc: True, 'matched', None, 'color+号数; au title says 0.2ct but au desc says 合計0.02ct (title typo)', ['review'])])
R['raw-44ce949d8dcecf40'] = dict(map_r={'タイプ': {'ミモレ丈': 'ワインレッド(ミモレ丈)', 'ロング丈(別途1980円)': 'ワインレッド(ロング丈)+1980円'}}, rules=[
    (contains('タイプ', 'ロング丈'), 'conditional', None, 'au desc: ロング丈は買い物かごでオプション「付ける」', ['review']),
])
R['raw-457e312a33caba50'] = dict(map_r={'タイプ': {'ロング丈': 'ライトシャンパン', 'トレーン丈：別途4280円': 'トレーンタイプ：別途4280円'}}, rules=[
    (contains('タイプ', 'トレーン'), 'conditional', None, 'au desc: トレーンタイプ オプション料金 別途4280円, オプション「付ける」', ['review']),
])
R['raw-4bb84bb524d60a77'] = dict(ignore_r=['対応機種'], rules=[
    (not_in('対応機種', 'Galaxy S25'), 'unmatched', None, 'au listing is Galaxy S25 only (title/spec); Ultra has no au row here', ['review']),
])
R['raw-5368b4a54d1b762d'] = dict(ignore_r=['-'], rules=[(lambda rc: True, 'matched', None, 'color; titles say プリンセス vs ラプンツェル (same Great Pretender item)', ['review'])])
R['raw-5a6a1938e1698365'] = dict(compose={'カラー': lambda rc: {('Aタイプ', '01.ブラック'): '01.Aタイプ ブラック', ('Aタイプ', '02.グレー'): '02.Aタイプ グレー', ('Aタイプ', '03.ライトグレー'): '03.Aタイプ ライトグレー', ('Bタイプ', '01.ブラック'): '04.Bタイプ ブラック', ('Bタイプ', '02.グレー'): '05.Bタイプ グレー', ('Bタイプ', '03.ライトグレー'): '06.Bタイプ ライトグレー'}[(rc['タイプ'], rc['カラー'])]}, ignore_r2=['タイプ', 'カラー'])
R['raw-5aac1087be9600dc'] = dict(ignore_a=['-'])
R['raw-635b86c6e684e1d1'] = dict(au_fixed={'カラー': 'シルバー'}, ignore_r=['ヒール'], rules=[
    (lambda rc: True, 'conditional', None, 'heel height is an au non-SKU option ("ヒール" in observed_unselected_text); selection unverified', ['review']),
])
R['raw-6de77fae280c02b2'] = dict(map_r={'サイズ': {'24cmx64cm': '24cmx64cm', '24cmx75cm': '24cmx64cm', '24cmx80cm': '24cmx64cm', '24cmx100cm': '24cmx64cm'}}, rules=[
    (lambda rc: rc['サイズ'] != '24cmx64cm', 'conditional', None, 'au row only 24cmx64cm; au desc: 75/80/100cm は買い物かごでサイズ選択 (paid option)', ['review']),
])
R['raw-6f3e94e5ed512da7'] = dict(rw_r={'カラー': {'ブラックライン×チャコール': 'ブラック×チャコール'}})
R['raw-701a460aa9270c56'] = dict(rules=[(has('タイプ', '大人'), 'matched', None, 'au "大人(8880円)" price label; paid option need unclear', ['conditional', 'review'])])
R['raw-738db4d617d48eb3'] = dict(au_fixed={'カラー': 'シャンパン色'}, ignore_r=['パニエ（4段）', 'ヘアアクセサリー'], rules=[
    (lambda rc: rc['パニエ（4段）'] == 'つける' or rc['ヘアアクセサリー'] == 'つける', 'conditional', None, 'パニエ/ヘアアクセサリー are au paid options', ['review']),
    (has('サイズ', 'サイズ指定'), 'matched', None, 'au row サイズ指定 exists (no fee line on au)', ['conditional', 'review']),
])
R['raw-7552380c5bdcd2a4'] = dict(ignore_a=['種類2'])
R['raw-7e80d0b9db763b61'] = dict(rw_r={'カラー': {'サックスブルー': 'サックス'}})
R['raw-7f04455a83ac52c8'] = dict(rules=[(lambda rc: True, 'unmatched', None, 'PAIR DOUBT: Rakuten Actcyc ALLCOVER TIGHTS (leggings) vs au ACTLEG calf supporter - different product', ['review'])])
R['raw-7fa1c1f5f6ac2ec6'] = dict(rules=[(lambda rc: True, 'unmatched', None, 'PAIR DOUBT: Rakuten backpack 30x13x43 (black/white) vs au 3way shoulder bag 34x34x15 (A01-A03)', ['review'])])
R['raw-affeea04e64fe893'] = R['raw-7fa1c1f5f6ac2ec6']
R['raw-803a727608455afe'] = dict(ignore_r=['タイプ'], rules=[
    (lambda rc: True, 'conditional', None, 'back type (ファスナー/編み上げ) is an au non-SKU option "後ろタイプ"; selection unverified', ['review']),
])
R['raw-806805573867fb66'] = dict(ignore_r=['お選びください'])
R['raw-867417cfbebb5736'] = dict(ignore_r=['お選びください'], rules=[
    (has('商品カラー', 'ピーチピンク'), 'review', None, 'Rakuten ピーチピンク vs au ピーチ / パステルピンク / ビビッドピンク: name differs, not provable', ['unmatched']),
])
R['raw-875f94252b18eb78'] = dict(ignore_a=['カラー'], rules=[
    (contains('サイズ', '20'), 'conditional', None, 'au desc: 20x22cm オプション料金 別途2310円, オプション「つける」', ['review']),
])
R['raw-8ec0c265594104dd'] = dict()
R['raw-949d7779a78625df'] = dict(ignore_r=['対応機種'], rules=[
    (not_in('対応機種', 'AQUOS wish4'), 'unmatched', None, 'au listing is AQUOS wish4 only', ['review']),
])
R['raw-a7704e4202d56f57'] = dict(au_fixed={'セット': '6枚セット'}, rules=[
    (lambda rc: True, 'matched', None, 'Rakuten desc: 6枚セット (3色x2組); au セット=6枚セット', ['review']),
])
R['raw-ac8fd1a7cbd8cfe2'] = dict(compose={'サイズ': lambda rc: f"{rc['型']}{rc['サイズ']}", 'カラー': lambda rc: f"{rc['カラー']}({rc['ネックライン']})"}, ignore_r2=['型', 'ネックライン', 'サイズ', 'カラー'])
R['raw-b0d71d38d47e17ea'] = dict(rw_r={'形状': {'丸型': '丸'}})
R['raw-b7c643b1fe1fa785'] = dict(ignore_r=['対応機種'], rules=[
    (not_in('対応機種', 'iPhone 16'), 'unmatched', None, 'au listing is iPhone 16 only', ['review']),
])
R['raw-b996688cc5c0ccfe'] = dict(ignore_r=['父の日カード'], rules=[
    (has('父の日カード', '希望する'), 'conditional', None, 'card via au [ギフト] option (定型文, not necessarily 父の日); unverified', ['review']),
])
R['raw-ba6be4d42376a54a'] = dict(ignore_r=['対応機種'], rules=[
    (not_in('対応機種', 'iPhone 16'), 'unmatched', None, 'au listing is iPhone 16 only', ['review']),
])
R['raw-c24a3d93ed23a245'] = dict(ignore_r=['対応機種'], rules=[
    (not_in('対応機種', 'Galaxy S25 Ultra'), 'unmatched', None, 'au listing is Galaxy S25 Ultra only', ['review']),
])
R['raw-dca4c563276ecd75'] = dict(rules=[(contains('タイプ', '2個'), 'unmatched', None, 'Rakuten 2個 set; au single only', ['review'])])
R['raw-dda5335fb4fea120'] = dict(ignore_r=['対応機種'], rules=[
    (not_in('対応機種', 'AQUOS R9'), 'unmatched', None, 'au listing is AQUOS R9/R10 only', ['review']),
])
R['raw-df54f8a492f9f692'] = dict(ignore_r=['タイプ'], rules=[
    (has('タイプ', '長袖'), 'unmatched', None, 'au listing is 5分袖 (title/desc); no 長袖', ['review']),
    (contains('カラー', '/'), 'unmatched', None, 'two-tone color has no au color', ['review']),
])
R['raw-ec66cdf34000106f'] = dict(ignore_r=['対応機種'], rules=[
    (not_in('対応機種', 'Google Pixel 9a'), 'unmatched', None, 'au listing is Pixel 9a only', ['review']),
])
R['raw-f04a36fbd4cc457a'] = dict(ignore_r=['機種'], rules=[
    (not_in('機種', 'iPhone 14 Plus'), 'unmatched', None, 'au listing is iPhone 14 Plus only', ['review']),
])
R['raw-f197ee49242ae821'] = dict(au_fixed={'セット': 'ジャケットのみ'}, ignore_r=['セット'], rules=[
    (has('セット', 'シャツ+スカート'), 'unmatched', None, 'au base row is ジャケットのみ; シャツ+スカート without jacket not buildable', ['review']),
    (lambda rc: rc['セット'] != 'ジャケットのみ', 'conditional', None, 'au: ジャケットのみ row + シャツ/スカート 別途金額追加 (paid options, unverified)', ['review']),
])
R['raw-f550c14a9a642c78'] = dict(ignore_r=['対応機種'], rw_r={'商品カラー': {'BLACK（ブラック）': 'ブラック', 'LIGHT BLUE（ライトブルー）': 'ライトブルー'}}, rules=[
    (not_in('対応機種', 'Google Pixel 9a'), 'unmatched', None, 'au listing is Pixel 9a only', ['review']),
])
R['raw-f94b25d2668fe1d6'] = dict(ignore_r=['ネック'], rules=[
    (lambda rc: True, 'review', None, 'au listing has size only; which neckline (クルー/U/タートル) au sells is not stated', []),
])
R['raw-fb5f9d07bbd7392a'] = dict(ignore_r=['種類'])

R['raw-5525f92f0a9c49e6'] = dict(map_r={'タイプ': {'A': 'A：ブルー', 'B': 'B：ダークブルー'}}, note='Rakuten タイプ A/B = au A：ブルー / B：ダークブルー')
R['raw-8df14d4636e3db58'] = dict(rw_fn={'カラー': lambda v: v.replace('【透け感】', 'TypeA【透け感】-') if '透け感' in v else v.replace('【裏起毛】', 'TypeB裏起毛-')})
