"""Failures per unit across runs: python tools/unitfails.py WS RUN [RUN...]"""
import json, sys, collections
from pathlib import Path
ws=Path(sys.argv[1]); runs=sys.argv[2:]
c=collections.defaultdict(lambda:[0]*len(runs)); tags=collections.defaultdict(collections.Counter)
for i,r in enumerate(runs):
    for it in json.load(open(ws/'runs'/r/'score.json'))['items']:
        if it['score']==0:
            c[it['unit']][i]+=1
            ref=it['ref'] if isinstance(it['ref'],str) else 'acc'
            tags[it['unit']][f"{str(it['pred']).split(':')[0]}>{ref.split(':')[0]}"]+=1
for u,v in sorted(c.items(),key=lambda x:-sum(x[1])): print(u[-8:],v,dict(tags[u]))
