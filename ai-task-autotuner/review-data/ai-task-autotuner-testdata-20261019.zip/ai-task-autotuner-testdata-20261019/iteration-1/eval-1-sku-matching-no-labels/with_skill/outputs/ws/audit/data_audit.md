# Data audit - rakuten-au-sku-matching (2026-10-18)

## Inputs
| file | size | records | sha256 (short) | unit |
|---|---|---|---|---|
| sku-normal-v1/inputs/products.jsonl | 4,162,677 B | 152 | b93eb2a23b90dd85 | one Rakuten/au product pair with all SKU rows, axes, descriptions, au non-SKU option flags |
| sku-normal-v1/subsets.json | 6,581 B | 4 lists | 5870b1c7f0230de7 | smoke_10, normal_50, all_152, largest_20 (pair ids) |

Not read by the pipeline: packets/*.json (same 152 inputs, one file each - not double counted), au_only_stress/
(user: do not use), source_records/ (provenance; contains derived colour vocab / size crosswalks from earlier
development - not used, to keep the "provided inputs only" condition), sources/ (raw pages).
Item = one Rakuten SKU row inside a pair (1,934 slots). Candidate rows = au SKU rows of the same pair.

## Stated by the user (known limitations)
- No labels / no model predictions; annotation_template.csv is blank -> silver reference needed; report "agreement".
- Pairs are candidate correspondences, not human-verified (provenance: all 152 `pair_identity_human_verified=false`).
- Description text unavailable: Rakuten 10, au 1. au option value lists / current selections are null (not captured).
- Data was used in earlier development (TRAINdict 72 / EVALtest 80) - not an independent test.
- au_only_stress is a separate load set; excluded from accuracy denominators (here: excluded entirely, per user).

## Findings
| id | severity | finding | evidence | impact | recommendation |
|---|---|---|---|---|---|
| integrity | info | keys unique within pair, every condition resolves to an axis value, condition count = axis count | 0 violations in 3,534 rows | none | - |
| size | info | 152 pairs / 1,934 Rakuten SKU slots / 1,600 au rows / 45,454 candidate pairs / max 60x60 | matches brief | - | - |
| rakuten-desc-effectively-empty | medium | 24 Rakuten descriptions exist but are boilerplate only (23x "メーカー希望小売価格はメーカーサイトに基づいて掲載しています", 1x shipping note); with the 10 unavailable, 34/152 Rakuten sides carry no product-spec text | e.g. raw-0209be9e10e8febc, raw-23a256226c40db65, raw-12f3057cc81c6d73 | more SKUs can only be decided from titles/axes; expect more review | report as stratum; brief's "10 unavailable" understates it |
| rakuten-page-in-two-pairs | medium | 6 Rakuten pages appear in 2 pairs each (12 pairs) -> 89 Rakuten SKU rows counted twice: 1,934 slots = 1,845 unique Rakuten SKUs | k14006, dsc88, act-01, k15029, 47aug25sb01, dsh88-m | denominators; split leakage | keep both pairs (different au candidates); group splits by Rakuten URL; report slots and unique |
| duplicate-au-listings | medium | 2 of those groups pair one Rakuten page with two au item ids whose title, rows and description are identical | (raw-6f8fde18946a343a, raw-dee9faa315079124) au 783574450/783574436; (raw-7fa1c1f5f6ac2ec6, raw-affeea04e64fe893) au 754835715/790224047 | near-duplicate units (8 SKU slots) | keep, same group |
| close-read-defects / close-read-ambiguous | medium | raw-7f04455a83ac52c8: Rakuten "ALLCOVER TIGHTS act-01" vs au "ACTLEG calf supporter ACTLEG-01" = different products of one maker (sibling pair raw-6f3e94e5ed512da7 looks right). raw-12f3057cc81c6d73: au title says tank top/sleeveless/antibacterial quick-dry, au description says cotton 100% short-sleeve 2-pack inner (= Rakuten) | close read | correct outputs unmatched/review; recorded separately | list in report |
| pair-doubt-low-title-overlap | info | 5 pairs with title bigram Jaccard < 0.12; close read shows they are real partial overlaps (device-model subsets: AQUOS R9/R10 vs Rakuten 7 models, iPhone16 series) | raw-dda5335fb4fea120, raw-949d7779a78625df ... | none | - |
| extra-options-unobserved | medium (known) | has_paid_options=true in 16 au pages (e.g. tent "グランドシート付" is a Rakuten SKU but an au paid option); value lists null everywhere | raw-23a256226c40db65, raw-23dd1d3cb8a0ab88 | such SKUs can at best be "conditional" | keep conditional class |
| aux-granularity | info | Rakuten 代表カラー (coarse) is not literally in the selector values for 627/1,634 rows (e.g. オーカー -> イエロー) | computed | a naive model may call these conflicts | prompt rule: auxiliary attrs are not selector conditions |
| trivial-rule | info | normalized exact selector-value match finds a unique au row for 644/1,934 (33.3%); 1,290 have no exact row; 62 pairs have none | computed | rules alone leave 2/3 open, and value identity is not proof of a full match | LLM step worth optimizing; rule shortcut is an efficiency lever |
| injection-like-text | info | 0 instruction-like strings in titles/descriptions | regex | - | prompts still treat data as untrusted |
| scope naming | info | the README calls the main set "通常用途ボリュームテスト用"; the user's "通常使用版 (au_only_stressは使わない)" is read as: the 152-pair main set; au_only_stress excluded | README + request | none | stated in report |

## Close read (17 pairs, stratified by bucket x axis asymmetry x exact-match coverage; audit/close_read.jsonl)
Verdicts: ok 4, hard 11, ambiguous 1 (raw-12f3057cc81c6d73, au page contradicts itself), defect 1
(raw-7f04455a83ac52c8, different products; severity medium because the brief prescribes "record pair doubts
separately" and scoring stays defined - expected unmatched/review; reported as its own stratum).
Note: the audit read happened before the split; raw-7f04455a83ac52c8 later fell into holdout (no rule was
derived from it). Model-assisted screen (Opus reference pair_assessment, added after the gate): dev 0 'different'
/ 1 'unclear' (= raw-12f3057cc81c6d73) of 50; holdout 1 'different' of 41 (counts only) -> pair defects ~2%.
What makes items hard (genuine, keep):
- Quantity axis on one side only, fixed on the other side via title ("2枚組") -> Rakuten 1枚 rows have no au row.
- Device-model axis on Rakuten (7 AQUOS models / S25 vs S25 Ultra) vs au page for one or two models (title/spec table):
  only the supported model's rows match; others unmatched.
- Combined values: au "01.ホワイト（Vネック）" = Rakuten colour + neckline axes.
- Unit / spelling variants: 21.0 vs 21.0cm, サックスブルー vs サックス, Sサイズ vs S.
- Add-ons: Rakuten SKU "グランドシート付（+780円）" or パニエ/ヘアアクセサリー "つける" vs au paid options (conditional).
- Rakuten size value "サイズ指定 別途+2230円" appears on both sides (custom-size row).
- Rakuten has more rows than au in 27 pairs (subset coverage), fewer in 16.
Easy: same axes and values after trivial normalization (80 pairs fully covered by exact values).
Defects vs hard cases: only the pair doubts and duplicate au listings look like data defects; none blocks the task.

## Difficulty and strata (report breakdowns)
- axis asymmetry: equal 116 / unequal 36 pairs.
- size: Rakuten SKUs per pair median 6, max 60 (largest_20 holds 840 of 1,934 slots).
- Rakuten description: spec_table 13 / full body 105 / effectively empty 34.
- au paid options: 16 pairs.
- exact-value coverage: full 80 / partial 10 / zero 62 pairs.

## Trivial-solution and shortcut checks
Exact normalized selector-value equality decides at most 33% of SKUs and cannot detect fixed-spec, option or pair-level
conflicts. LLM optimization is worthwhile; a rule pre-pass is a candidate efficiency lever, not a solution.
Shortcuts/leakage: no answer keys in the inputs (au sku_key = au:<item>:<sku>:<row>:<col>, carries no Rakuten
information); model numbers shared by both pages (variant_id / 型番 in au text) are legitimate evidence. No labels
exist, so label leakage is impossible; the reference is built in this workspace (see eval_spec.md).

## Scope
In scope: all 152 pairs / 1,934 Rakuten SKU slots (1,845 unique) / 1,600 au rows. Nothing excluded for price or stock.
Excluded: au_only_stress (58 products, 2,937 SKUs) - user instruction and brief (load set, no Rakuten side).
packets/ not read (duplicate representation).

## Gate
PASS (re-run 2026-10-18 15:5x UTC under the updated skill with close_read.jsonl and provenance.jsonl as aux):
no critical/high unknown findings. Medium findings (effectively empty Rakuten descriptions, duplicated
Rakuten pages / au listings, two pair doubts) are carried into the report and handled by group-aware splits and strata.
