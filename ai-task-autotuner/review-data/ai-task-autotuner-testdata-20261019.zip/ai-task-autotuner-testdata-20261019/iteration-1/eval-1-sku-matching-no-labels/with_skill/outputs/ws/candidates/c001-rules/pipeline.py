"""c001-rules: no-model baseline (code only).

Per pair:
1. Normalize selector values (NFKC, lower case, no spaces, trailing サイズ/cm dropped, bracketed parts split
   into extra tokens: "01.ホワイト（Vネック）" -> {"01.ホワイト（vネック）", "01.ホワイト", "vネック"}).
2. Axes with a single value on one side are page-level facts and are not required on the other side.
3. Rakuten row R and au row A correspond when every varying value of A is covered by a token of R and every
   varying value of R is covered by a token of A (equality, or containment with >= 2 characters).
4. Exactly one corresponding au row -> matched; several -> review; none -> unmatched when R's value on some
   varying axis is absent from au although other values of that axis do appear on au (explicit conflict),
   otherwise also unmatched (no corresponding row). Never conditional (code cannot read option text).
"""
import re
import unicodedata


def _n(s):
    s = unicodedata.normalize("NFKC", s).lower()
    s = re.sub(r"\s+", "", s)
    s = re.sub(r"(サイズ|size)$", "", s)
    s = re.sub(r"(?<=\d)cm$", "", s)
    return s


def tokens(v):
    n = _n(v)
    out = {n}
    for part in re.split(r"[()\[\]（）【】/／・]+", n):
        if len(part) >= 1:
            out.add(part)
    base = re.sub(r"[(（\[【].*?[)）\]】]", "", n)
    if base:
        out.add(base)
    return {t for t in out if t}


def covered(v, toks):
    n = _n(v)
    for t in toks:
        if n == t:
            return True
        if len(n) >= 2 and len(t) >= 2 and (n in t or t in n):
            return True
    return False


def run(unit, ctx):
    rec = unit["input"]
    R, A = rec["rakuten"], rec["au"]

    def varying(side):
        return {a["axis_index"] for a in side["sku_axes"] if len(a["values"]) > 1}
    rv, av = varying(R), varying(A)
    a_rows = []
    for s in A["skus"]:
        toks = set().union(*[tokens(c["value"]) for c in s["conditions"]])
        a_rows.append((s["sku_key"], s, toks))
    all_au_tokens = set().union(*[t for _, _, t in a_rows]) if a_rows else set()
    results = []
    n_rule = 0
    for s in R["skus"]:
        rtoks = set().union(*[tokens(c["value"]) for c in s["conditions"]])
        hits = []
        for key, a, atoks in a_rows:
            ok = all(covered(c["value"], rtoks) for c in a["conditions"] if c["axis_index"] in av)
            ok = ok and all(covered(c["value"], atoks) for c in s["conditions"] if c["axis_index"] in rv)
            if ok:
                hits.append(key)
        if len(hits) == 1:
            d, ak, why = "matched", hits[0], "all varying selector values correspond (rule)"
        elif len(hits) > 1:
            d, ak, why = "review", None, f"{len(hits)} au rows correspond equally (rule)"
        else:
            conflict = None
            for c in s["conditions"]:
                if c["axis_index"] not in rv or covered(c["value"], all_au_tokens):
                    continue
                axis = next(a for a in R["sku_axes"] if a["axis_index"] == c["axis_index"])
                if any(covered(v, all_au_tokens) for v in axis["values"] if v != c["value"]):
                    conflict = c
                    break
            if conflict:
                d, ak, why = "unmatched", None, f"{conflict['name']}={conflict['value']} absent on au while other values of that axis exist (rule)"
            else:
                d, ak, why = "unmatched", None, "no au row corresponds (rule; code cannot verify page-level facts)"
        n_rule += 1
        results.append({"rakuten_sku_key": s["sku_key"], "decision": d, "au_sku_key": ak,
                        "required_extra_options": [], "unresolved_conditions": [] if d != "review" else [why],
                        "evidence_refs": [], "reason": why})
    ctx.count("rule_decided", n_rule)
    return {"product_pair_id": rec["product_pair_id"], "pair_assessment": None, "results": results}
