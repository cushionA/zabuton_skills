Runs voided by subscription-quota exhaustion (~10:52-15:49 UTC 2026-10-18; harness errors 37-42 of 41-50 units).
Moved out of runs/ so the ledger does not pool them with valid runs. Kept for the record; never used for decisions.
- E001__dev__baseline__20261018-105117568: 42/50 units harness_error (quota) -> E001 re-run after the reset.
- ref-opus-v2__{dev,holdout}__reference__refC_*: third-opinion reference variant; not re-run (quota caution); not used.
