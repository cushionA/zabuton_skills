# Journal

Concise English. One block per experiment; rewrite Learnings as they change.

## Learnings (max ~20 bullets; what is true about this task and model)
- Opus reference (effort high, text rendering) is very self-consistent: dev 8.9% disagreement concentrated in 2 pairs
  (2-item set unmatched vs review; fox-fur paid option matched vs conditional); holdout 0%. Two same-prompt runs are
  NOT independent evidence -> reference = one Opus judgment + adjudication; human check still recommended.
- Reference label shares on dev (642): matched ~62%, unmatched ~17%, review ~15%, conditional ~7%.
- Code-only rule (normalize values, page-level single-value axes ignored, cover both ways) agrees 0.497 on dev with
  0 wrong links; it never finds unmatched-by-fixed-spec (title "2枚組", model-only pages) or conditional.
- Haiku effort low still emits thinking tokens via claude -p (~900/call on small pairs).
- Quota: 2x(50+41) Opus calls at effort high plus a parallel job exhausted the shared subscription quota (~10:52 UTC);
  runs after that were void (moved to runs_void/).

## Idea backlog (group: idea - evidence - status)
- decomposition.split: value-level mapping per axis + code join - long outputs on 40-60-row pairs - open
- deterministic.pre: rule-matched rows given to the model as proposals / decided by code - rule precision 0.88 - open
- input.representation: table rows instead of nested JSON - open
- input.selection: drop boilerplate/shipping lines from descriptions - cost - open

## Log
- 10:33-10:52 audit (gate PASS, old skill), splits, reference ref-opus A/B on dev+holdout, adjudication (dev 57 items:
  30 label, 27 acceptable -> overridden to conditional after reading ad24-25). Quota exhausted 10:52; clock paused.
- 15:49 resumed under updated skill: close_read.jsonl (17 units), provenance as aux, gate re-run PASS; void runs moved.
- c001-rules smoke (code only) dev agreement 0.497, wrong_link 0, link precision 0.88, recall 0.62.
E001 baseline (c000): pooled 0.857 (r1 0.899 / r2 0.815) | cost $0.0026/unit | asym 0.77/0.57 vs sym 0.98/0.97
  noise: whole-unit flips on 3 ambiguous pairs (105 items); validator band 0.032 understates it -> min_delta 0.04, 2 runs/candidate
E002 deterministic.pre (c001-rules, code only): 0.597 DISCARD (-0.26); trivial exact-match rule 0.559. NO-LLM gap ~0.29.
E003 prompt.instructions (c002-spec-rules <- c000): complete task rules -> 0.888/0.886 KEEP (tie +0.030, cost x0.85)
  much more stable (runs differ 0.002); new failure: over-conditional on unrelated au options (gift wrap, embroidery, 同梱)
E004 prompt.instructions (c003-option-scope <- c002): narrow the add-on rule -> 0.838/0.774 DISCARD
  why: model became less cautious overall (raw-3486110e019a2015 60 rows matched despite 0.02ct vs 0.2ct; fox-fur matched)
EVAL v2: raw-457e312a33caba50 train rows matched->conditional (identical au pattern to fox-fur raw-0908: variant value names
  the paid add-on + description says also select 付ける). All runs rescored; validation re-run (eval_hash 65ac634e).
  Rescored: E001 0.889/0.805, E003 0.897/0.896, E004 0.829/0.765.
