"""Units of work: one Rakuten/au product pair (inputs/products.jsonl line). Frozen once validated.

load_units(split) -> [{"id": product_pair_id, "input": record}]
group_of(unit)    -> Rakuten product URL (6 Rakuten pages appear in two pairs; they must share a split)
stratum_of(unit)  -> axis asymmetry x size bucket

Splits (made once, never by score):
  dev     = subsets.json normal_50 (provider-defined 50 pairs, representative by counts)
  holdout = 40 pairs drawn random, proportionally stratified, group-aware, from pairs whose Rakuten page is not in dev
  full    = all 152 pairs; rest = pairs in neither dev nor holdout
  smoke_10, largest_20 = provider subsets (for reference only)

  python eval/dataset.py --make-splits --holdout 40 --seed 0
"""
import argparse
import json
import sys
from pathlib import Path

WS = Path(__file__).resolve().parents[1]
CHARTER = json.loads((WS / "charter.json").read_text(encoding="utf-8"))
sys.path.insert(0, str(Path(CHARTER["skill_dir"]) / "scripts"))
from common import read_json, write_json  # noqa: E402
import random

ID_FIELD = "product_pair_id"
_CACHE = {}


def _records():
    if "recs" not in _CACHE:
        path = CHARTER["data"]["inputs"][0]
        with open(path, encoding="utf-8") as f:
            recs = [json.loads(line) for line in f if line.strip()]
        _CACHE["recs"] = {str(r[ID_FIELD]): r for r in recs}
    return _CACHE["recs"]


def load_units(split):
    recs = _records()
    splits = read_json(WS / "eval" / "splits.json", {})
    ids = list(recs) if split == "all" else splits[split]
    return [{"id": i, "input": recs[i]} for i in ids]


def group_of(unit):
    return unit["input"]["rakuten"]["url"]


def size_bucket(n):
    return "s" if n <= 4 else ("m" if n <= 15 else "l")


def stratum_of(unit):
    r = unit["input"]
    asym = "asym" if len(r["rakuten"]["sku_axes"]) != len(r["au"]["sku_axes"]) else "sym"
    return f"{asym}-{size_bucket(len(r['rakuten']['skus']))}"


def proportional_sample(pool, n, seed):
    """Group-aware sample with stratum quotas proportional to the pool (largest remainder)."""
    rng = random.Random(seed)
    groups = {}
    for u in pool:
        groups.setdefault(group_of(u), []).append(u)
    by_s = {}
    for g, members in sorted(groups.items()):
        by_s.setdefault(stratum_of(members[0]), []).append(g)
    total = len(pool)
    raw = {s: n * sum(len(groups[g]) for g in gs) / total for s, gs in by_s.items()}
    quota = {s: int(v) for s, v in raw.items()}
    for s in sorted(raw, key=lambda s: raw[s] - quota[s], reverse=True)[: n - sum(quota.values())]:
        quota[s] += 1
    out = []
    for s in sorted(by_s):
        gs = by_s[s][:]
        rng.shuffle(gs)
        got = []
        for g in gs:
            if len(got) >= quota[s]:
                break
            got += [u["id"] for u in groups[g]]
        out += got
    return out


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--make-splits", action="store_true")
    ap.add_argument("--holdout", type=int, default=40)
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()
    if a.make_splits:
        subsets = json.loads(Path(CHARTER["data"]["inputs"][1]).read_text(encoding="utf-8"))
        units = load_units("all")
        by_id = {u["id"]: u for u in units}
        dev = list(subsets["normal_50"])
        dev_groups = {group_of(by_id[i]) for i in dev}
        pool = [u for u in units if u["id"] not in dev and group_of(u) not in dev_groups]
        hold = proportional_sample(pool, a.holdout, a.seed)
        full = [u["id"] for u in units]
        out = {"dev": dev, "holdout": hold, "full": full,
               "rest": [i for i in full if i not in set(dev) | set(hold)],
               "smoke_10": subsets["smoke_10"], "largest_20": subsets["largest_20"],
               "_note": "dev=normal_50; holdout=random proportional-stratified group-aware (seed %d) from pairs whose Rakuten "
                        "page is not in dev; group=Rakuten URL" % a.seed}
        write_json(WS / "eval" / "splits.json", out)
        print({k: len(v) for k, v in out.items() if isinstance(v, list)})
