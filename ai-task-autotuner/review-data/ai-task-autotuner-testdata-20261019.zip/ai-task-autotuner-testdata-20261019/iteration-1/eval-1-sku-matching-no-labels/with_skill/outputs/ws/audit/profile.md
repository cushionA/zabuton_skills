## /tmp/claude-0/-home-user-zabuton-skills/63e4c5c7-d309-596e-8dd4-3c5a2c09efb2/scratchpad/inputs/sku-normal-v1/inputs/products.jsonl  (records, 4,162,677 bytes, 152 records, dup_records=0)
| path | rec% | null% | types | distinct | len/num min/p50/p90/max | dups | notes |
|---|---|---|---|---|---|---|---|
| au | 100.0 | 0.0 | object |  |  |  |  |
| au.description | 100.0 | 0.0 | object |  |  |  |  |
| au.description.lines | 100.0 | 0.0 | list |  | len 0/26/71/166 |  |  |
| au.description.lines[] | 99.3 | 0.0 | object |  |  |  |  |
| au.description.lines[].evidence_id | 99.3 | 0.0 | string | 166 | len 19/19/19/19 |  |  |
| au.description.lines[].text | 99.3 | 0.0 | string | 3340 | len 0/20/46/601 |  |  |
| au.description.links | 100.0 | 0.0 | list |  | len 0/0/4/15 |  |  |
| au.description.links[] | 47.4 | 0.0 | object |  |  |  |  |
| au.description.links[].href | 47.4 | 0.0 | string | 137 | len 0/38/65/166 |  |  |
| au.description.links[].text | 47.4 | 0.0 | string | 29 | len 0/0/19/86 |  | top: (203), ※概要はキャンペーンページをご確認ください。(17), 新着商品はコチラ(7), カテゴリ別検索(7) |
| au.description.mode | 100.0 | 0.0 | string | 3 | len 10/18/18/18 |  | top: full_body_fallback(103), spec_table(48), unavailable(1) |
| au.description.text | 100.0 | 0.0 | string | 132 | len 0/760/1904/3285 | 28 | dup e.g. ＜材質＞ ポリエステル 85％、ナイロン 15％ ＜カラー・セット内容＞ アジサ ; ★送料★ 1点 550円(沖縄・離島は1点1550円) 複数同時購入の場合、1点 |
| au.description.text_sha256 | 100.0 | 0.0 | string | 149 | len 64/64/64/64 | 6 | dup e.g. b6f75c755d05d1db6d04e2cc4253dfae25863315 ; b9373c529d2b77021754d804e9d1a14fda573b01 |
| au.non_sku_options | 100.0 | 0.0 | object |  |  |  |  |
| au.non_sku_options.complete_value_lists | 100.0 | 100.0 | null |  |  |  |  |
| au.non_sku_options.current_selected_values | 100.0 | 100.0 | null |  |  |  |  |
| au.non_sku_options.has_free_options | 100.0 | 0.0 | bool | 2 |  |  | top: True(137), False(15) |
| au.non_sku_options.has_paid_options | 100.0 | 0.0 | bool | 2 |  |  | top: False(136), True(16) |
| au.non_sku_options.observed_unselected_text | 100.0 | 0.0 | list |  | len 0/1/3/6 |  |  |
| au.non_sku_options.observed_unselected_text[] | 90.1 | 0.0 | string | 97 | len 3/20/44/66 |  |  |
| au.product_id | 100.0 | 0.0 | string | 152 | len 9/9/9/9 | 0 | KEY? |
| au.sku_axes | 100.0 | 0.0 | list |  | len 1/2/2/2 |  |  |
| au.sku_axes[] | 100.0 | 0.0 | object |  |  |  |  |
| au.sku_axes[].axis_index | 100.0 | 0.0 | number | 2 | num 0/0.0/1 |  | top: 0(152), 1(84) |
| au.sku_axes[].name | 100.0 | 0.0 | string | 41 | len 1/3/5/31 |  |  |
| au.sku_axes[].values | 100.0 | 0.0 | list |  | len 1/3/8/27 |  |  |
| au.sku_axes[].values[] | 100.0 | 0.0 | string | 542 | len 1/5/13/22 |  |  |
| au.skus | 100.0 | 0.0 | list |  | len 1/5/27/60 |  |  |
| au.skus[] | 100.0 | 0.0 | object |  |  |  |  |
| au.skus[].conditions | 100.0 | 0.0 | list |  | len 1/2/2/2 |  |  |
| au.skus[].conditions[] | 100.0 | 0.0 | object |  |  |  |  |
| au.skus[].native_column_index | 100.0 | 0.0 | number | 13 | num 0/1.0/12 |  | top: 0(703), 1(340), 2(274), 3(125) |
| au.skus[].native_row_index | 100.0 | 0.0 | number | 27 | num 0/2.0/26 |  | top: 0(373), 1(248), 2(203), 3(173) |
| au.skus[].sku_key | 100.0 | 0.0 | string | 1600 | len 25/26/27/27 |  |  |
| au.title | 100.0 | 0.0 | string | 150 | len 22/124/149/162 | 4 | dup e.g. クッションファンデーション 日本製 美容成分配合 SPF50 PA＋＋＋＋ ツヤ ; ＼即納／ ショルダーバッグ リュック トートバッグ レディース 3way バッグ |
| au.url | 100.0 | 0.0 | string | 152 | len 31/31/31/31 | 0 | KEY? |
| product_pair_id | 100.0 | 0.0 | string | 152 | len 20/20/20/20 | 0 | KEY? |
| rakuten | 100.0 | 0.0 | object |  |  |  |  |
| rakuten.description | 100.0 | 0.0 | object |  |  |  |  |
| rakuten.description.lines | 100.0 | 0.0 | list |  | len 0/24/54/68 |  |  |
| rakuten.description.lines[] | 93.4 | 0.0 | object |  |  |  |  |
| rakuten.description.lines[].evidence_id | 93.4 | 0.0 | string | 68 | len 24/24/24/24 |  |  |
| rakuten.description.lines[].text | 93.4 | 0.0 | string | 2256 | len 2/23/47/946 |  |  |
| rakuten.description.links | 100.0 | 0.0 | list |  | len 0/0/9/16 |  |  |
| rakuten.description.links[] | 46.7 | 0.0 | object |  |  |  |  |
| rakuten.description.links[].href | 46.7 | 0.0 | string | 166 | len 40/49/68/132 |  |  |
| rakuten.description.links[].text | 46.7 | 0.0 | string | 29 | len 0/0/30/92 |  | top: (174), メーカー希望小売価格はメーカーサイトに基づいて掲載しています(26), 返品・交換・キャンセルについて(16), ギフト対応(6) |
| rakuten.description.mode | 100.0 | 0.0 | string | 3 | len 10/18/18/18 |  | top: full_body_fallback(129), spec_table(13), unavailable(10) |
| rakuten.description.text | 100.0 | 0.0 | string | 112 | len 0/642/1618/2636 | 51 | dup e.g. メーカー希望小売価格はメーカーサイトに基づいて掲載しています ; ＜材質＞ ポリエステル 85％、ナイロン 15％ ＜カラー・セット内容＞ アジサ |
| rakuten.description.text_sha256 | 100.0 | 0.0 | string | 113 | len 64/64/64/64 | 49 | dup e.g. 58351d01bd54b2c04cf583cc012d520b26b72d3c ; 4e3b6e06a04d99f94a67b327626564a510c03d55 |
| rakuten.sku_axes | 100.0 | 0.0 | list |  | len 1/2/2/4 |  |  |
| rakuten.sku_axes[] | 100.0 | 0.0 | object |  |  |  |  |
| rakuten.sku_axes[].axis_index | 100.0 | 0.0 | number | 4 | num 0/0.0/3 |  | top: 0(152), 1(99), 2(11), 3(2) |
| rakuten.sku_axes[].name | 100.0 | 0.0 | string | 63 | len 1/3/7/27 |  |  |
| rakuten.sku_axes[].values | 100.0 | 0.0 | list |  | len 1/3/8/20 |  |  |
| rakuten.sku_axes[].values[] | 100.0 | 0.0 | string | 565 | len 1/5/13/22 |  |  |
| rakuten.skus | 100.0 | 0.0 | list |  | len 1/6/36/60 |  |  |
| rakuten.skus[] | 100.0 | 0.0 | object |  |  |  |  |
| rakuten.skus[].auxiliary_attributes | 100.0 | 0.0 | list |  | len 0/8/13/22 |  |  |
| rakuten.skus[].auxiliary_attributes[] | 99.3 | 0.0 | object |  |  |  |  |
| ... 8 more paths in the .json |
## /tmp/claude-0/-home-user-zabuton-skills/63e4c5c7-d309-596e-8dd4-3c5a2c09efb2/scratchpad/inputs/sku-normal-v1/subsets.json  (records, 6,581 bytes, 1 records, dup_records=0)
| path | rec% | null% | types | distinct | len/num min/p50/p90/max | dups | notes |
|---|---|---|---|---|---|---|---|
| all_152 | 100.0 | 0.0 | list |  | len 152/152/152/152 |  |  |
| all_152[] | 100.0 | 0.0 | string | 152 | len 20/20/20/20 |  |  |
| largest_20 | 100.0 | 0.0 | list |  | len 20/20/20/20 |  |  |
| largest_20[] | 100.0 | 0.0 | string | 20 | len 20/20/20/20 |  | top: raw-ff9c0ccaa24b6bff(1), raw-cc9592c3e34ae4ed(1), raw-ac8fd1a7cbd8cfe2(1), raw-5c0aa587141c5f27(1) |
| normal_50 | 100.0 | 0.0 | list |  | len 50/50/50/50 |  |  |
| normal_50[] | 100.0 | 0.0 | string | 50 | len 20/20/20/20 |  |  |
| smoke_10 | 100.0 | 0.0 | list |  | len 10/10/10/10 |  |  |
| smoke_10[] | 100.0 | 0.0 | string | 10 | len 20/20/20/20 |  | top: raw-5368b4a54d1b762d(1), raw-a0b32008327edad6(1), raw-2fc336c20bf4ad86(1), raw-db7b5bc1d66dddfa(1) |
