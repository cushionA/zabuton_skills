# Eval spec - rakuten-au-sku-matching

## Unit, item, label
- Unit: one product pair (inputs/products.jsonl line). Item: one Rakuten SKU slot, key `<pair_id>|<rakuten_sku_key>`.
- Label: `matched:<au_sku_key>` | `conditional:<au_sku_key>` | `unmatched` | `review`.
  (`review` ignores any candidate au row; `conditional` requires the right au row AND an extra-option condition.)
- Pipeline output = one object per pair with one result per Rakuten SKU (schema of
  schemas/suggested-response.schema.json + `pair_assessment`); every Rakuten key exactly once.

## Metrics (eval/score.py)
- primary = agreement with the silver reference over all referenced items of the split; unit failures and
  missing items count as wrong. Named "agreement with Opus silver reference", not accuracy.
- guards: wrong_link_rate (pred links a row the reference rejects: ref unmatched or another row) may rise at most
  +0.01 over the best; missing_or_failed_rate <= 0.02.
- diagnostics: overclaim (pred link, ref review), link_type (right row, matched<->conditional), missed_link,
  link precision/recall, auto_decided_rate (matched+unmatched), decision shares, agreement asym/sym, unit macro.
- hard gates: results list present, Rakuten keys known and unique, au keys belong to the pair, decision valid,
  link decisions carry an au key.
- trivial baseline (score.trivial): unique exact normalized selector-value match -> matched, else unmatched.

## Splits (eval/splits.json)
- dev = provider subset normal_50: 50 pairs, 642 slots.
- holdout = 41 pairs, 544 slots: random (seed 0), proportional strata (axis asymmetry x Rakuten size bucket),
  group-aware (group = Rakuten URL; the 6 Rakuten pages used twice never straddle splits; pairs sharing a Rakuten
  page with dev are excluded from holdout).
- rest = 61 pairs (no reference; full-scope run only). full = 152.

## Reference (silver)
- ref-opus: Opus 5.5 via claude -p 2.1.302, effort high, text rendering with all evidence; run twice (refA, refB)
  per split. dev: 585/642 agreed (8.9% disagreement, all in 2 pairs); holdout: 544/544 agreed.
- ref-opus-v2: Opus, effort high, JSON rendering + reworded prompt, run once per split as a decorrelating third
  opinion; items where it differs from the agreed label are adjudicated as well.
- Adjudication: tools/adjudicate.py - a separate Opus call per pair that sees the data, the rules and both answers
  (claims, not evidence) and returns a label / acceptable set / exclude. dev: verdicts read by me; 27 acceptable
  sets {matched, conditional} for fox-fur rows of raw-0908bb952709f362 overridden to conditional after reading
  ad24-25 (fox fur requires the paid option "つける"). holdout: adjudicated by the tool only; I saw counts only.
- Spot-check (dev): 29 stratified agreed items read against the data; no reference error found.
- Not human-verified (user unavailable). Blind spots shared with Opus remain.

## Validation
See eval/validation.json (null, oracle, determinism, corruption, reference coverage, rescore, noise from two
baseline runs, spot-check note).
