"""Show reference items compactly: python tools/show_ref.py WS SPLIT RUN_DIR [--sample N --seed S | --pair ID]"""
import json, sys, random, collections
from pathlib import Path
ws=Path(sys.argv[1]); split=sys.argv[2]; run=Path(sys.argv[3])
args=sys.argv[4:]
ch=json.loads((ws/'charter.json').read_text())
sys.path.insert(0,str(Path(ch['skill_dir'])/'scripts')); sys.path.insert(0,str(ws/'eval'))
from common import load_reference
import dataset
units={u['id']:u['input'] for u in dataset.load_units(split)}
ref=load_reference(ws,split); ref.pop('__unresolved__')
reasons={}
for l in open(run/'outputs.jsonl'):
    r=json.loads(l)
    if r['status']=='ok':
        for x in r['output']['results']: reasons[f"{r['id']}|{x['rakuten_sku_key']}"]=x
keys=list(ref)
if '--pair' in args:
    keys=[k for k in keys if k.startswith(args[args.index('--pair')+1])]
else:
    n=int(args[args.index('--sample')+1]); seed=int(args[args.index('--seed')+1]) if '--seed' in args else 0
    by=collections.defaultdict(list)
    for k in keys: by[(ref[k].get('label') or 'acc').split(':')[0]].append(k)
    rng=random.Random(seed); keys=[]
    for lab,ks in sorted(by.items()): rng.shuffle(ks); keys+=ks[:max(1,n*len(ks)//len(ref))]
for k in keys:
    pid,rk=k.split('|',1); rec=units[pid]
    rs=[s for s in rec['rakuten']['skus'] if s['sku_key']==rk][0]
    lab=ref[k].get('label') or ref[k].get('acceptable')
    au=''
    if isinstance(lab,str) and ':' in lab:
        ak=lab.split(':',1)[1]; a=[s for s in rec['au']['skus'] if s['sku_key']==ak][0]
        au=' -> '+'/'.join(c['value'] for c in a['conditions'])
    x=reasons.get(k,{})
    print(f"{pid} R{rec['rakuten']['skus'].index(rs)} [{'/'.join(c['value'] for c in rs['conditions'])}] {str(lab).split(':')[0]}{au} | {x.get('reason','')[:170]}")
