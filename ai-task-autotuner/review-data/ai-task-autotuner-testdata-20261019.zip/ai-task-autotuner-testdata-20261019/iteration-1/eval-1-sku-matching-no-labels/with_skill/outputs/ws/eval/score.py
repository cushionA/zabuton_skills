"""Frozen scorer for Rakuten -> au SKU matching.

Pipeline output per unit (one product pair):
  {"product_pair_id": ..., "results": [{"rakuten_sku_key", "decision", "au_sku_key",
     "required_extra_options", "unresolved_conditions", "evidence_refs", "reason"}, ...]}
decision in matched | conditional | unmatched | review.

Item = one Rakuten SKU slot, key "<pair_id>|<rakuten_sku_key>". Label (for comparison):
  "matched:<au_sku_key>" | "conditional:<au_sku_key>" | "unmatched" | "review"
Reference: eval/reference/<split>*.jsonl (silver: Opus x2 + adjudication); entries may carry an
"acceptable" set for genuinely ambiguous items, or "exclude".

primary = agreement with the reference label over all referenced items (missing/failed = wrong).
Guards/diagnostics:
  wrong_link_rate   pred links to au row K, reference says unmatched or a different row (no acceptable label
                    links to K and none is "review")  -> false accept, guarded
  overclaim_rate    pred links to K, reference says review only
  link_precision    share of predicted links that agree with the reference
  link_recall       share of reference links reproduced exactly
  auto_decided_rate share of items predicted matched or unmatched (coverage, not accuracy)
Hard gates: output shape, unknown/duplicate Rakuten keys, au keys not in the pair, bad decision values,
links without an au key.
"""
import json
import sys
from pathlib import Path

WS = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(json.loads((WS / "charter.json").read_text(encoding="utf-8"))["skill_dir"]) / "scripts"))
from common import load_reference  # noqa: E402

DECISIONS = ("matched", "conditional", "unmatched", "review")
LINKS = ("matched", "conditional")


def expected_keys(unit):
    return [s["sku_key"] for s in unit["input"]["rakuten"]["skus"]]


def label_of(res):
    d = res.get("decision")
    if d in LINKS:
        return f"{d}:{res.get('au_sku_key')}"
    return d


def _link_key(label):
    if isinstance(label, str) and ":" in label and label.split(":", 1)[0] in LINKS:
        return label.split(":", 1)[1]
    return None


def flatten(unit, output):
    if not isinstance(output, dict):
        return {}
    out = {}
    for r in output.get("results", []) or []:
        if isinstance(r, dict) and r.get("rakuten_sku_key") is not None:
            out.setdefault(f"{unit['id']}|{r['rakuten_sku_key']}", label_of(r))
    return out


def _gate(unit, output):
    errs = []
    if not isinstance(output, dict) or not isinstance(output.get("results"), list):
        return [f"{unit['id']}: output has no results list"]
    rk = set(expected_keys(unit))
    ak = {s["sku_key"] for s in unit["input"]["au"]["skus"]}
    seen = set()
    for r in output["results"]:
        if not isinstance(r, dict):
            errs.append(f"{unit['id']}: non-object result")
            continue
        k = r.get("rakuten_sku_key")
        if k not in rk:
            errs.append(f"{unit['id']}: unknown rakuten key {str(k)[:60]}")
        if k in seen:
            errs.append(f"{unit['id']}: duplicate rakuten key {str(k)[:60]}")
        seen.add(k)
        d = r.get("decision")
        if d not in DECISIONS:
            errs.append(f"{unit['id']}: bad decision {d!r}")
        a = r.get("au_sku_key")
        if a is not None and a not in ak:
            errs.append(f"{unit['id']}: au key not in pair {str(a)[:60]}")
        if d in LINKS and a is None:
            errs.append(f"{unit['id']}: {d} without au key")
    return errs


def _acceptable(entry):
    return entry["acceptable"] if "acceptable" in entry else [entry.get("label")]


def score(units, outputs, split):
    ref = load_reference(WS, split)
    ref.pop("__unresolved__", None)
    items, gate = [], []
    excluded = 0
    for u in units:
        out = outputs.get(u["id"])
        if out is not None:
            gate += _gate(u, out)
        pred = flatten(u, out) if out is not None else {}
        asym = len(u["input"]["rakuten"]["sku_axes"]) != len(u["input"]["au"]["sku_axes"])
        for k in expected_keys(u):
            key = f"{u['id']}|{k}"
            entry = ref.get(key)
            if entry is None:
                continue
            if entry.get("exclude"):
                excluded += 1
                continue
            acc = _acceptable(entry)
            p = pred.get(key)
            ok = p in acc
            tags = []
            if out is None:
                tags.append("unit_failed")
            elif key not in pred:
                tags.append("missing")
            pl = _link_key(p)
            ref_links = {_link_key(x) for x in acc if _link_key(x)}
            if not ok:
                pd = (p or "none").split(":")[0]
                rd = "/".join(sorted({(x or "none").split(":")[0] for x in acc}))
                tags.append(f"pred:{pd}")
                tags.append(f"ref:{rd}")
                if pl is not None:
                    if "review" in acc and not ref_links:
                        tags.append("overclaim")
                    elif pl in ref_links:
                        tags.append("link_type")  # right row, matched vs conditional differs
                    else:
                        tags.append("wrong_link")
                elif ref_links:
                    tags.append("missed_link")
            tags.append("asym" if asym else "sym")
            items.append({"id": key, "unit": u["id"], "score": 1.0 if ok else 0.0, "tags": tags,
                          "pred": p, "ref": acc[0] if len(acc) == 1 else acc})
    n = len(items)

    def rate(pred_fn):
        return sum(1 for i in items if pred_fn(i)) / n if n else 0.0

    primary = rate(lambda i: i["score"] == 1.0)
    preds = [i["pred"] for i in items]
    n_links = sum(1 for p in preds if _link_key(p))
    links_ok = sum(1 for i in items if _link_key(i["pred"]) and i["score"] == 1.0)
    ref_link_items = [i for i in items if any(_link_key(x) for x in (i["ref"] if isinstance(i["ref"], list) else [i["ref"]]))]
    asym_items = [i for i in items if "asym" in i["tags"]]
    sym_items = [i for i in items if "sym" in i["tags"]]
    unit_scores = {}
    for i in items:
        unit_scores.setdefault(i["unit"], []).append(i["score"])
    metrics = {
        "agreement": primary,
        "n_items": n,
        "n_excluded": excluded,
        "wrong_link_rate": rate(lambda i: "wrong_link" in i["tags"]),
        "overclaim_rate": rate(lambda i: "overclaim" in i["tags"]),
        "link_type_rate": rate(lambda i: "link_type" in i["tags"]),
        "missed_link_rate": rate(lambda i: "missed_link" in i["tags"]),
        "missing_or_failed_rate": rate(lambda i: "missing" in i["tags"] or "unit_failed" in i["tags"]),
        "link_precision": links_ok / n_links if n_links else 0.0,
        "link_recall": (sum(1 for i in ref_link_items if i["score"] == 1.0) / len(ref_link_items)) if ref_link_items else 0.0,
        "auto_decided_rate": rate(lambda i: i["pred"] == "unmatched" or str(i["pred"]).startswith("matched:")),
        "pred_matched": rate(lambda i: str(i["pred"]).startswith("matched:")),
        "pred_conditional": rate(lambda i: str(i["pred"]).startswith("conditional:")),
        "pred_unmatched": rate(lambda i: i["pred"] == "unmatched"),
        "pred_review": rate(lambda i: i["pred"] == "review"),
        "agreement_asym": (sum(i["score"] for i in asym_items) / len(asym_items)) if asym_items else None,
        "agreement_sym": (sum(i["score"] for i in sym_items) / len(sym_items)) if sym_items else None,
        "unit_macro_agreement": (sum(sum(v) / len(v) for v in unit_scores.values()) / len(unit_scores)) if unit_scores else 0.0,
    }
    return {"primary": primary, "metrics": metrics, "items": items, "gate_failures": gate}


def _result_from_label(key, label):
    d = label.split(":", 1)[0] if label else "review"
    a = label.split(":", 1)[1] if d in LINKS else None
    return {"rakuten_sku_key": key, "decision": d, "au_sku_key": a, "required_extra_options": [],
            "unresolved_conditions": [], "evidence_refs": [], "reason": "oracle"}


def oracle(units, split):
    ref = load_reference(WS, split)
    ref.pop("__unresolved__", None)
    out = {}
    for u in units:
        res = []
        for k in expected_keys(u):
            e = ref.get(f"{u['id']}|{k}")
            if e is None or e.get("exclude"):
                continue
            res.append(_result_from_label(k, _acceptable(e)[0]))
        out[u["id"]] = {"product_pair_id": u["id"], "results": res}
    return out


def corrupt(output, rng):
    res = [dict(r) for r in output.get("results", [])]
    flip = {"matched": "unmatched", "conditional": "review", "unmatched": "review", "review": "unmatched"}
    for r in res:
        if rng.random() < 0.5:
            r["decision"] = flip.get(r["decision"], "review")
            r["au_sku_key"] = None
    return {"product_pair_id": output.get("product_pair_id"), "results": res}


def reference_coverage(units, split):
    ref = load_reference(WS, split)
    unresolved = ref.pop("__unresolved__", [])
    keys = [f"{u['id']}|{k}" for u in units for k in expected_keys(u)]
    covered = sum(1 for k in keys if k in ref)
    return {"covered_items": covered, "total_items": len(keys), "unresolved": len(unresolved)}


def _norm(s):
    import re
    import unicodedata
    s = unicodedata.normalize("NFKC", s).lower()
    return re.sub(r"[\s　・/／\-_()（）\[\]【】「」]+", "", s)


def trivial(units, split):
    """Rule baseline: unique exact normalized selector-value match -> matched, else unmatched."""
    out = {}
    for u in units:
        au = [(s["sku_key"], tuple(sorted(_norm(c["value"]) for c in s["conditions"]))) for s in u["input"]["au"]["skus"]]
        res = []
        for s in u["input"]["rakuten"]["skus"]:
            v = tuple(sorted(_norm(c["value"]) for c in s["conditions"]))
            hits = [k for k, a in au if a == v]
            lab = f"matched:{hits[0]}" if len(hits) == 1 else "unmatched"
            res.append(_result_from_label(s["sku_key"], lab))
        out[u["id"]] = {"product_pair_id": u["id"], "results": res}
    return out
