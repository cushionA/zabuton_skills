"""One line per failing item: python tools/fails.py WS RUN_DIR [unit_prefix ...] [--max N]"""
import json, sys
from pathlib import Path
ws=Path(sys.argv[1]); run=Path(sys.argv[2]); args=sys.argv[3:]
mx=40
if '--max' in args: mx=int(args[args.index('--max')+1]); args=args[:args.index('--max')]
ch=json.loads((ws/'charter.json').read_text()); sys.path.insert(0,str(ws/'eval')); sys.path.insert(0,str(Path(ch['skill_dir'])/'scripts'))
import dataset
meta=json.load(open(run/'meta.json'))
units={u['id']:u['input'] for u in dataset.load_units(meta['split'])}
outs={}
for l in open(run/'outputs.jsonl'):
    r=json.loads(l)
    if r['status']=='ok':
        for x in r['output']['results']: outs[f"{r['id']}|{x['rakuten_sku_key']}"]=x
n=0
for it in json.load(open(run/'score.json'))['items']:
    if it['score']==1: continue
    if args and not any(it['unit'].startswith(a) for a in args): continue
    rec=units[it['unit']]; rk=it['id'].split('|',1)[1]
    rs=next(s for s in rec['rakuten']['skus'] if s['sku_key']==rk)
    def au(lab):
        if isinstance(lab,str) and ':' in lab:
            k=lab.split(':',1)[1]; a=[s for s in rec['au']['skus'] if s['sku_key']==k]
            return lab.split(':')[0]+'->'+('/'.join(c['value'] for c in a[0]['conditions']) if a else '?')
        return str(lab)
    x=outs.get(it['id'],{})
    print(f"{it['unit'][-8:]} R{rec['rakuten']['skus'].index(rs)} [{'/'.join(c['value'] for c in rs['conditions'])[:40]}] pred={au(it['pred'])[:40]} ref={au(it['ref'])[:40]} | {x.get('reason','')[:150]}")
    n+=1
    if n>=mx: break
