## Failure lines (c002 best, two dev runs; one line per failing Rakuten row, deduplicated by unit+pattern)
4d1b762d R0 [お選びください/レッド] pred=review ref=matched->レッド | Colour レッド matches A1, and the model number 17250 is shared. The placeholder '-' axis is ignored. However, the costume character differs (princess vs 
0bf4ad86 R0 [無地大判ストール/07.カーキ] pred=conditional->07.カーキ/無地大判ストール ref=matched->07.カーキ/無地大判ストール | Colour 07.カーキ matches A6 on both pages; type and page facts match. The Rakuten title names the initial embroidery as included, and au
0bf4ad86 R1 [無地大判ストール/08.グレー] pred=conditional->08.グレー/無地大判ストール ref=matched->08.グレー/無地大判ストール | Colour 08.グレー matches A7; the embroidery non-SKU option must also be selected on au.
0bf4ad86 R2 [無地大判ストール/06.ワイン] pred=conditional->06.ワイン/無地大判ストール ref=matched->06.ワイン/無地大判ストール | Colour 06.ワイン matches A5; the embroidery non-SKU option must also be selected on au.
0bf4ad86 R3 [無地大判ストール/01.アイボリー] pred=conditional->01.アイボリー/無地大判ストール ref=matched->01.アイボリー/無地大判ストール | Colour 01.アイボリー matches A0; 代表カラー ホワイト is a coarse class and does not contradict. The embroid
0bf4ad86 R4 [無地大判ストール/09.ネイビー] pred=conditional->09.ネイビー/無地大判ストール ref=matched->09.ネイビー/無地大判ストール | Colour 09.ネイビー matches A8; the embroidery non-SKU option must also be selected on au.
0bf4ad86 R5 [無地大判ストール/10.ブラック] pred=conditional->10.ブラック/無地大判ストール ref=matched->10.ブラック/無地大判ストール | Colour 10.ブラック matches A9; the embroidery non-SKU option must also be selected on au.
0bf4ad86 R6 [無地大判ストール/04.パープル] pred=conditional->04.パープル/無地大判ストール ref=matched->04.パープル/無地大判ストール | Colour 04.パープル matches A3; the embroidery non-SKU option must also be selected on au.
0bf4ad86 R7 [無地大判ストール/05.レッド] pred=conditional->05.レッド/無地大判ストール ref=matched->05.レッド/無地大判ストール | Colour 05.レッド matches A4; the embroidery non-SKU option must also be selected on au.
0bf4ad86 R8 [無地大判ストール/02.ベージュ] pred=conditional->02.ベージュ/無地大判ストール ref=matched->02.ベージュ/無地大判ストール | Colour 02.ベージュ matches A1; the embroidery non-SKU option must also be selected on au.
0bf4ad86 R9 [無地大判ストール/03.ライトピンク] pred=conditional->03.ライトピンク/無地大判ストール ref=matched->03.ライトピンク/無地大判ストール | Colour 03.ライトピンク matches A2; 代表カラー ピンク is a coarse class and does not contradict. Th
a7df740d R0 [お選びください。（必須）/モイスチャー] pred=conditional->モイスチャー/お選びください。（必須） ref=matched->モイスチャー/お選びください。（必須） | R0 is モイスチャー and A1 is モイスチャー; both pages describe the same 6
a7df740d R1 [お選びください。（必須）/シルキー] pred=conditional->シルキー/お選びください。（必須） ref=matched->シルキー/お選びください。（必須） | R1 is シルキー and A0 is シルキー; both pages describe the same 600ml+600g two-piece set. The a
5eb70d0c R0 [当日出荷/ホワイト] pred=review ref=matched->ホワイト/当日出荷 | Same model MHS-2477 and identical specs. ad1 (商品番号 35279092) hints at the white variant, but au rows never state colour, and two au rows share the sam
5eb70d0c R1 [当日出荷/ブラック] pred=review ref=matched->ブラック/当日出荷 | The au page lists two colours, but its rows encode only shipping. The black configuration cannot be tied to any au row, and the page hint leans white.
d38bd9cd R0 [ONESIZE/クリスマス_C] pred=conditional->クリスマス_C/ONESIZE ref=matched->クリスマス_C/ONESIZE | 曲 クリスマス_C matches row to row, and both sides are ONESIZE with model 7987638. The au page has an optional free gift wrap that is observed unselected; t
d38bd9cd R1 [ONESIZE/誕生日_A] pred=conditional->誕生日_A/ONESIZE ref=matched->誕生日_A/ONESIZE | 曲 誕生日_A matches row to row, and both sides are ONESIZE with model 7987638. The au free gift wrap option is observed unselected and is not mentioned on
d38bd9cd R3 [ONESIZE/誕生日_B] pred=conditional->誕生日_B/ONESIZE ref=matched->誕生日_B/ONESIZE | 曲 誕生日_B matches row to row, and both sides are ONESIZE with model 7987638. The au free gift wrap option is observed unselected and is not mentioned on
c81c6d73 R0 [1枚/01.ホワイト/クルーネック/Lサイズ] pred=review ref=unmatched | Colour, neckline and size align with A13, but the au page contradicts itself on product type and quantity.
c81c6d73 R2 [1枚/02.ブラック/Vネック/Lサイズ] pred=review ref=unmatched | Row values match A14, but quantity and sleeve type are unresolved or contradictory on the au page.
17c84334 R0 [当日出荷] pred=conditional->当日出荷 ref=matched->当日出荷 | Shipping option 当日出荷 matches A0. Model 580DM0709 and au product number 09950080 agree with variant a09950080. Both pages describe the same single-item
17c84334 R1 [通常配送5日以内] pred=conditional->通常配送5日以内 ref=matched->通常配送5日以内 | Shipping option 通常配送5日以内 matches A1. Model 580DM0709 and au product number 09950080 agree with variant 09950080ZZ. The au free gift option is observed
1b56d3ad R2 [Aタイフ?_フ?ルーク?レイ] pred=review ref=unmatched | The garbled value is most likely 'Aタイプ_ブルーグレイ'. None of the au colours (pink, orange, navy, white, green) matches it, but the mojibake leaves the mean
0c3c3d0f R2 [ブラック/S] pred=review ref=matched->S/ブラック | Colour and size map to A2, but the au page contradicts itself on the S foot-size range, so the size identity is not settled.
0c3c3d0f R6 [ホワイト/S] pred=review ref=matched->S/ホワイト | Colour and size map to A3, but the au page contradicts itself on the S foot-size range, so the size identity is not settled.
be9600dc R0 [ミニーマウス・ユニコーン] pred=conditional->ミニーマウス・ユニコーン/お選びください ref=matched->ミニーマウス・ユニコーン/お選びください | Character value ミニーマウス・ユニコーン matches A2 at row level. The au page has a fr
be9600dc R1 [バットマン・ボディ] pred=conditional->バットマン・ボディ/お選びください ref=matched->バットマン・ボディ/お選びください | Character value バットマン・ボディ matches A4 at row level. The au free bundle option must be excluded, which cannot
be9600dc R2 [パウ・パトロール] pred=conditional->パウ・パトロール/お選びください ref=matched->パウ・パトロール/お選びください | Character value パウ・パトロール matches A7 at row level. The au free bundle option must be excluded, which cannot be verified
be9600dc R3 [スヌーピー] pred=conditional->スヌーピー/お選びください ref=matched->スヌーピー/お選びください | Character value スヌーピー matches A8 at row level. The au free bundle option must be excluded, which cannot be verified.
be9600dc R4 [アリエル] pred=conditional->アリエル/お選びください ref=matched->アリエル/お選びください | Character value アリエル matches A0 at row level. The au free bundle option must be excluded, which cannot be verified.
be9600dc R5 [ジュラシックワールド] pred=conditional->ジュラシックワールド/お選びください ref=matched->ジュラシックワールド/お選びください | Character value ジュラシックワールド matches A6 at row level. The au free bundle option must be excluded, 
d4214c18 R0 [02.Uネック/Lサイズ] pred=review ref=matched->Lサイズ/02.Uネック | Neckline and size map to A7 and color is black, but the 044 model hint conflicts with the au model 043.
d4214c18 R1 [02.Uネック/Mサイズ] pred=review ref=matched->Mサイズ/02.Uネック | Neckline and size map to A4, but the 044 model hint conflicts with the au model 043.
d4214c18 R3 [02.Uネック/XLサイズ] pred=review ref=matched->XLサイズ/02.Uネック | Neckline and size map to A10, but the 044 model hint conflicts with the au model 043.
d4214c18 R4 [03.タートルネック/Sサイズ] pred=review ref=matched->Sサイズ/03.タートルネック | Neckline and size map to A2, but the 045 model hint conflicts with the au model 043.
b0b285e6 R0 [ハイドロリペア トリートメント/ゴールデンモイストシャンプー] pred=review ref=unmatched | Mixed two-item set; au rows are single-item only.
17a4b100 R0 [3サイズセット/ゴールド] pred=conditional->ゴールド/3サイズセット ref=matched->ゴールド/3サイズセット | Gold colour and the 3-size set match A1. Model 7987299 appears in the au title. The 7号 hint is a set component (ad20) and is not contradicted. The fre
17a4b100 R1 [3サイズセット/ブラック] pred=conditional->ブラック/3サイズセット ref=matched->ブラック/3サイズセット | Black colour and the 3-size set match A0. Model 7987299 appears in the au title. The free gift-wrapping option is unselected on au and not part of the
17a4b100 R2 [3サイズセット/シルバー] pred=conditional->シルバー/3サイズセット ref=matched->シルバー/3サイズセット | Silver colour and the 3-size set match A2. Model 7987299 appears in the au title. The free gift-wrapping option is unselected on au and not part of th
1b56d3ad R0 [Aタイプ_オレンジ] pred=review ref=matched->オレンジ（C）/お選びください | Colour orange matches A1, but the Rakuten row carries an 'Aタイプ' type qualifier that the au page never states; Rakuten also has a Bタイプ variant, so the 
1b56d3ad R1 [Aタイプ_ホワイト] pred=review ref=matched->ホワイト（E）/お選びください | Colour white matches A3, but the Rakuten row carries an 'Aタイプ' type qualifier that the au page never states, so the type match is unresolved.

## Failing items per unit [run1, run2] with pred>ref patterns
b0b285e6 [0, 30] {'review>unmatched': 30}
c81c6d73 [24, 0] {'review>unmatched': 24}
0bf4ad86 [10, 10] {'conditional>matched': 20}
d4214c18 [8, 8] {'review>matched': 16}
5eb70d0c [4, 4] {'review>matched': 8}
d38bd9cd [4, 4] {'conditional>matched': 8}
be9600dc [8, 0] {'conditional>matched': 8}
a7df740d [2, 2] {'conditional>matched': 4}
17c84334 [2, 2] {'conditional>matched': 4}
1b56d3ad [1, 3] {'review>unmatched': 2, 'review>matched': 2}
17a4b100 [0, 3] {'conditional>matched': 3}
4d1b762d [1, 1] {'review>matched': 2}
0c3c3d0f [2, 0] {'review>matched': 2}

## Headroom probe: same prompt on Sonnet 5.5 = 0.854 agreement (Haiku c002 0.896). Sonnet failing units:
019a2015 [60] {'matched>review': 60}
c81c6d73 [24] {'matched>review': 24}
33caba50 [6] {'matched>conditional': 6}
5eb70d0c [4] {'review>matched': 4}
