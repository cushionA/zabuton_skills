"""Adjudicate reference disagreements with a third, independent Opus call per pair.

  python tools/adjudicate.py WS --split dev --runs RUN_A RUN_B [--quiet]

For every pair with disagreements (eval/reference/<split>.disagreements.jsonl) the adjudicator sees the
full pair rendering, the reference rules, and both answers (decision, au row, reason) for the disputed
Rakuten rows only. It returns a final label, or an acceptable set when the case is genuinely ambiguous,
or exclude for a data defect. Results are appended to eval/reference/<split>.adjudicated.jsonl
(source "adjudicated:opus-3rd"). --quiet prints counts only (use it for holdout).
"""
import argparse
import json
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

WS = None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("ws")
    ap.add_argument("--split", default="dev")
    ap.add_argument("--runs", nargs=2, required=True)
    ap.add_argument("--quiet", action="store_true")
    ap.add_argument("--model", default="opus")
    ap.add_argument("--effort", default="high")
    a = ap.parse_args()
    ws = Path(a.ws)
    ch = json.loads((ws / "charter.json").read_text(encoding="utf-8"))
    sys.path.insert(0, str(Path(ch["skill_dir"]) / "scripts"))
    sys.path.insert(0, str(ws / "eval"))
    sys.path.insert(0, str(ws / "candidates" / "ref-opus"))
    import llm_call  # noqa
    from common import append_jsonl, read_jsonl  # noqa
    import dataset  # noqa
    import pipeline as refp  # noqa

    units = {u["id"]: u for u in dataset.load_units(a.split)}
    base = ws / "eval" / "reference"
    dis = read_jsonl(base / f"{a.split}.disagreements.jsonl")
    done = {r["key"] for r in read_jsonl(base / f"{a.split}.adjudicated.jsonl")}
    dis = [d for d in dis if d["key"] not in done]
    outs = []
    for rd in a.runs:
        o = {}
        for row in read_jsonl(Path(rd) / "outputs.jsonl"):
            if row.get("status") == "ok":
                o[row["id"]] = {r["rakuten_sku_key"]: r for r in row["output"]["results"]}
        outs.append(o)
    by_pair = {}
    for d in dis:
        pid, rk = d["key"].split("|", 1)
        by_pair.setdefault(pid, []).append(rk)
    system = (ws / "candidates" / "ref-opus" / "prompts" / "system.txt").read_text(encoding="utf-8")
    system = system.split("Output exactly one JSON object")[0] + ADJ_OUTPUT

    def short(rec, label):
        if label is None:
            return "no answer"
        if ":" in label:
            d, k = label.split(":", 1)
            ak = [s["sku_key"] for s in rec["au"]["skus"]]
            return f"{d} {('A%d' % ak.index(k)) if k in ak else k}"
        return label

    def work(pid):
        rec = units[pid]["input"]
        rk = [s["sku_key"] for s in rec["rakuten"]["skus"]]
        lines = []
        for key in by_pair[pid]:
            i = rk.index(key)
            parts = []
            for name, o in zip("AB", outs):
                r = (o.get(pid) or {}).get(key)
                if r is None:
                    parts.append(f"answer {name}: none")
                else:
                    lab = r["decision"] + (f":{r['au_sku_key']}" if r["decision"] in ("matched", "conditional") else "")
                    parts.append(f"answer {name}: {short(rec, lab)}; options={json.dumps(r.get('required_extra_options'), ensure_ascii=False)[:200]}; "
                                 f"reason: {r.get('reason', '')[:400]}")
            lines.append(f"R{i}:\n  " + "\n  ".join(parts))
        user = ("<DATA>\n" + refp.render(rec) + "\n</DATA>\n\nDISPUTED ROWS (two independent reviewers disagreed):\n"
                + "\n".join(lines) + "\n\nRe-check each disputed row against the data and the rules; output the JSON only.")
        r = llm_call.call(user, system, backend="cli", model=a.model, effort=a.effort, expect_json=True,
                          timeout=1500, retries=2)
        return pid, r

    n_label = n_acc = n_excl = n_fail = 0
    with ThreadPoolExecutor(max_workers=6) as ex:
        for pid, r in ex.map(work, sorted(by_pair)):
            rec = units[pid]["input"]
            rk = [s["sku_key"] for s in rec["rakuten"]["skus"]]
            ak = [s["sku_key"] for s in rec["au"]["skus"]]
            js = r.get("json") if r.get("ok") else None
            got = {}
            for v in (js or {}).get("verdicts", []) if isinstance(js, dict) else []:
                if isinstance(v, dict) and str(v.get("r", "")).startswith("R"):
                    got[v["r"]] = v

            def full(lab):
                lab = str(lab).strip()
                if lab in ("unmatched", "review"):
                    return lab
                if ":" in lab:
                    d, x = lab.split(":", 1)
                    x = x.strip()
                    if d in ("matched", "conditional") and x.startswith("A") and x[1:].isdigit() and int(x[1:]) < len(ak):
                        return f"{d}:{ak[int(x[1:])]}"
                return None
            for key in by_pair[pid]:
                v = got.get(f"R{rk.index(key)}")
                entry = {"key": f"{pid}|{key}", "source": "adjudicated:opus-3rd"}
                if v is None:
                    n_fail += 1
                    continue
                if v.get("exclude"):
                    entry.update(exclude=True, note=str(v.get("note", ""))[:300])
                    n_excl += 1
                else:
                    acc = [full(x) for x in (v.get("acceptable") or [])]
                    acc = [x for x in acc if x]
                    lab = full(v.get("label", ""))
                    if len(set(acc)) >= 2:
                        entry.update(acceptable=sorted(set(acc)), note=str(v.get("note", ""))[:300])
                        n_acc += 1
                    elif lab:
                        entry.update(label=lab, note=str(v.get("note", ""))[:300])
                        n_label += 1
                    else:
                        n_fail += 1
                        continue
                append_jsonl(base / f"{a.split}.adjudicated.jsonl", entry)
                if not a.quiet:
                    print(f"{pid}|R{rk.index(key)}: {entry.get('label') or entry.get('acceptable') or 'EXCLUDE'} | {entry.get('note', '')[:140]}")
    print(f"adjudicated pairs={len(by_pair)} items: label={n_label} acceptable={n_acc} exclude={n_excl} unresolved={n_fail}")


ADJ_OUTPUT = """You are the adjudicator. Two independent reviewers answered some Rakuten rows differently. Decide each disputed row yourself from the data and the rules above; the reviewers' reasons are claims to verify, not evidence. Use an acceptable set only when the data genuinely supports two readings under the rules (e.g. matched vs conditional when it is unclear whether an au option exists); otherwise give one label. Use exclude only for a defect in the input data itself.

Output exactly one JSON object and nothing else:
{"verdicts": [{"r": "R3", "label": "matched:A2" | "conditional:A2" | "unmatched" | "review",
  "acceptable": ["matched:A2", "conditional:A2"] (only when genuinely ambiguous, else omit),
  "exclude": false, "note": "one short English sentence with the deciding evidence"}]}
One verdict per disputed row.
"""

if __name__ == "__main__":
    main()
