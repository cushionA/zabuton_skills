# Experiment plan - rakuten-au-sku-matching

## Decision this serves
Whether (and in which configuration) Haiku via an API-like call can resolve Rakuten -> au PAY Market SKU
correspondence per Rakuten SKU, with explicit no-match / review / conditional-on-extra-option outcomes, and at
what quality, automation share, time and AI usage.

## Problem taxonomy (from the audit, counts over 152 pairs / 1,934 Rakuten SKU slots)
- Easy: same axes and values after trivial normalization - 80 pairs fully covered by exact selector values
  (644 slots have a unique exact au row).
- One-sided axes fixed by the other page (quantity "2枚組" in au title; device model in au title/spec): part of
  the 36 unequal-axis pairs and of the 27 pairs where Rakuten has more rows than au.
- Combined values (colour+neckline in one au value), naming/unit variants (21.0 vs 21.0cm, サックスブルー vs サックス).
- Add-ons as au non-SKU paid options vs Rakuten SKU axis (16 pairs with paid options) -> conditional.
- Pair-level doubt (2 pairs found) -> all rows unmatched/review.
- Missing Rakuten description (34 pairs) -> evidence only from titles/axes/aux.
- Size: 20 largest pairs hold 840 slots; up to 60 rows per side -> long outputs.

## Approaches, ranked
1. One call per pair, all rows at once (baseline). Simple; risk: long outputs, row omissions, attention spread on 60-row pairs.
2. Decomposition: model maps axis VALUES (and fixed facts) per pair, code joins rows deterministically. Fewer output
   tokens, consistent per value; risk: cases where row-level exceptions matter (au row missing for a combo).
3. Deterministic pre-pass: exact-value rows proposed to the model as candidates / auto-decided; model only judges the
   rest. Cheaper; risk: exact value match is not proof (fixed specs, options).
4. Verification pass on review/uncertain rows (ensemble.verify) or Haiku effort up (model.effort).
5. Input selection: shorter descriptions (only lines mentioning axis values / numbers) to cut tokens.

## Baseline
c000-baseline: one Haiku call per pair, effort low, compact JSON of the pair with short ids, task rules from
TASK.txt condensed, no examples, JSON out. No-LLM rule baseline (exact normalized value match -> matched else
unmatched) reported via score.trivial.

## Metrics
- Primary: agreement with the adjudicated silver reference on the per-Rakuten-SKU label (decision + au row), all
  referenced slots of the split; failed/missing = wrong.
- Guards: wrong_link_rate (links to a row the reference rejects) may not rise > 0.01 over the best;
  missing_or_failed_rate <= 0.02.
- Diagnostics: overclaim_rate, link_type_rate, missed_link_rate, link precision/recall, auto_decided_rate
  (matched+unmatched; coverage, not accuracy), decision distribution, agreement asym vs sym, unit macro agreement.
- Efficiency: cost_uncached_list_usd (same split -> same units), plus api_ms per unit and wall time.

## Splits
dev = normal_50 (50 pairs, 642 slots); holdout = 41 pairs / 544 slots (random, proportional strata asym/sym x size,
group-aware by Rakuten URL, seed 0); rest = 61 pairs (full-scope run only); full = 152.
Noise: two baseline runs -> paired band; expected ~±2-4 pt on 642 correlated items.

## Reference
Silver: Opus 5.5 (claude -p), effort high, separate careful prompt and text rendering (ref-opus), two independent runs
per split; agreements kept, disagreements adjudicated by a third Opus call that sees both answers (tools/adjudicate.py)
with my spot-check on dev; holdout adjudication by the same tool with counts only. Named "agreement with Opus silver
reference", never accuracy. No human verification in this run (user unavailable) -> recommend a human check sheet.

## Budget and stop
No user limits. Stop at the improvement limit: quality plateau (patience 5, >=3 lever groups, fresh-eyes done),
then efficiency phase until plateau, then finalize (holdout <= 3 evaluations, 3 repeats pass^k, full 152 run).

## Risks
- Reference bias: Opus shares blind spots with Haiku; rules in both prompts come from the same TASK.txt.
- Leakage: none built from data (no dictionaries); prompt rules are generic. Rakuten pages shared by two pairs are
  grouped.
- Data not independent of past development (known).
- Policy ambiguity matched vs conditional for "without add-on" rows -> acceptable sets where genuinely ambiguous.
