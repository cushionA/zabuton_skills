"""Task-specific data checks for quality_gate.py (Rakuten -> au PAY market SKU matching).

Every number is computed here from inputs/products.jsonl and subsets.json (charter.data.inputs).
Unit = product pair (one JSONL line). Item = one Rakuten SKU row inside a pair.
"""
import json
import re
import statistics
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

BOILERPLATE_MAX_CHARS = 80
TITLE_JACCARD_DOUBT = 0.12


def _records(path):
    with open(path, encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def _norm(s):
    s = unicodedata.normalize("NFKC", s).lower()
    return re.sub(r"[\s　・/／\-_()（）\[\]【】「」]+", "", s)


def _bigrams(s):
    s = re.sub(r"\s+", "", unicodedata.normalize("NFKC", s).lower())
    return {s[i:i + 2] for i in range(len(s) - 1)}


def run_checks(ctx):
    out = []
    F = ctx.finding
    recs = _records(ctx.inputs[0])
    subsets = json.loads(Path(ctx.inputs[1]).read_text(encoding="utf-8"))
    n = len(recs)
    r_skus = sum(len(r["rakuten"]["skus"]) for r in recs)
    a_skus = sum(len(r["au"]["skus"]) for r in recs)
    cand = sum(len(r["rakuten"]["skus"]) * len(r["au"]["skus"]) for r in recs)
    mx = max(max(len(r["rakuten"]["skus"]), len(r["au"]["skus"])) for r in recs)
    out.append(F("size", "info", f"{n} pairs; {r_skus} Rakuten SKU rows; {a_skus} au rows; {cand} candidate row pairs; "
                 f"max {mx} rows on one side",
                 evidence="brief states 152 / 1,934 / 1,600 / 45,454 / 60x60",
                 affected=n))
    if (n, r_skus, a_skus, cand) != (152, 1934, 1600, 45454):
        out.append(F("size-mismatch", "high", "counts differ from the brief", evidence=str((n, r_skus, a_skus, cand))))

    # ---- schema / integrity
    req_side = {"rakuten": ["title", "url", "sku_axes", "skus", "description"],
                "au": ["product_id", "title", "url", "sku_axes", "skus", "description", "non_sku_options"]}
    missing = 0
    for r in recs:
        for side, keys in req_side.items():
            missing += sum(1 for k in keys if k not in r.get(side, {}))
    if missing:
        out.append(F("schema-missing", "critical", f"{missing} required fields missing"))
    ids = Counter(r["product_pair_id"] for r in recs)
    if any(c > 1 for c in ids.values()):
        out.append(F("dup-pair-ids", "critical", "duplicated product_pair_id"))
    bad_keys = bad_cond = bad_count = 0
    for r in recs:
        for side in ("rakuten", "au"):
            ks = [s["sku_key"] for s in r[side]["skus"]]
            bad_keys += len(ks) - len(set(ks))
            axes = {a["axis_index"]: a for a in r[side]["sku_axes"]}
            for s in r[side]["skus"]:
                if len(s["conditions"]) != len(axes):
                    bad_count += 1
                for c in s["conditions"]:
                    a = axes.get(c["axis_index"])
                    if a is None or c["value"] not in a["values"] or c["name"] != a["name"]:
                        bad_cond += 1
    sev = "critical" if (bad_keys or bad_cond) else "info"
    out.append(F("integrity", sev, f"sku_key duplicates within a pair={bad_keys}; conditions not resolving to an axis value="
                 f"{bad_cond}; rows whose condition count != axis count={bad_count}", affected=bad_keys + bad_cond))
    dupcond = 0
    for r in recs:
        for side in ("rakuten", "au"):
            c = Counter(tuple((x["axis_index"], x["value"]) for x in s["conditions"]) for s in r[side]["skus"])
            dupcond += sum(v - 1 for v in c.values() if v > 1)
    out.append(F("dup-condition-rows", "info" if not dupcond else "medium",
                 f"{dupcond} SKU rows share identical selector values with another row of the same side"))

    # ---- stated limitations (known)
    out.append(F("no-labels", "medium", "no reference labels or model predictions are included; annotation_template.csv is blank",
                 evidence="brief + README; schema has no label fields", affected=r_skus, known=True,
                 recommendation="build a silver reference (stronger model x2 + adjudication); report 'agreement', not accuracy"))
    prov = {}
    if ctx.aux:
        with open(ctx.aux[0], encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    r = json.loads(line)
                    prov[r["product_pair_id"]] = r
    unver = sum(1 for p in prov.values() if p.get("pair_identity_human_verified") is False)
    status = Counter(p.get("pair_identity_status") for p in prov.values())
    out.append(F("pair-identity-unverified", "medium",
                 f"product pairs are candidate correspondences: pair_identity_human_verified=false for {unver}/{len(prov)} "
                 f"(status {dict(status)})",
                 affected=unver, known=True, recommendation="record pair-level doubts separately; SKU outputs may be all unmatched/review"))
    osplit = Counter(p.get("original_split") for p in prov.values())
    out.append(F("not-independent", "medium", f"data was used in earlier development (original split {dict(osplit)})",
                 affected=n, known=True, recommendation="do not present results as an independent benchmark"))
    if len(prov) != n or set(prov) != set(ids):
        out.append(F("provenance-mismatch", "high", "provenance.jsonl does not cover exactly the input pair ids",
                     evidence=f"{len(prov)} provenance rows vs {n} pairs"))
    modes = {s: Counter(r[s]["description"]["mode"] for r in recs) for s in ("rakuten", "au")}
    out.append(F("desc-unavailable", "low", f"description unavailable: rakuten={modes['rakuten']['unavailable']} "
                 f"au={modes['au']['unavailable']}; modes {dict(modes['rakuten'])} / {dict(modes['au'])}",
                 affected=modes["rakuten"]["unavailable"] + modes["au"]["unavailable"], known=True))
    nso_null = sum(1 for r in recs if r["au"]["non_sku_options"]["complete_value_lists"] is None
                   and r["au"]["non_sku_options"]["current_selected_values"] is None)
    paid = sum(1 for r in recs if r["au"]["non_sku_options"]["has_paid_options"] is True)
    free = sum(1 for r in recs if r["au"]["non_sku_options"]["has_free_options"] is True)
    out.append(F("extra-options-unobserved", "medium",
                 f"au non-SKU option value lists / current selections are null (not captured) in {nso_null}/{n}; "
                 f"has_paid_options=true in {paid}, has_free_options=true in {free}",
                 affected=paid, known=True,
                 recommendation="option presence is not selection; such SKUs can at best be 'conditional'"))

    # ---- unstated findings
    boiler = []
    for r in recs:
        d = r["rakuten"]["description"]
        if d["mode"] != "unavailable" and len(d["text"]) < BOILERPLATE_MAX_CHARS:
            boiler.append(r["product_pair_id"])
    texts = Counter(next(r for r in recs if r["product_pair_id"] == p)["rakuten"]["description"]["text"][:40] for p in boiler)
    out.append(F("rakuten-desc-effectively-empty", "medium",
                 f"{len(boiler)} Rakuten descriptions are present but contain only boilerplate (< {BOILERPLATE_MAX_CHARS} chars), "
                 f"in addition to {modes['rakuten']['unavailable']} 'unavailable'; together "
                 f"{len(boiler) + modes['rakuten']['unavailable']}/{n} Rakuten sides have no product-spec text",
                 evidence=f"texts: {dict(texts)}; e.g. {boiler[:4]}", affected=len(boiler),
                 recommendation="report as a stratum; fixed-spec evidence on the Rakuten side then comes only from title/aux attributes"))

    by_url = defaultdict(list)
    for r in recs:
        by_url[r["rakuten"]["url"]].append(r)
    groups = {u: v for u, v in by_url.items() if len(v) > 1}
    dup_slots = sum(len(v[0]["rakuten"]["skus"]) * (len(v) - 1) for v in groups.values())
    uniq = len({(r["rakuten"]["url"], s["sku_key"]) for r in recs for s in r["rakuten"]["skus"]})
    out.append(F("rakuten-page-in-two-pairs", "medium",
                 f"{len(groups)} Rakuten pages appear in 2 pairs each ({sum(len(v) for v in groups.values())} pairs); "
                 f"{dup_slots} Rakuten SKU rows are counted twice: {r_skus} SKU slots = {uniq} unique Rakuten SKUs",
                 evidence="; ".join(f"{u.split('/')[-2]}: {[x['product_pair_id'] for x in v]}" for u, v in groups.items()),
                 affected=dup_slots,
                 recommendation="keep both pairs (different au candidates) but split group-aware by Rakuten URL and report "
                                "both slot and unique counts"))
    cross = [u for u, v in groups.items() if len({prov.get(x["product_pair_id"], {}).get("original_split") for x in v}) > 1]
    out.append(F("dup-pages-vs-original-split", "info" if not cross else "medium",
                 f"{len(cross)} of the duplicated Rakuten pages straddle the original TRAINdict/EVALtest split"))
    same_au = []
    for v in groups.values():
        sig = {(json.dumps([[c["value"] for c in s["conditions"]] for s in x["au"]["skus"]], ensure_ascii=False),
                x["au"]["description"]["text_sha256"], x["au"]["title"]) for x in v}
        if len(sig) == 1:
            same_au.append([x["product_pair_id"] for x in v] + [x["au"]["product_id"] for x in v])
    out.append(F("duplicate-au-listings", "medium" if same_au else "info",
                 f"{len(same_au)} Rakuten pages are paired with two different au item ids whose title, SKU rows and "
                 f"description are identical (likely duplicate au listings -> near-duplicate units)",
                 evidence=str(same_au), affected=2 * len(same_au)))

    low = []
    for r in recs:
        a, b = _bigrams(r["rakuten"]["title"]), _bigrams(r["au"]["title"])
        j = len(a & b) / max(1, len(a | b))
        if j < TITLE_JACCARD_DOUBT:
            low.append((round(j, 3), r["product_pair_id"]))
    out.append(F("pair-doubt-low-title-overlap", "info",
                 f"{len(low)} pairs have title bigram Jaccard < {TITLE_JACCARD_DOUBT} (screen only; close-read in data_audit.md)",
                 evidence=str(sorted(low)), affected=len(low)))

    # ---- difficulty drivers
    unequal = sum(1 for r in recs if len(r["rakuten"]["sku_axes"]) != len(r["au"]["sku_axes"]))
    r_more = sum(1 for r in recs if len(r["rakuten"]["skus"]) > len(r["au"]["skus"]))
    r_less = sum(1 for r in recs if len(r["rakuten"]["skus"]) < len(r["au"]["skus"]))
    out.append(F("asymmetry", "info", f"unequal axis count {unequal} pairs; Rakuten has more rows in {r_more}, fewer in {r_less}",
                 affected=unequal))
    sizes = [len(r["rakuten"]["skus"]) for r in recs]
    chars = [len(json.dumps(r, ensure_ascii=False)) for r in recs]
    out.append(F("unit-size", "info", f"Rakuten SKUs per pair median {statistics.median(sizes)} max {max(sizes)}; "
                 f"JSON chars per pair median {statistics.median(chars):.0f} max {max(chars)} (fits one Haiku context)"))

    # ---- trivial solution
    uniq_hit = none_hit = multi_hit = 0
    full_pairs = zero_pairs = 0
    for r in recs:
        au = [tuple(sorted(_norm(c["value"]) for c in s["conditions"])) for s in r["au"]["skus"]]
        hits_here = 0
        for s in r["rakuten"]["skus"]:
            v = tuple(sorted(_norm(c["value"]) for c in s["conditions"]))
            k = au.count(v)
            if k == 1:
                uniq_hit += 1
                hits_here += 1
            elif k == 0:
                none_hit += 1
            else:
                multi_hit += 1
        full_pairs += hits_here == len(r["rakuten"]["skus"])
        zero_pairs += hits_here == 0
    out.append(F("trivial-rule", "info",
                 f"normalized exact selector-value match gives a unique au row for {uniq_hit}/{r_skus} Rakuten SKUs "
                 f"({uniq_hit / r_skus:.1%}); no exact row for {none_hit}; ambiguous {multi_hit}. Pairs fully covered {full_pairs}, "
                 f"pairs with zero exact rows {zero_pairs}",
                 recommendation="a rule cannot decide 2/3 of SKUs (and an exact value match is not proof of a full match: "
                                "fixed specs, extra options, pair doubts) -> an LLM step is worth optimizing"))

    # ---- injection-like text
    pat = re.compile(r"(ignore (all|previous)|disregard|system prompt|you are an? |指示を無視|以前の指示|プロンプト)", re.I)
    inj = []
    for r in recs:
        for side in ("rakuten", "au"):
            t = r[side]["title"] + "\n" + r[side]["description"]["text"]
            if pat.search(t):
                inj.append((r["product_pair_id"], side))
    out.append(F("injection-like-text", "info", f"{len(inj)} titles/descriptions contain instruction-like text",
                 evidence=str(inj[:5])))

    # ---- subsets
    allids = set(ids)
    bad = {k: len(set(v) - allids) for k, v in subsets.items() if set(v) - allids}
    if bad:
        out.append(F("subset-unknown-ids", "high", f"subsets reference unknown ids {bad}"))
    out.append(F("subsets", "info", f"subset sizes { {k: len(v) for k, v in subsets.items()} }; smoke_10 within normal_50: "
                 f"{set(subsets['smoke_10']) <= set(subsets['normal_50'])}; largest_20 & normal_50 = "
                 f"{len(set(subsets['largest_20']) & set(subsets['normal_50']))}"))
    out.append(F("scope-au-only-stress", "info",
                 "au_only_stress/ (58 au-only products, 2,937 SKUs) is excluded from every run and denominator, per the user; "
                 "packets/*.json duplicate inputs/products.jsonl and are not read",
                 known=True))
    return out
