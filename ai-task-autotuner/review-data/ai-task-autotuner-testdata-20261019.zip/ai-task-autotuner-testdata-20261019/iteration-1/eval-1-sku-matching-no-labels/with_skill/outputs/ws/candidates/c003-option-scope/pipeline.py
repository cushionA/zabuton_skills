"""c003-option-scope (<- c002): c002 with the add-on rule narrowed: conditional only when the Rakuten row involves the
add-on or the au text says the variant needs an option; unrelated au options (gift wrap, shipping...) are ignored.

Input: the pair record as compact JSON (hash/native-index fields dropped, description.text dropped because
description.lines carry the same text with ids) with short ids R*/A* for SKU rows and rd*/ad* for
description lines. Output: one JSON object with one result per Rakuten row; the pipeline maps the short ids
back to the original sku_keys/evidence ids. Hygiene only: invalid ids are counted and turned into review.
"""
import json


def compact(rec):
    out = {"product_pair_id": rec["product_pair_id"]}
    for side, pre, dpre in (("rakuten", "R", "rd"), ("au", "A", "ad")):
        s = rec[side]
        o = {"title": s["title"],
             "sku_axes": [{"name": a["name"], "values": a["values"]} for a in s["sku_axes"]],
             "skus": []}
        for i, row in enumerate(s["skus"]):
            r = {"id": f"{pre}{i}", "conditions": {c["name"]: c["value"] for c in row["conditions"]}}
            if side == "rakuten":
                r["variant_id"] = row.get("variant_id")
                r["auxiliary_attributes"] = {a["name"]: a["value"] for a in row.get("auxiliary_attributes", [])
                                             if a.get("value") not in (None, "", "-")}
            o["skus"].append(r)
        d = s["description"]
        o["description"] = {"mode": d["mode"],
                            "lines": [{"id": f"{dpre}{j}", "text": ln["text"]} for j, ln in enumerate(d["lines"], 1)],
                            "links": d.get("links", [])}
        if side == "au":
            o["non_sku_options"] = s["non_sku_options"]
        out[side] = o
    return out


def _ev(rec, ref):
    """Map short evidence ids back to dataset references."""
    try:
        if ref.startswith("rd") and ref[2:].isdigit():
            return rec["rakuten"]["description"]["lines"][int(ref[2:]) - 1]["evidence_id"]
        if ref.startswith("ad") and ref[2:].isdigit():
            return rec["au"]["description"]["lines"][int(ref[2:]) - 1]["evidence_id"]
        if ref[:1] in "RA" and ":" in ref:
            rid, cond = ref.split(":", 1)
            side = "rakuten" if rid[0] == "R" else "au"
            key = rec[side]["skus"][int(rid[1:])]["sku_key"]
            return f"{side}/{key}/{cond}"
        if ref[:1] in "RA" and ref[1:].isdigit():
            side = "rakuten" if ref[0] == "R" else "au"
            return f"{side}/{rec[side]['skus'][int(ref[1:])]['sku_key']}"
    except (IndexError, ValueError, KeyError):
        pass
    return ref


def to_output(rec, js, ctx=None):
    """Model JSON (short ids) -> dataset output. Raises on missing/invalid structure."""
    if not isinstance(js, dict) or not isinstance(js.get("results"), list):
        raise ValueError("no results list")
    rk = [s["sku_key"] for s in rec["rakuten"]["skus"]]
    ak = [s["sku_key"] for s in rec["au"]["skus"]]
    by_r = {}
    for it in js["results"]:
        if not isinstance(it, dict):
            continue
        r = str(it.get("r", ""))
        if not (r.startswith("R") and r[1:].isdigit() and int(r[1:]) < len(rk)) or r in by_r:
            if ctx:
                ctx.count("dropped_bad_or_dup_r")
            continue
        by_r[r] = it
    missing = [f"R{i}" for i in range(len(rk)) if f"R{i}" not in by_r]
    if missing:
        raise ValueError(f"missing {len(missing)} rows: {missing[:5]}")
    results = []
    for i, key in enumerate(rk):
        it = by_r[f"R{i}"]
        d = it.get("d")
        a = it.get("a")
        au_key = None
        if isinstance(a, str) and a.startswith("A") and a[1:].isdigit() and int(a[1:]) < len(ak):
            au_key = ak[int(a[1:])]
        elif a not in (None, "", "null") and ctx:
            ctx.count("bad_au_id")
        if d not in ("matched", "conditional", "unmatched", "review"):
            d = "review"
            if ctx:
                ctx.count("bad_decision")
        if d in ("matched", "conditional") and au_key is None:
            d = "review"
            if ctx:
                ctx.count("link_without_au")
        if d == "unmatched":
            au_key = None
        xs = []
        for x in it.get("x") or []:
            if isinstance(x, dict):
                xs.append({"feature": str(x.get("feature", "")), "required_state": str(x.get("state", "")),
                           "selection_label": x.get("label"), "current_selection_verified": False,
                           "evidence_refs": [_ev(rec, str(e)) for e in (x.get("e") or [])]})
        results.append({"rakuten_sku_key": key, "decision": d, "au_sku_key": au_key,
                        "required_extra_options": xs,
                        "unresolved_conditions": [str(u) for u in (it.get("u") or [])],
                        "evidence_refs": [_ev(rec, str(e)) for e in (it.get("e") or [])],
                        "reason": str(it.get("why", ""))})
    return {"product_pair_id": rec["product_pair_id"], "pair_assessment": js.get("pair"), "results": results}


def run(unit, ctx):
    rec = unit["input"]
    system = ctx.prompt("system.txt")
    user = ctx.prompt("user.txt").replace("{{UNIT_JSON}}", json.dumps(compact(rec), ensure_ascii=False))
    r = ctx.llm(user, system, tag="main", expect_json=True)
    if not r["ok"]:
        raise RuntimeError(f"{r['error_kind']}: {r['error']}")
    if r["json"] is None:
        raise ValueError("unparseable model output")
    return to_output(rec, r["json"], ctx)
