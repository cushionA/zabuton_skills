# ai-task-autotuner レビュー用パッケージ（2026-10-19）

## これは何か
- **ai-task-autotuner** は Claude Code 用のスキルです。テストデータを渡すと、AI（API 呼び出し）を使うタスクを設計し、実測に基づいて自律的に改善します。
- 改善は、品質（精度）を上げた後に効率（費用・時間）へ進みます。
- 最後に、タスク設計と本番設定（max_tokens、timeout など）を出力します。
- 前処理などのコード処理も積極的に組み合わせます。コードだけで済むと分かった場合は、別に報告します。
- 参考にした考え方は次の2つです。
  - Autoresearch: 実行できる採点コマンドで、変更を採用するか破棄するかを決める
  - Skill Evolver

## 中身
| パス | 内容 |
|---|---|
| `TASK_STRUCTURES.md` | **スキルが作ったタスク構造2件の概要**（まずここから） |
| `skill/ai-task-autotuner/` | スキル本体（リポジトリ `cushionA/zabuton_skills` のブランチ `claude/keen-edison-8il7ag`、コミット `f9a0c2f` と同じ） |
| `task_structures/01_sku-matching/` | 試験①: 楽天→au SKU突合の成果物 |
| `task_structures/02_au-rakuten-product-identification/` | 試験②: au→楽天 同一商品特定の成果物 |

### 各試験フォルダの中身
| ファイル | 内容 |
|---|---|
| `task_design.md` | タスク設計（入出力、パイプライン、規則、本番設定、運用） |
| `pipeline/` | 最終構成のコード（`pipeline.py`）とプロンプト（`prompts/`） |
| `production_config.json` | 推奨設定と、その根拠になった実測値 |
| `report.md` | 実測レポート（データ監査、評価方法、実験の経緯、限界） |
| `non_ai_findings.md` | AI を使わない処理で分かったこと |
| `eval/` または `eval_kit/` | 採点スクリプト、評価仕様、データ分割 |
| `final_message.md` | スキルがユーザーに出した最終報告 |
| `skill_feedback.md` | 試験を回したエージェントによる、スキルへの指摘 |
| `process/data_audit.md` | 最初のデータ監査の結果（PASS / REVIEW / STOP の判定） |
| `process/experiment_history.md` | 全実験の一覧（仮説、結果、採否、理由） |
| `process/journal.md` | 実験ごとの記録（英語） |
| `process/candidates/` | 試したすべての構成のコードとプロンプト（差分を見られます） |

### 入っていないもの
- 商品データ、実行結果（行ごとの判定）、参照データ、AI 呼び出しの全記録は入れていません。
- これらが必要な場合は、別途お渡しする試験データの zip（`ai-task-autotuner-testdata-20261019.zip`）にあります。

## スキルの読み方
1. `skill/ai-task-autotuner/SKILL.md`: 全体の流れ（英語、約190行）。
   - 監査 → 設計 → 評価の構築 → 改善ループ → 最終評価
2. `skill/ai-task-autotuner/references/`: 段階ごとの詳しい手順。
   - `audit.md`: データ監査
   - `evaluation.md`: 評価
   - `loop.md`: 改善ループ
   - `task-design.md`: タスク設計
   - `backends.md`: API の代わりの呼び出し方
   - `report.md`: 報告
3. `skill/ai-task-autotuner/scripts/`: 標準ライブラリだけの Python スクリプト。
4. `skill/ai-task-autotuner/HANDOFF.md`: 日本語の引き継ぎメモ。依頼内容との対応、試験結果、既知の問題が書いてあります。

## レビューで特に見てほしい点
- **判定の仕組み:** スクリプトが判定を強制し、エージェントの自己申告に頼っていないか。
  - データ監査の判定: 終了コードで判定
  - 採用・破棄の判定: `ledger.py decide`
  - 最終評価用データの使用回数の制限
- **揺れの扱い:** 揺れの見積もり（商品ペアなどのまとまり単位）と、採用の閾値の決め方が妥当か。
- **行き詰まり対策:** 同じ方向の試行の繰り返しを防ぐ仕組み（手法グループの分散、類似仮説の拒否、FRESH_EYES）が実際に効いていたか。
  - `process/experiment_history.md` で確認できます。
- **汎用性:** 2つの試験タスクに特化しすぎていないか。
- **数値の呼び方:** 成果物で「一致率」と「正解率」を混同していないか。

## テストの実行
```
cd skill
python -B -m unittest discover -s ai-task-autotuner/tests   # 17件、偽モデルで動くので API 呼び出しなし
```
