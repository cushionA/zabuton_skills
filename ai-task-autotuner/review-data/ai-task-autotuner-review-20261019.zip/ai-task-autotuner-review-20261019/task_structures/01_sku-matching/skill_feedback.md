# Feedback on ai-task-autotuner (run: Rakuten->au SKU matching, no labels, haiku via claude -p)

The run spanned three skill versions: initial (b3226b9), update 1 (c593bab: close_read, aux, quota, deliverables), and
update 2 (3410829/f6b4588: void, renoise, --gap, per-unit efficiency metric). The workspace is at
OUT/ws; my helper scripts are in ws/tools/.

## What helped
- **Gates enforced by scripts.** The quality gate, the "candidate changed after a measured run" refusal and the
  holdout cap all fired or applied exactly when they should. They kept the measurement honest across three
  interruptions.
- **Ledger RECOMMEND / FRESH_EYES.** The forced headroom probe was the most informative experiment of the run: the
  same prompt on Sonnet scored 0.854 vs Haiku 0.896. That showed the residual errors were policy/reference
  ambiguity, not model capacity, and stopped me from chasing model upgrades.
- **Smaller tools.** The novelty check with `--force-similar` reasons recorded, `ledger.py history`, and the quota
  circuit breaker (update 1) were all useful.
- **export_deliverables.** It derives production settings from measurements (max_tokens, timeout, cost per
  1,000 units) with their basis. That saved real work.
- **Reference protocol + validate_eval.** Null/oracle/corrupt/rescore caught nothing wrong, but they made the eval
  versions (v2, v3) cheap to re-validate.

## Problems, with concrete examples

### 1. Noise model assumes independent items (most important)
- validate_eval's paired band treats items as independent. Here items are clustered by product pair: 4 dev pairs
  (168 of 642 items) flip as whole pairs between identical runs.
- Observed vs reported:

  | What | Reported band | Actual difference between identical runs |
  |---|---|---|
  | Baseline, two runs | 0.032 | 0.889 vs 0.805 = 0.084 |
  | `--renoise` on the incumbent | 0.026 (69 flips) | flips cancelled in that pair of runs (0.913 vs 0.911) |
  | E011, identical config, three runs | ― | 0.760 / 0.952 / 0.921 |

- I set `loop.min_delta = 0.04` by hand, ran every candidate twice, and E011 three times. Keep/discard in the
  efficiency phase still depended on whether one 60-row pair flipped.
- Suggestions:
  - Compute the band with a unit-clustered bootstrap (resample units, not items). I wrote tools/cluster_ci.py.
  - Report the share of items carried by the top-k units.
  - Warn when a few units dominate.
  - The ledger could use clustered paired tests.

### 2. Ledger keeps decision-time numbers after eval changes
- After eval v2/v3 rescoring, `status` still showed `BEST E003 primary=0.8871` (v1 value; v3 value is 0.912).
- `DRIFT since phase switch: 0.8871 -> 0.8746` was misleading; the real drop was 0.912 -> 0.875, about min_delta.
- `ledger.py phase ... efficiency` would have set the floor from the stale 0.887. I passed `--floor 0.872` by hand.
- Suggestion: recompute best/floor/drift from rescored runs, or refuse while decide rows are stale.

### 3. Efficiency-metric switch broke old runs
- Switching the charter to `cost_uncached_list_usd_per_unit` at the phase switch (as instructed) left every earlier
  run without that summary field. `_pool` would get None for the incumbent.
- I backfilled 24 summary.json files by hand (cost_uncached_list_usd / units, marked `_backfilled`).
- Suggestion: `--rescore` should also recompute summary fields, or the ledger should derive per-unit values.

### 4. Reference protocol: "two independent runs" are not independent
- Opus effort high, same prompt, twice: holdout disagreement 0/544, dev 57/642 (all in 2 pairs).
- Those two runs mostly measure Opus self-consistency.
- The decorrelating variant (different prompt + representation) was voided by the quota outage.
- Suggestions:
  - Make two prompt/representation variants the default, not optional.
  - State plainly that agreement between them is not verification.

### 5. Adjudicator outputs need checking
- My third-Opus adjudicator (no subagent tool in this environment, so I wrote tools/adjudicate.py on top of
  llm_call) returned acceptable sets {matched, conditional} for 27 fox-fur rows. Its own notes said conditional.
- The same au pattern elsewhere in dev (train dress) had been labelled matched by both Opus runs. I found that
  inconsistency only later, through candidate failures, which forced eval v2.
- Suggestion: after adjudication, run a pattern-consistency pass, i.e. group items by the reason/pattern and check
  that equal patterns get equal labels.

### 6. No subagent tool in this environment
- The skill relies on subagents for: holdout adjudication ("look only at counts"), failure clustering, and
  fresh-eyes proposals. I had none.
- Workarounds:
  - Adjudication and fresh-eyes through `llm_call` (Opus via claude -p). That is a model, not an agent; it costs
    quota.
  - Failure reading through my own one-line-per-item scripts (tools/fails.py, unitfails.py).
- Update 1 added "print compact one-line views" for bulk reading. Suggestions:
  - Ship an adjudicate script.
  - Ship holdout-safe aggregate views: confusion matrix, per-unit failure histogram without ids
    (my tools/confusion.py).

### 7. Holdout guidance gaps
- The phase-switch holdout check of c002 gave 0.678 vs dev 0.91, with one 32-row pair failing on a missing output
  row.
- Holdout must not be read, so the only things I could look at were aggregates (sym 0.54 vs asym 0.92; review
  confusion). The skill does not say which aggregate diagnostics are allowed.
- With whole-pair noise, one holdout run per candidate is weak evidence. Final: c000 0.818, c012 0.925, cluster CI
  of the difference +0.02..+0.24.
- Suggestions:
  - Default to clustered CIs for holdout.
  - Allow more than 1 run per holdout evaluation, counted as one "peek".
- Close-read before splitting: I close-read 17 units during the audit, before splits existed. One of them (a
  clearly mismatched pair) then landed in holdout. Suggestion: make splits before the close read, and read
  dev/rest only, or force close-read units into dev.

### 8. close_read 'defect' default severity vs. briefs that prescribe handling
- Update 1 says a general acceptance does not cover specific defects, and `defect` lines default to high (REVIEW).
- The brief explicitly said "ペア自体に疑義があれば別に記録してください" (record pair doubts separately), i.e. it
  prescribed the handling for exactly this class.
- I set `severity: medium` on the one defect line, with the justification inline.
- Please say whether a brief-prescribed handling counts as the user's decision. As written, an agent could
  reasonably stop for a REVIEW that the user already answered.

### 9. make_splits stratification was not proportional (fixed in update 2)
- Round-robin over strata gave equal draws per stratum: holdout 17/40 asymmetric vs 36/152 in the data. I wrote a
  proportional sampler in dataset.py.

### 10. Quota (fixed in update 1, but the cost was real)
- Before update 1, the reference job ran without any pricing step, at concurrency 8 per run, two runs at a time:
  2x(50+41) Opus calls at effort high, plus another job on the same subscription. Quota was exhausted at ~10:52.
- The runner then classified quota errors as `api`, so it retried 84-168 times per run, and produced runs that
  were 80% harness errors.
- Later the session itself was cut off (16:25-23:43).
- The ledger had no `void` until update 2:
  - I moved broken runs to `runs_void/` by hand.
  - I wrote clock pause/resume lines into ledger.jsonl by hand, because `clock` has no `--at` for a known past
    start time. `--gap` covers only the "session silently died" case.

### 11. Smaller issues
- **profile_data.py:** `--out WS/audit/profile` is a file prefix, not a directory. I first looked for a directory.
- **score.py template:** label-only. Matching tasks need decision + row id, acceptable sets, and false-link vs
  over-claim vs link-type tags. A matching-task scorer template would save an hour. Mine is
  ws/eval/score.py.
- **No probe purpose:** I ran the Sonnet headroom probe with `--purpose smoke --tag headroom` so it would not count
  as a candidate. A `probe` purpose would make that explicit.
- **export_deliverables:**
  - It copies `pipeline/`, but re-measuring requires `candidates/<name>/`; the MANIFEST does not say so.
  - It does not export the actual task outputs of the full run, which is what the user needs. I added
    `deliverables/results/full_152_results.{csv,jsonl}` by hand.
- **Write tool:** it refused report.md ("subagents should return findings as text"). Update 2's "write it with the
  shell" note was needed and worked.
- **Workspace migration:** mid-run updates changed the template (charter `data.aux`, `thinking`, concurrency 6,
  efficiency metric). There is no migrate step, so I patched charter/config by hand. A `migrate_workspace.py`, or
  a status line listing missing fields, would help.

## About the mid-run updates
- **Coordinator messages:** both were precise and actionable. Re-reading SKILL.md and loop.md was enough to adapt.
  The diffs were small and well targeted.
- **Update 1 (close_read.jsonl, data.aux):** re-running the gate under it was quick. It made me record the
  close-read properly; worthwhile.
- **Update 2:** `--gap`, `void`, `renoise` and per-run costs all arrived after I had already built workarounds.
  `--renoise` without clustering can lower min_delta when the real noise is whole-unit flips (see 1).
