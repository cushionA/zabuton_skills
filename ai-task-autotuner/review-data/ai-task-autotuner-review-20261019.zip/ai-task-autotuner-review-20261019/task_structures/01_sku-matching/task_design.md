# 楽天→au PAYマーケット SKU突合 ― タスク設計（最終構成 c012-lean-compact）

## 目的と範囲
- 入力は、楽天と au の候補商品ペア1件です（inputs/products.jsonl の1行）。
- その商品の**全楽天SKU行それぞれ**について、次の4区分のどれかを返します。
  - matched: 対応する au の在庫行がある
  - conditional: au 行は対応するが、追加オプションの選択が必要
  - unmatched: どの au 行とも明示的に矛盾する
  - review: 根拠不足、曖昧さ、ページ内の矛盾、ペア自体への疑義がある
- 根拠、未解決条件、必要な追加オプション（いずれも未確認のまま）を一緒に残します。
- 範囲外のもの:
  - 商品ペアそのものの同一性の確定（疑義は `pair_assessment` に記録するだけです）
  - Web の現在状態の確認
  - au のオプション選択状態の取得（データ上 null です）
  - au_only_stress
- 1対1の割当は強制しません。複数の楽天行が同じ au 行を指してもかまいません。
- 選択肢の直積から架空の SKU を作ることはしません。

## パイプライン
1. **コード: 完全一致ペアの判定**（pipeline.py `exact_pair`）
   - 条件は次の3つです。
     - 両側の軸数が同じ
     - au に有料オプションがない（`has_paid_options` が true でない）
     - 楽天の全行について、正規化した選択肢値の組が一致する au 行がちょうど1行ある
   - 正規化は NFKC、小文字化、空白と区切り記号の除去です。
   - 条件を満たせば全行を matched とし、根拠として両行の選択肢条件を記録して終了します。AI は呼びません。
   - 実績: 152ペア中78ペア、1,934枠中561枠。
2. **コード: 入力の整形**（`render`）
   - 楽天と au の各ページを、次の形式のテキストにします。
     - 題名
     - 軸
     - SKU行を1行ずつ（`R0 | 軸=値 | …`、楽天は variant_id と補助属性付き）
     - 全行で同じ補助属性は「common aux」として1回だけ記載
     - 説明行（`rd1:` / `ad1:`）とリンク
     - au の non_sku_options フラグ
   - 情報は落としません。ID は短縮形（R*/A*/rd*/ad*）です。
3. **AI: Haiku 5.5 を1回呼び出す**（effort low）
   - システムプロンプトは `prompts/system.txt`（英語、約580語）、ユーザープロンプトは `prompts/user.txt` です。
   - データは `<DATA>` で囲み、中身は信頼しない前提を明記しています。
   - 出力は JSON 1個です。
     - matched 行は `{r,d,a}` だけを返します。
     - その他の行は x（追加オプション）、u（未解決条件）、e（根拠ID）、why（短い理由）も返します。
4. **コード: 検証と復元**（`to_output`）
   - 短縮 ID を元の sku_key / evidence_id に戻します。
   - 存在しない ID や、au 行のない matched/conditional は review に落とします。
   - matched 行の根拠は、両行の選択肢条件をコードが補います。
   - 欠落行がある、または解析できない場合は1回だけ再試行します。それでも駄目なら、その商品は失敗として扱います（全行を誤り扱い）。
5. **出力**: `schemas/suggested-response.schema.json` に準拠した形式に `pair_assessment` を加えたものです。
   - 中身は `{product_pair_id, pair_assessment, results:[{rakuten_sku_key, decision, au_sku_key, required_extra_options[{feature, required_state, selection_label, current_selection_verified:false, evidence_refs}], unresolved_conditions, evidence_refs, reason}]}` です。

## AI 呼び出し
| 項目 | 値 |
|---|---|
| モデル | claude-haiku-5-5（`haiku`。claude -p で実測、served も同じ） |
| effort / thinking | low / off 指定（claude -p では thinking を完全には止められません。実測で1呼び出し当たり p50 1,026 thinking トークン） |
| 呼び出し回数 | 完全一致でないペアだけ1回（全体平均 0.49回/ペア） |
| 主な判定規則（system.txt） | 片側だけの条件は相手ページの固定事実で説明する / 単一値軸やプレースホルダー（「-」「お選びください」）は条件ではない / 書式違いは同じ値（21.0=21.0cm）/ 数量・セット内容・機種は厳密に比較 / シリーズの列挙や他商品の案内は根拠にしない / 金額は根拠にしない / 追加オプションの扱い / ページ内の矛盾は review |

## 規則と辞書
- 辞書、学習、派生語彙は使っていません。source_records の色語彙やサイズ対応表も使っていません（配布入力だけの条件）。
- コードの規則は「完全一致ペア」の判定と正規化だけです（約40行）。
- プロンプトの規則は system.txt の1ファイルです。
- 規則はデータの特定の商品から作っていません。課題文（brief と TASK.txt）の定義を英語で書き直したものです。

## 出力区分の意味
| 区分 | 意味 | 自動確定に数えるか |
|---|---|---|
| matched | 1つの au 行が楽天行のすべての条件を満たす。矛盾も未解決条件もなく、追加オプションも不要で、同等の別候補もない | 数える |
| unmatched | どの au 行とも明示的に矛盾する（選択肢値、または au ページの固定事実） | 数える |
| conditional | 行としては対応するが、au の追加オプション（含む／含まない）の選択が必要。選択状態は未確認（`current_selection_verified=false`） | 数えない（人がオプションを確認） |
| review | 根拠不足、複数候補、ページ内の矛盾、ペアへの疑義など | 数えない（人が判断） |
| 失敗 | 再試行しても完全な出力が得られなかった | 数えない（全152ペアの full run では0件） |

## 本番設定（`production_config.json`、実測から算出）
| 設定 | 推奨値 | 根拠 |
|---|---|---|
| max_tokens | 23,040 | 出力（thinking を含む）p50 1,801、p99 11,433、最大 13,042。打ち切りは0件 |
| timeout | 110 秒 | api_ms p99 35.7 秒、最大 41.9 秒。claude -p の起動時間込み |
| 同時実行 | 6 | 実測した最高値。スロットリングとエラーは0件 |
| 再試行 | 2回（429/5xx/タイムアウト）＋出力欠落時1回 | 実測で再試行の発生は0回 |
| effort / thinking | low / off | medium は品質向上なし、thinking は +50%（E005） |
| キャッシュ | 静的部分（system.txt）を先頭に置く | claude -p はプロンプト全体をキャッシュに計上するため、コスト表示は実行順に依存する |

## 期待される品質・コスト・時間
いずれも Opus 5.5 による silver 参照との一致率で、正解率ではありません。
- 一致率:
  - dev（50ペア、642枠）: 3回平均 0.877（0.905 / 0.844 / 0.882）
  - holdout（41ペア、544枠）: 1回 0.925（ペア単位ブートストラップの95%区間 0.824–0.992）
  - 誤リンク率（参照が拒否する au 行に結びつけた率）は dev・holdout とも 0
- 全152ペアの実行（同時実行6）:
  - 壁時計 153 秒、AI 呼び出し 74回
  - 非キャッシュ換算の定価で 1ペア当たり $0.00098（1,000ペアで約 $0.98）
  - AI を使ったペアの所要時間は中央値 8.9 秒、p90 22.6 秒、最大 43 秒
  - コード判定のペアは 1ミリ秒未満

## 運用
- 実行: pipeline.py の `run(unit, ctx)` を自前の API ラッパーから呼びます。`ctx.llm` は Messages API の1回呼び出しに対応し、`ctx.prompt(name)` は prompts/ の読み込み、`ctx.count` は件数の記録です。
- 再測定: `eval/`（dataset.py、score.py、splits.json、reference/）と charter.json が workspace 形式で同梱されています。手順は次のとおりです。
  1. `relocate_workspace.py` でパスを直します。
  2. `pipeline/` を `candidates/<名前>/` にコピーします。
  3. `run_experiment.py <フォルダ> --candidate <名前> --split dev --purpose confirm` で再測定します。
- 監視する指標:
  - review / conditional の割合（今回は全体の 9.5% / 8.4%）
  - 失敗（欠落行）の発生率
  - 完全一致ペアの割合
  - pair_assessment が different / unclear になったペア
- 再調整が必要になる場面:
  - サイトの項目が変わったとき（non_sku_options、説明欄の抽出方法）
  - モデルを変えたとき
  - review の割合が大きく変わったとき
- 調整前に、人手で確認した参照を作ることを勧めます（report.md を参照）。
