"""c011-shortcut-lean (<- c009): c009 + lean output from c008 (matched rows return r/d/a only; code fills their
evidence from the selector conditions). c009 doc: code decides "exact pairs" without a model call - equal axis counts, no au paid
options, and every Rakuten row has exactly one au row with the same normalized selector values -> matched to that row.
All other pairs go to the c002 Haiku call. Harness: one retry when a reply is unparseable or misses rows.

Input: the pair record as compact JSON (hash/native-index fields dropped, description.text dropped because
description.lines carry the same text with ids) with short ids R*/A* for SKU rows and rd*/ad* for
description lines. Output: one JSON object with one result per Rakuten row; the pipeline maps the short ids
back to the original sku_keys/evidence ids. Hygiene only: invalid ids are counted and turned into review.
"""
import json
import re
import unicodedata


def compact(rec):
    out = {"product_pair_id": rec["product_pair_id"]}
    for side, pre, dpre in (("rakuten", "R", "rd"), ("au", "A", "ad")):
        s = rec[side]
        o = {"title": s["title"],
             "sku_axes": [{"name": a["name"], "values": a["values"]} for a in s["sku_axes"]],
             "skus": []}
        for i, row in enumerate(s["skus"]):
            r = {"id": f"{pre}{i}", "conditions": {c["name"]: c["value"] for c in row["conditions"]}}
            if side == "rakuten":
                r["variant_id"] = row.get("variant_id")
                r["auxiliary_attributes"] = {a["name"]: a["value"] for a in row.get("auxiliary_attributes", [])
                                             if a.get("value") not in (None, "", "-")}
            o["skus"].append(r)
        d = s["description"]
        o["description"] = {"mode": d["mode"],
                            "lines": [{"id": f"{dpre}{j}", "text": ln["text"]} for j, ln in enumerate(d["lines"], 1)],
                            "links": d.get("links", [])}
        if side == "au":
            o["non_sku_options"] = s["non_sku_options"]
        out[side] = o
    return out


def _norm(v):
    v = unicodedata.normalize("NFKC", v).lower()
    return re.sub(r"[\s\u3000・/／\-_()（）\[\]【】「」]+", "", v)


def _sig(row):
    return tuple(sorted(_norm(c["value"]) for c in row["conditions"]))


def exact_pair(rec):
    """Every Rakuten row has exactly one au row with identical normalized values; same axis count; no paid options."""
    R, A = rec["rakuten"], rec["au"]
    if len(R["sku_axes"]) != len(A["sku_axes"]) or A["non_sku_options"]["has_paid_options"]:
        return None
    au = [_sig(s) for s in A["skus"]]
    out = []
    for s in R["skus"]:
        sig = _sig(s)
        if au.count(sig) != 1:
            return None
        a = A["skus"][au.index(sig)]
        out.append({"rakuten_sku_key": s["sku_key"], "decision": "matched", "au_sku_key": a["sku_key"],
                    "required_extra_options": [], "unresolved_conditions": [],
                    "evidence_refs": [f"rakuten/{s['sku_key']}/{c['name']}" for c in s["conditions"]]
                    + [f"au/{a['sku_key']}/{c['name']}" for c in a["conditions"]],
                    "reason": "rule: identical normalized selector values, same axis count, no au paid options"})
    return {"product_pair_id": rec["product_pair_id"], "pair_assessment": "same(rule)", "results": out}


def _ev(rec, ref):
    """Map short evidence ids back to dataset references."""
    try:
        if ref.startswith("rd") and ref[2:].isdigit():
            return rec["rakuten"]["description"]["lines"][int(ref[2:]) - 1]["evidence_id"]
        if ref.startswith("ad") and ref[2:].isdigit():
            return rec["au"]["description"]["lines"][int(ref[2:]) - 1]["evidence_id"]
        if ref[:1] in "RA" and ":" in ref:
            rid, cond = ref.split(":", 1)
            side = "rakuten" if rid[0] == "R" else "au"
            key = rec[side]["skus"][int(rid[1:])]["sku_key"]
            return f"{side}/{key}/{cond}"
        if ref[:1] in "RA" and ref[1:].isdigit():
            side = "rakuten" if ref[0] == "R" else "au"
            return f"{side}/{rec[side]['skus'][int(ref[1:])]['sku_key']}"
    except (IndexError, ValueError, KeyError):
        pass
    return ref


def to_output(rec, js, ctx=None):
    """Model JSON (short ids) -> dataset output. Raises on missing/invalid structure."""
    if not isinstance(js, dict) or not isinstance(js.get("results"), list):
        raise ValueError("no results list")
    rk = [s["sku_key"] for s in rec["rakuten"]["skus"]]
    ak = [s["sku_key"] for s in rec["au"]["skus"]]
    by_r = {}
    for it in js["results"]:
        if not isinstance(it, dict):
            continue
        r = str(it.get("r", ""))
        if not (r.startswith("R") and r[1:].isdigit() and int(r[1:]) < len(rk)) or r in by_r:
            if ctx:
                ctx.count("dropped_bad_or_dup_r")
            continue
        by_r[r] = it
    missing = [f"R{i}" for i in range(len(rk)) if f"R{i}" not in by_r]
    if missing:
        raise ValueError(f"missing {len(missing)} rows: {missing[:5]}")
    results = []
    for i, key in enumerate(rk):
        it = by_r[f"R{i}"]
        d = it.get("d")
        a = it.get("a")
        au_key = None
        if isinstance(a, str) and a.startswith("A") and a[1:].isdigit() and int(a[1:]) < len(ak):
            au_key = ak[int(a[1:])]
        elif a not in (None, "", "null") and ctx:
            ctx.count("bad_au_id")
        if d not in ("matched", "conditional", "unmatched", "review"):
            d = "review"
            if ctx:
                ctx.count("bad_decision")
        if d in ("matched", "conditional") and au_key is None:
            d = "review"
            if ctx:
                ctx.count("link_without_au")
        if d == "unmatched":
            au_key = None
        xs = []
        for x in it.get("x") or []:
            if isinstance(x, dict):
                xs.append({"feature": str(x.get("feature", "")), "required_state": str(x.get("state", "")),
                           "selection_label": x.get("label"), "current_selection_verified": False,
                           "evidence_refs": [_ev(rec, str(e)) for e in (x.get("e") or [])]})
        ev = [_ev(rec, str(e)) for e in (it.get("e") or [])]
        why = str(it.get("why", ""))
        if d == "matched" and not ev and au_key is not None:
            arow = rec["au"]["skus"][ak.index(au_key)]
            ev = ([f"rakuten/{key}/{c['name']}" for c in rec["rakuten"]["skus"][i]["conditions"]]
                  + [f"au/{au_key}/{c['name']}" for c in arow["conditions"]])
            why = why or "all selector conditions and page-level facts of both rows correspond"
        results.append({"rakuten_sku_key": key, "decision": d, "au_sku_key": au_key,
                        "required_extra_options": xs,
                        "unresolved_conditions": [str(u) for u in (it.get("u") or [])],
                        "evidence_refs": ev,
                        "reason": why})
    return {"product_pair_id": rec["product_pair_id"], "pair_assessment": js.get("pair"), "results": results}


def run(unit, ctx):
    rec = unit["input"]
    ruled = exact_pair(rec)
    if ruled is not None:
        ctx.count("rule_decided", len(ruled["results"]))
        ctx.count("rule_pairs")
        return ruled
    system = ctx.prompt("system.txt")
    user = ctx.prompt("user.txt").replace("{{UNIT_JSON}}", json.dumps(compact(rec), ensure_ascii=False))
    last = None
    for attempt in range(2):
        r = ctx.llm(user, system, tag="main" if attempt == 0 else "retry", expect_json=True)
        if not r["ok"]:
            raise RuntimeError(f"{r['error_kind']}: {r['error']}")
        try:
            if r["json"] is None:
                raise ValueError("unparseable model output")
            return to_output(rec, r["json"], ctx)
        except ValueError as e:
            ctx.count("retry_bad_output")
            last = e
    raise last
